XBMC-plugin Elisa Viihteelle

https://github.com/anylonen/XBMC-Elisa-Viihde-plugin/wiki

Original author is zippoman. Fixes and changes are done by purtsi, teerytko, anylonen and ottok.




