# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="BELGESEL"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://www.belgeselizle.net/'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Belgesel ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR][COLOR lightblue][B] Yeni Eklenen Belgeseller [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
        ##### KATEGORILERI OKU EKLE ##########################
        
        link=araclar.get_url(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>').findall(link)
        for url,name in match:               
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+ name+'[/B][/COLOR]',"Dublaj(url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.belgeselizle.net/?s='+query)
            Dublaj(url)

############
def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)" title=".*?">\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)" />').findall(link)
        for url,thumbnail,name in match:
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

        page=re.compile('class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     
        
###########        
                                
###########
def Dublaj(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)" title=".*?">\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)" />').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
                
        page=re.compile('class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Dublaj(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")



        
#############
def VIDEOLINKS(name,url):
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                link=link.replace('\xf6',"o").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
                response.close()

                                
                you_match=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
                print you_match
                for code in you_match:
                        print code
                        yt=('plugin://plugin.video.youtube/?action=play_video&videoid='+str(code))
                        araclar.addLink('~~Son~~',yt,'')
                        playList.add(yt)
                xbmcPlayer.play(playList)
                if not xbmcPlayer.isPlayingVideo():
                        d = xbmcgui.Dialog()
                        d.ok('Sunucu Hatası', 'Aranan Video Bulunamadi.','Baska Video Deneyiniz.')
             
        
