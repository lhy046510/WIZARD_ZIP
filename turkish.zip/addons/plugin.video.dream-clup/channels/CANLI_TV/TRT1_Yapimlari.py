# -*- coding: utf-8 -*- happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="TRT1_Yapimlari"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme OKUYUNUZ  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        canli='rtmp://edge03-08.az.myvideo.az/dvrh264/trt1/trt1 swfUrl=http://www.myvideo.az/dvr/dvrManual4.swf live=1 pageUrl=http://www.myvideo.az/?act=dvr&chan=trt1'
        url='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=1'
        diziler2='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=2'
        diziler3='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=3'
        diziler4='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=4'
        diziler5='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=5'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B]7/24 CANLI YAYIN [/B][/COLOR]', "VIDEOLINKS2(name,url)",canli,'special://home/addons/plugin.video.dream-clup/resources/images/TRT1.png')
        link=araclar.get_url(url)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler2)  
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler3)  
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler4)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler5)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
                
def diziler(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            name=name.replace('wmv','').replace('(','').replace(')','')
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"mpdort1(name,url)",url,thumbnail)
        page=re.compile('<div style="clear:both;"><br/><br/> | <a href\=".\/(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR blue][B]Sayfa >> [/B][/COLOR]'+'[COLOR pink][B]'+name+'[/B][/COLOR]',"diziler2(url)",url,'')

def diziler2(url):
        link=araclar.get_url(url)  
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"mpdort1(name,url)",url,thumbnail)

def mpdort1(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('\\',"")
        match=re.compile('"mms://(.*?).wmv"').findall(link)
        for url in match:
                url='mms://'+url+'.wmv'
                                
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
                

def VIDEOLINKS2(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Yogunluktan Dolayi Bazen ilk Denemede Acilmayabilir.[/COLOR]","[COLOR orange]Brkac Dakika Sonra Tekrar Deneyin.[/COLOR]")
  except:
        
        pass
