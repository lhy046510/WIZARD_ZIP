# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="KanalD_Yapimlari"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        tom='http://live.netd.com.tr/S1/HLS_LIVE/kanald/1500/prog_index.m3u8'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B] 7/24 CANLI YAYIN [/B][/COLOR]', "VIDEOLINKS2(name,url)",tom,'special://home/addons/plugin.video.dream-clup/resources/images/KanalD.png')

        url='http://www.kanald.com.tr/Dizi'
        link=araclar.get_url(url)  
        match=re.compile('<a href="/(.*?)"></a>\r\n        </div>\r\n').findall(link)
        for url in match:
            name=url
            url='http://video.kanald.com.tr/'+url+'/Bolumler/'
            name=name_fix(name)
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"yeni(url)",url,'')

def yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)">\r\n<h2 class=".*?">(.*?)</h2>\r\n').findall(link)
        for url,name in match:
            url='http://video.kanald.com.tr'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"yeni2(name,url)",url,'')

def yeni2(name,url): 
        link=araclar.get_url(url)  
        match=re.compile('<iframe id="hdsframe" src="http:\/\/video1.kanald.com.tr\/KanaldVideo\/MobilFrame\/\?part\=(.*?)" ').findall(link)
        for url in match:
                url='http://video1.kanald.com.tr/KanaldVideo/MobilFrame/?part='+url
                araclar.addDir(fileName,'[COLOR lightgreen] [B]'+name+'[/B][/COLOR]',"yeni3(name,url)",url,'')
        match1=re.compile('  var hds = \'(.*?).m3u8\'').findall(link)
        for url in match1:
                url='http://212.224.80.78'+url+'.m3u8'
                araclar.addDir(fileName,'[COLOR orange][B] Alternatif - '+name+'[/B][/COLOR]',"VIDEOLINKS2(name,url)",url,'')
                
def yeni3(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url)  
        match=re.compile('path: \'http://(.*?).mp4\'').findall(link)
        for url in match:
                url='http://'+url+'.mp4'

                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)        

def VIDEOLINKS2(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def name_fix(x):        
        x=x.replace('-',' ').replace('_',' ')
        return x[0].capitalize() + x[1:]

