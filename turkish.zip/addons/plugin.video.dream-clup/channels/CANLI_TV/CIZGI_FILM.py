# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="CIZGI_FILM"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        tom='http://www.cizgifilm.ws/izle/tom_ve_jerry-izle'
        #kayu='http://www.cizgifilm.ws/izle/caillou_kayu-izle'
        duck='http://www.cizgifilm.ws/izle/donald-duck-izle'
        ben='http://www.cizgifilm.ws/izle/ben_10-izle'
        naruto='http://www.cizgifilm.ws/izle/naruto-izle'
        panter='http://www.cizgifilm.ws/izle/pembe_panter-izle'
        pepe='http://www.cizgifilm.ws/izle/pepee-izle'
        sirinler='http://www.cizgifilm.ws/izle/sirinler'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Tom & Jerry[/B][/COLOR]', "Yerli(url)", tom,"")
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Caillou – Kayu[/B][/COLOR]', "Yerli(url)", kayu,"")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]Donald Duck[/B][/COLOR]', "Yerli(url)", duck,"")
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Ben 10[/B][/COLOR]', "Yerli(url)", ben,"")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR yellow][B]Naruto[/B][/COLOR]', "Yerli(url)", naruto,"")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Pembe Panter[/B][/COLOR]', "Yerli(url)", panter,"")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Pepee[/B][/COLOR]', "Yerli(url)", pepe,"")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Sirinler[/B][/COLOR]', "Yerli(url)", sirinler,"")
             
def Yerli(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)">\t\t\t<img src="http:\/\/www.cizgifilm.ws(.*?)" alt="(.*?)" width=".*?" height=".*?" /></a>').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR blue][B]Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "Yerli(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

def ayrisdirma(name,url):
                link=araclar.get_url(url)
                match=re.compile('src="http://vk.com/(.*?)"').findall(link)
                for vk in match:
                        vk=''
                        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>VK Video   '+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")
                link=araclar.get_url(url)
                match1=re.compile('movieSrc=mail\/(.*?)"').findall(link)
                for mailru in match1:
                        mailru=''
                        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>Mail Ru 1   '+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")
                link=araclar.get_url(url)
                match2=re.compile('<iframe src="http://api.video.mail.ru/videos/embed/mail/(.*?).html"').findall(link)
                for mailru in match2:
                        mailru=''
                        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>Mail Ru 2   '+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")
                link=araclar.get_url(url)
                match2=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
                for dm in match2:
                        mailru=''
                        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>dm   '+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")
                link=araclar.get_url(url)
                match2=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
                for youtube in match2:
                        youtube=''
                        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>dm   '+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")


def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        
        vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        for url in divxstage:
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        	#---------------------------------------------#
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        for url in movshare:
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
        for url,uploadcgelen in uploadc:
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                #print url
                urlList.append(url)

        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
        for url,divxstagegelen in divxstage:
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
