# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver,time

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="zChat"

url='aHR0cDovL2ZvcnVtLnhibWN0ci5jb20vY2hhdGJveC9pbmRleC5waHA='
t='http://www.chatfriend.biz/wp-content/uploads/1702f3259cb397da605f404069d0a527_1283856793.jpg'

def replace_fix(x):        
        x=x.replace('<font  color=\'Maroon\'>', '').replace('<font  color=\'Red\'>', '').replace('#1E90FF', 'blue').replace('</font>', '').replace('#FF8C00', 'orange').replace('.gif', '').replace('</b>', '').replace('<b>', '').replace('&gt;&gt;&gt; <a target="_blank" href="', '').replace('</em>', '').replace('<em>', '').replace('border=\'0\' />', ' ').replace('">[Link]</a>', ' ').replace('<img src=\'http://us.i1.yimg.com/us.yimg.com/i/mesg/emoticons7/4\'', ':))').replace('<font  color=\'Orange\'>', '').replace('<font  color=\'DarkGreen\'>', '').replace('<font face=\'Arial Black\' color=\'Blue\'>', '').replace('<font face=\'Arial Black\' color=\'Maroon\'>', '').replace('<font  color=\'Brown\'>', '').replace('<font face=\'Verdana\' color=\'Red\'>', '').replace('<font face=\'Verdana\' color=\'Blue\'>', '').replace('<font  color=\'Blue\'>', '').replace('<img src=\'', '').replace('\'', '').replace('<font face=Tahoma color=Red>', '').replace('<i>', '').replace('</i>', '').replace('<font face=Arial Black>', '').replace('<font face=Arial Black color=Brown>', '').replace('<font  color=Tomato>', '').replace('<font face=Century Gothic color=BlueViolet>', '').replace('<a target=\"_blank\" href=\"', '').replace('<font  color=BlueViolet>', '')#.replace('', '')#.replace('', '')#.replace('', '')#.replace('', '')#.replace('', '')
        return x
                                                                                                                                                        
def main():
        link=araclar.get_url(base64.b64decode(url))
        match1=re.compile('<span class=\'time\'>(.*?)</span></span>  <a href=\'.*?\' target=\'.*?\'><b><span style="color:(.*?);"><strong>(.*?)</strong></span></b></a>(.*?)</div>').findall(link)
        for zaman,renk,name,yazi in match1:
                yazi=replace_fix(yazi)
                name=replace_fix(name)                                                                                                                                                                                                            
                renk=replace_fix(renk)
                #print yazi
                araclar.addDir(fileName,'[COLOR cyan]'+zaman+'[/COLOR]'+'[COLOR'+' '+renk+']'+'  '+name+'[/COLOR]'+' [COLOR beige]'+yazi+'[/COLOR]',"",url,t)
