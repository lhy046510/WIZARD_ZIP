# -*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS



  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="silver_cinema"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    url='http://movie25.ws/category/hollywood/'
    url1='http://movie25.ws/category/tv-shows/'
    url2='http://movie25.ws/category/tv-episodes/'
    url3='http://movie25.ws/'
    araclar.addDir(fileName,'Search', "Search()",url3,"http://www.clker.com/cliparts/K/4/J/T/s/Y/movie-folder-icon-md.png")
    araclar.addDir(fileName,'Movies', "movies(url)",url,"http://www.clker.com/cliparts/K/4/J/T/s/Y/movie-folder-icon-md.png")
    araclar.addDir(fileName,'TV Shows', "tvshows(url)",url1,"http://fc04.deviantart.net/fs51/i/2009/312/b/3/TV_show_icon_1_by_Butchokoy.jpg")
    araclar.addDir(fileName,'TV Episodes', "newepisodes(url)",url2,"http://icons.iconarchive.com/icons/firstline1/tv-show-mega-pack-1/512/Episodes-icon.png")
    araclar.addDir(fileName,'Categories', "ingkategory(url)",url3,"http://icons.iconarchive.com/icons/limav/movie-genres-folder/icons-390.jpg")
    araclar.addDir(fileName,'Most populer', "mostpopuler(url)",url3,"http://www.clker.com/cliparts/K/4/J/T/s/Y/movie-folder-icon-md.png")
    araclar.addDir(fileName,'Featured Movies', "futured(url)",url3,"http://fc04.deviantart.net/fs70/f/2013/044/b/6/movie_icon_by_sdoherty1000-d5usdyq.png")
    araclar.addDir(fileName,'Just Added Movies and Tv Episodes', "justadded(url)",url3,"http://icons.iconarchive.com/icons/icondesigner.net/hyperion/256/3D-Movies-icon.png")

###########
## movie ##                                                     movies section araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I] Featured Movies[/I][/B][/COLOR] ', "inghome(url)",url,"http://fc04.deviantart.net/fs70/f/2013/044/b/6/movie_icon_by_sdoherty1000-d5usdyq.png")

#####################################################################################################################################################################################################




def movies(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="120" height="185" alt=".*?"><div src="" class="kucukIcon"></div></a>').findall(link)
        for url,name,thumbnail in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "moviesinside(url)",url,thumbnail,)
        page=re.compile('<span class=\'on\'>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR pink][B]Next Page >>  [/B][/COLOR]''[COLOR pink][B]'+name+'[/B][/COLOR]', "movies(url) ",url,'http://informationtechnologyii2014.pbworks.com/f/1390249613/next%20sign%20TE.png')


def moviesinside(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('<td><center><a rel=".*?" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')




############# 
## tv shows##                                                    tv shows section
#####################################################################################################################################################################################################






def tvshows(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="120" height="185" alt=".*?"><div src="" class="kucukIcon"></div></a>').findall(link)
        for url,name,thumbnail in match:
            araclar.addDir(fileName,''+name+'', "tvshowsparts(url)",url,thumbnail)
        page=re.compile('<span class=\'on\'>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR pink][B]Sonraki Sayfa >>  [/B][/COLOR]''[COLOR pink][B]'+name+'[/B][/COLOR]', "tvshows(url) ",url,'')

def tvshowsparts(url): 
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center>(.*?)</center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<td><center><a target=".*?" href="(.*?)">(.*?)</a></center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for seiz,date,url,name in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            seiz=seiz.replace('&#8211;', ' ')
            araclar.addDir(fileName,''+seiz+'      '+name+'         '+date+'', "tvshowssinside(url)",url,'')

def tvshowssinside(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a target="_blank" href="(.*?)" target="_blank" rel="nofollow">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match1:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')






##################
## new episodes ##                                              new eposides section
#####################################################################################################################################################################################################





def newepisodes(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="120" height="185" alt=".*?"><div src="" class="kucukIcon"></div></a>').findall(link)
        for url,name,thumbnail in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "episodessparts(url)",url,thumbnail)
        page=re.compile('<span class=\'on\'>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR pink][B]Sonraki Sayfa >>  [/B][/COLOR]''[COLOR pink][B]'+name+'[/B][/COLOR]', "newepisodes(url) ",url,'')

def episodessparts(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a target="_blank" href="(.*?)" target="_blank" rel="nofollow">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match1:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')


################
## just added ##                                                  just added section
####################################################################################################################################################################################################






def justadded(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="afis">\r\n\t\t\t\t\t\t\t\t\t\t\t<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="126" height="185" alt=".*?" /><div class="kucukIcon"></div>  </a>\r\n\t\t\t\t\t\t\t\t\t</div>').findall(link)
        for url,name,thumbnail in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "justparts(url)",url,thumbnail)
        page=re.compile('<span class=\'on\'>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR pink][B]Sonraki Sayfa >>  [/B][/COLOR]''[COLOR pink][B]'+name+'[/B][/COLOR]', "justadded(url) ",url,'')



def justparts(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<a rel=".*?" target=".*?" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n</tr>').findall(link)
        for url,name in match1:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')






#############
## futured ##                                                            futured section
######################################################################################################################################################################################################






def futured(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="90" height="135" alt=".*?" /></a>').findall(link)
        for url,name,thumbnail in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "futuredparts(url)",url,thumbnail)


def futuredparts(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<a rel=".*?" target=".*?" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n</tr>').findall(link)
        for url,name in match1:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')






################
## categories ##                                                           categories section
######################################################################################################################################################################################################




def ingkategory(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class=".*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link)
        for url,name in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "inginside(url)",url,'https://cdn0.iconfinder.com/data/icons/ticket/500/Cinema_film_movie_ticket_entertainment_theater_coupon_circus_event_star_stars_music-512.png')


def inginside(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="120" height="185" alt=".*?"><div src="" class=".*?"></div></a>').findall(link)
        for url,name,thumbnail in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "ingparts(url)",url,thumbnail)
        page=re.compile('<span class=\'on\'>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR pink][B]Next Page >>  [/B][/COLOR]''[COLOR pink][B]'+name+'[/B][/COLOR]', "inginside(url) ",url,'http://informationtechnologyii2014.pbworks.com/f/1390249613/next%20sign%20TE.png')

def ingparts(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<a rel=".*?" target=".*?" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n</tr>').findall(link)
        for url,name in match1:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')




##################
## most populer ##                                           most populer section
####################################################################################################################################################################################################




def mostpopuler(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li><a href="(.*?)"  title="(.*?)">.*?</a> -(.*?)</li>').findall(link)
        for url,name,discription in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "mostparts(url)",url,'http://www.clker.com/cliparts/K/4/J/T/s/Y/movie-folder-icon-md.png')
        match1=re.compile('<li>\n\t\t\t\t<a href="(.*?)">(.*?)</a>\n\t\t\t\t\t\t</li>').findall(link)
        for url,name in match1:
            araclar.addDir(fileName,''+name+'', "mostparts(url)",url,'http://www.clker.com/cliparts/K/4/J/T/s/Y/movie-folder-icon-md.png')


def mostparts(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<a rel=".*?" target=".*?" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n</tr>').findall(link)
        for url,name in match1:
            #name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')


############
## search ##                                                  search section
###########################################################################################################################################################################################################



def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://movie25.ws/?s='+query+'')
            Yeni(url) 



def Yeni(url):
    link=araclar.get_url(url)
    match=re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" width="126" height="185" alt=".*?" /><div class="kucukIcon"></div>  </a>').findall(link)
    if match:
        for url,name,thumbnail in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "searchparts(url)",url,thumbnail)
            if not match:
                araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR][COLOR yellow][B] Movie Not Uploaded Yet // Film Henuz Eklenmedi [/B][/COLOR][COLOR red][B] <<<[/B][/COLOR]', "Search()", "",'')

               
    if not match:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(fileName,"Listen","     Do Not Search Again   ","  If You Do I won't Show You  ")
        return False  


def searchparts(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        link=araclar.get_url(url) 
        match=re.compile('<tr>\n<td><center><a rel="nofollow" target="_blank" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n<p><!--ENTER NAME HERE --></tr>').findall(link)
        for url,name in match:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        match1=re.compile('<a rel=".*?" target=".*?" href="(.*?)">.*?</a></center></td>\n<p><!--ENTER LINK HERE --></p>\n<td><center>(.*?)</center></td>\n</tr>').findall(link)
        for url,name in match1:
            name=name.replace('&#8211;', ' ').replace('&#038;', '&').replace('&#8217;', '')
            araclar.addDir(fileName,''+name+'', "cozucu.magix_player(name,url)",url,'http://icons.iconarchive.com/icons/toma4025/rumax/256/drive-bluray-icon.png')
        page=re.compile('<span class=\'on\'>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            araclar.addDir(fileName,'[COLOR pink][B]Next Page >>  [/B][/COLOR]''[COLOR pink][B]'+name+'[/B][/COLOR]', "searchparts(url) ",url,'http://informationtechnologyii2014.pbworks.com/f/1390249613/next%20sign%20TE.png')




            

