#-*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
   
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
   
fileName ="Pasha_CanliTV"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 

canlitvt='aHR0cDovL3d3dy51c2VybG9nb3Mub3JnL2ZpbGVzL2xvZ29zL2lnb3IyMy9saXZldHZfYmxhY2sucG5n'
   
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        url='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1Bhc2hhX0NhbmxpX1RWLnhtbA=='
        url1='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L21hcmNvL1RVUksuNy50eHQ='
        url2='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L21hcmNvL3Nwb3JsYXJfc2t5LnhtbA=='
        
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]Canli_Turkish[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(url)),(base64.b64decode(canlitvt)))
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]Karma_Turkish[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(url1)),(base64.b64decode(canlitvt)))
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]English Live Channels[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(url2)),(base64.b64decode(canlitvt)))
         
         
 
def VIDEOLINKSS(name,url): 
        link=araclar.get_url(url)
        match=re.compile("<name>(.*?)</nam.*?ail>(.*?)</th.*?nk>(.*?)</link>").findall(link) 
        for name,thumbnail,url in match:
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail) 
        match1=re.compile("<name>(.*?)</name>\n<thumbnail>(.*?)</thumbnail>\n<link>(.*?)</link>").findall(link) 
        for name,thumbnail,url in match1: 
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail) 
        match2=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link) 
        for name,thumbnail,url in match2: 
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail) 
        match3=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link> \n').findall(link) 
        for name,thumbnail,url in match3: 
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail) 
        match4=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>\n').findall(link) 
        for name,thumbnail,url in match4: 
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail) 
        match5=re.compile('#EXTINF:-1, (.*?)\n#EXTINF:0,(.*?)\n').findall(link) 
        for name,url in match5: 
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]>[/B][/COLOR]'+ name,"yeni4(name,url)",url,'') 
        match6=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link) 
        for name,url in match6: 
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]>[/B][/COLOR]'+ name,"yeni4(name,url)",url,'') 

def yeni4(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
