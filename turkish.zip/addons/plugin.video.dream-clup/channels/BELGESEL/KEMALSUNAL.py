# -*- coding: iso-8859-9 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
import os,base64

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="KEMALSUNAL"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>[/B][/COLOR][COLOR yellow][B]Bu Addons Kemal Sunal Anisina xbmcTR Team Tarafindan Hazirlanmistir[/B][/COLOR][COLOR red][B] <[/B][/COLOR]', "", "","")
        url=url='aHR0cDovL3hibWN0ci5jb20vYmVzaXIva2VtYWxzdW5hbC54bWw='
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
        for name,url,thumbnail in match:
                name='[COLOR beige][B]'+name+'[/B][/COLOR]'			
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)

def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
