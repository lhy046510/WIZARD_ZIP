# -*- coding: utf-8 -*-
##this script creates earch page for all related web sites in this addon
##created by drascom in date:18.03.2013
##it's not commercial free to use change all code


import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu

web = 'http://www.webteizle.com/'

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

from BeautifulSoup import BeautifulSoup 




def main():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)

  
       

        try:
                fileName ="BAGLANBIZE"
                araclar.addDir(fileName,'[COLOR blue][B] --- BAGLAN BIZE SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.baglanfilmizle.com/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a href="http://www.baglanfilmizle.com/(.*?).html"><img src=".*?" width=".*?" height=".*?" alt=".*?" title=".*?"/></a>\n\t\t\t<a href="(.*?)">\t<img src=".*?" width=".*?" height=".*?" alt=".*?" title=".*?" />\n</a>\n\t\t</div>\n\t</div>\n\t<img src="(.*?)" alt=""').findall(link)
                for name,url,thumbnail in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"tek(url)",url,thumbnail)
        except:
                xbmc.executebuiltin('Notification("Media Center","BAGLAN BIZE Acılamadı")')
        
        try:
                fileName ="CINESALON"
                araclar.addDir(fileName,'[COLOR blue][B] --- CINESALON SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.videonuz.org/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a href="(.*?)">\n<img src="(.*?)" alt=".*?" height="125px" width="119px" /></a>\n<div class="movief"><a href=".*?">(.*?)</a></div>').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","CINESALON Acılamadı")')

        try:
                fileName ="FILME2KDE"
                araclar.addDir(fileName,'[COLOR blue][B] --- FILME2KDE SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.filme2k.net/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a class="coverimg" title=".*?" href="(.*?)"><img src="(.*?)" width="150" height="220" alt="(.*?)" title=".*?" />').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"tek(url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","FILME2KDE Acılamadı")')

        try:
                fileName ="FILMSEYRET"
                araclar.addDir(fileName,'[COLOR blue][B] --- FILMSEYRET SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.filmizleseyret.com/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a  title=".*?" href="(.*?)" rel="bookmark">(.*?)</a></h2>\n\n<p>\n\n<img style="float:left;margin:0px 10px 0px 0px;" height="240" width="155" src="(.*?)" align="top" alt=".*?" /></a>').findall(link)
                for url,name,thumbnail in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","FILMSEYRET Acılamadı")')

        try:
                fileName ="FILMTEK"
                araclar.addDir(fileName,'[COLOR blue][B] --- FILMTEK SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.filmtekpart.net/?s='+query)
                link=araclar.get_url(url)       
                match=re.compile('<a href="(.*?)" title="(.*?)">\r\n\r\n<img src="(.*?)" class="img" alt="" /></a>').findall(link)
                for url,name,thumbnail in match:
                       
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","FILMTEK Acılamadı")')

        try:
                fileName ="HDSEYIR"
                araclar.addDir(fileName,'[COLOR blue][B] --- HDSEYIR SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.film-izle.biz/index.php?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a href="(.*?)"><img src="(.*?)"  alt="(.*?)" height="207" width="140"').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","HDSEYIR Acılamadı")')
        try:
                fileName ="HEYFILM"
                araclar.addDir(fileName,'[COLOR blue][B] --- HEYFILM SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.onlinefilmizle.org/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a  href="(.*?)" rel="bookmark"><img src="(.*?)" alt="(.*?)"').findall(link)
                for url,thumbnail,name in match:
                        url = url+'/2'
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","HEYFILM Acılamadı")')
        try:
                fileName ="IZLEDUR"
                araclar.addDir(fileName,'[COLOR blue][B] --- IZLEDUR SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.hdfilmsehri.com/index.php/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('\r\r\n\t\t\t\t\t<a href="(.*?)" title="">\r\r\n\t\t\t\t\t\t<img width="135" height="195" src="(.*?)" class="attachment-135x195 wp-post-image" alt="(.*?)" title=""').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","IZLEDUR Acılamadı")')

        try:
                fileName ="IZLETIME"
                araclar.addDir(fileName,'[COLOR blue][B] --- IZLETIME SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.filmizlehep.com/?s='+query)
                link=araclar.get_url(url)  
                match=re.compile('<a  href="(.*?)" rel="bookmark"><img src="(.*?)" height="192px" width="130px" alt="(.*?)" class="captify"').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","IZLETIME Acılamadı")')
        try:
                fileName ="NOSTALJI"
                araclar.addDir(fileName,'[COLOR blue][B] --- NOSTALJI SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.nostaljifilmizle.com/?s='+query)
                link=araclar.get_url(url)
                match=re.compile('<a href="(.*?)">\n<img src="(.*?)" alt="(.*?) &#8211; .*? &#8211; .*?" height="125px" width="119px" /></a>').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","NOSTALJI Acılamadı")')

        try:
                fileName ="WEBTEIZLE"
                araclar.addDir(fileName,'[COLOR blue][B] --- WEBTEIZLE SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.webteizle.com/Arama.asp?Sozcuk='+query+'&Kategori=yabanci')
                link=araclar.get_url(url)  
                match=re.compile('<a href="(.*?)" class="red-link" title=".*?"><img src="(.*?)" alt="(.*?)" style="border-width: 0px; height: 150px; width: 110px;" /></a>').findall(link)
                for url,thumbnail,name in match:
                        url=web+url
                        thumbnail=web+thumbnail
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","WEBTEIZLE Acılamadı")')
        try:
                fileName ="FILMZE"
                araclar.addDir(fileName,'[COLOR blue][B] --- FILMZE SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.filmze.com/search.php?query='+query)
                link=araclar.get_url(url)
                match=re.compile('</a><a href="(.*?)"> \r\n\r\n\r\n          \r\n\r\n\r\n          \r\n\r\n\r\n           <img src="(.*?)" width=120px alt="(.*?)" /><br />').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","FILMZE Acılamadı")')

        try:
                fileName ="HDIZLE"
                araclar.addDir(fileName,'[COLOR blue][B] --- HDIZLE SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.hdfilmsitesi.com/?s='+query)
                link=araclar.get_url(url)
                match=re.compile('</div> \r\n   \r\n\t\t\t\t\r\n\r\n\t\t\r\n\r\n<img alt=".*?" src="(.*?)" title=".*?" width="135" height="180" /><a href="(.*?)" title="(.*?)" class="play">izle</a>\r\n\r\n\r\n\r\n</div>').findall(link)
                for thumbnail,url,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","HDIZLE Acılamadı")')

        try:
                fileName ="MOVIE2K"
                araclar.addDir(fileName,'[COLOR blue][B] --- MOVIE2K SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.movie2k.to/searchAutoCompleteNew.php?search=' + query)
                link=araclar.get_url(url)
                match=re.compile('\t\t<TD width="550" id="tdmovies">\n            \t\t    <a href="(.*?)">(.*?)\t\t ').findall(link)
                for url in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","MOVIE2K Acılamadı")')

        try:
                fileName ="BELGESEL"
                araclar.addDir(fileName,'[COLOR blue][B] --- BELGESEL SONUCLARI ---[/B][/COLOR]',"","","")
                url = ('http://www.belgeselizle.net/?s='+query)
                link=araclar.get_url(url)
                match=re.compile('<a href="(.*?)" title=".*?">\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)" />').findall(link)
                for url,thumbnail,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        except:
                    xbmc.executebuiltin('Notification("Media Center","BELGESEL Acılamadı")')
       


