import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64 
import araclar,cozucu,time
  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="Canli_Mac_izle"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 

urll='aHR0cDovL2NyaWNmcmVlLnN4L2xpdmUv'
livet='http://1.bp.blogspot.com/-k_a-9qP_TQw/Ubk0KowrukI/AAAAAAAAHmc/EPwt68xFrYc/s1600/live_transp400x400.png'
thomast='special://home/addons/plugin.video.dream-clup/resources/images/UK_Thomas_Bouquet.png'
hangii='aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20v'

def main(): 
        #url='aHR0cDovL2NyaWNmcmVlLnN4L2xpdmUvd2F0Y2gtbGl2ZS1mb290YmFsbC1zdHJlYW0='
        hangi='aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20vbGl2ZS1mb290YmFsbC1vbi10di8='
        url='http://streamhd.eu/'
        araclar.addDir(fileName,'[COLOR blue][B] This Addon Sponsored by Sharp ELEKTRONIC Repairs[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Sharp_ELECTRONIC.png')        
        araclar.addDir(fileName,'[COLOR blue][B]>>> [COLOR violet]Hangi Mac Hangi Kanalda icin Burdan[/B][/COLOR]',"hangi(url)",(base64.b64decode(hangi)),'special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>> [COLOR navajowhite]Altta Mac Listesi YOKSA,[COLOR lightgreen] Mac Bitmistir,[COLOR red] Yada Daha Baslamamistir.[/B][/COLOR]', "",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        araclar.addDir(fileName,'[COLOR blue][B]***** [COLOR lightblue] Altta Suan CANLI Yayin Olan Maclar Gozukur[COLOR blue][B] *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        link=araclar.get_url(url)
        match=re.compile('<strong>(.*?)</strong>').findall(link)
        for name in match:
                url=url
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "streamhdschedule(url)",url,livet)

def streamhdschedule(url):
        link=araclar.get_url(url)
        match=re.compile('<p><strong>(.*?) <a  href="(.*?)">(.*?)</a><br />\n<p>').findall(link)
        for name,url,kanal in match:
                name=name+' '+'[COLOR yellow]'+kanal+'[/COLOR]'
                araclar.addDir(fileName,'[COLOR lighblue][B] >> [/B][/COLOR][COLOR lightgreen][B]'+name+'[/B][/COLOR]', "streamhdicerik(name,url)",url,livet)             
        url2='http://streamhd.eu/menu.html'
        link=araclar.get_url(url2)
        match1=re.compile('\t\t<li><a href="(.*?)" target="_top">(.*?)</a></li>\n ').findall(link)
        if match1 >0:
                del match1[0]
                
                for url,name in match1:
                        url='http://streamhd.eu'+url
                        araclar.addDir(fileName,'[COLOR lightgreen][B] >> [/B][/COLOR][COLOR lightblue][B]'+name+'[/B][/COLOR]', "streamhdicerik(name,url)",url,livet)

def streamhdicerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<iframe class="video"  src="(.*?)" ').findall(link)
        for url2 in match:
                url2='http://streamhd.eu/'+url2
                link=araclar.get_url(url2)
                match=re.compile(' fid="(.*?)"; ').findall(link)
                for playpath in match:
                        #rtmpe://46.246.124.3:1935/live/ app=live/ playpath=sskys1 swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive.php?u=sskys1&vw=854&vh=480&domain=streamhd.eu live=1
                        url='rtmpe://46.246.124.30:1935/live/ app=live/ playpath='+playpath+' swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive.php?u='+playpath+'&vw=854&vh=480&domain=streamhd.eu live=1'
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

def ayniyim(url):
        link=araclar.get_url(base64.b64decode(urll))
        araclar.addDir(fileName,'[COLOR blue][B]***** [COLOR lightblue] Baslamis Maclar [COLOR blue][B] *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        match=re.compile('<td style=".*?" width="100" class="matchtime">(.*?)</td>\n<td style=".*?" width="550">(.*?)</td>\n<td width="25"> <img src="(.*?)"/></td>\n</tr>\n</table>\n<div style="background:#FFFFFF;color:blue" class="hidden"><a target=\'_blank\' href=\'(.*?)\' style=\'.*?\'>(.*?)</a>').findall(link)
        for saat,name,t,url,kanal in match:
            name=name+' '+'[COLOR beige]'+saat+'[COLOR yellow]'+' uk time zone[/COLOR]'+'[COLOR violet] '+kanal+'[/COLOR]'
            #name=name.replace(':00',' uk time zone')
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "icerik(name,url)",url,livet)

def icerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<iframe frameborder="0" marginheight="0" marginwidth="0" height="490" src="(.*?)"').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile('fid=\'(.*?)\';').findall(link)
                for kanal in match:
                        #rtmp://31.220.0.195:1935/live playpath=channel4 swfUrl=http://www.flashtv.co/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live=channel4&vw=620&vh=490 live=1
                        url='rtmp://31.220.0.195:1935/live playpath='+kanal+' swfUrl=http://www.flashtv.co/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live='+kanal+'&vw=620&vh=490 live=1'
                        playList.clear()
                        araclar.addLink(name,url,livet)
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)  

def hangi(url):
        link=araclar.get_url(url)
        araclar.addDir(fileName,'[COLOR blue][B]***** [COLOR lightblue] Gunun Maclari [COLOR blue][B] *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        match=re.compile('<span class="fixture"><a href="../(.*?)">\r\n                    (.*?)\r\n                    vs\r\n                    (.*?)</a></span> <span class="ground">\r\n                      \r\n                         (.*?)\r\n').findall(link)
        for url,bir,iki,saat in match:
            name='[COLOR beige]'+bir+'[COLOR lightblue] vs '+'[COLOR beige]'+iki+' '+'[COLOR yellow]'+saat
            url=base64.b64decode(hangii)+url
            #name='[COLOR lightblue]'+canli+' '+'[COLOR lightyellow]'+saat+'[COLOR beige]'+mac+'[COLOR lightgreen]'+kanal+'[/COLOR]'
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "hangikanal(url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')

def hangikanal(url):            #special://home/addons/plugin.video.dream-clup/channels/HAPPYFEETS/UK_Thomas_Bouquet.py
        link=araclar.get_url(url)
        araclar.addDir(fileName,'[COLOR lightgreen][B] >>> [COLOR tomato] Thomas Bouguet ten Bu Kanali [COLOR lightblue]HD [COLOR tomato]Olarak izleyebilirsiniz[/B][/COLOR]','','',thomast)
        match=re.compile('<div class="channel-logo"> <a href=""><img src="../(.*?)" alt="(.*?)"').findall(link)
        for t,name in match:
                t=(base64.b64decode(hangii))+t.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR]Beklemeden izlemek icin burdan [COLOR orange][B]'+name+'[/B][/COLOR]', "ayniyim(url)",url,t)
        match1=re.compile('<div class="channel-logo"> <a href=".*?"><img src="../(.*?)" alt="(.*?)"').findall(link)
        for t,name in match1:
                t=(base64.b64decode(hangii))+t.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR]Beklemeden izlemek icin burdan [COLOR orange][B]'+name+'[/B][/COLOR]', "ayniyim(url)",url,t)
