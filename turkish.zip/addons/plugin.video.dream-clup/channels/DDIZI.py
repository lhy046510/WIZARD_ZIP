# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
##addon_id = 'script.module.xbmctr'
##__settings__ = xbmcaddon.Addon(id=addon_id)
##__language__ = __settings__.getLocalizedString

#---------------------------------------------------
web="http://www.ddizi.org"

fileName="DDIZI"
#--------------- YENI KOMUTLAR  --------------------
# sayfa taratma --> araclar.get_url(url)
# klasor ekleme --> araclar.addDir(fileName,name, mode, url="", thumbnail="")
# link ekleme   --> araclar.addLink(name,url,thumbnail)
# videolink bulma --> urlList=cozucu.videobul(url)
# sonrasında     --> for url in urlList if not isinstance(urlList, basestring) else [urlList]:
#                               araclar.addlink(name,url,thumbnail) yada playList.add(url)
#---------------------------------------------------
        
def main():
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR][COLOR beige][B]Yeniler[/B][/COLOR]','yeni(url)',web,"")
        div_list=["[COLOR blue][B]>>[/B][/COLOR][COLOR lightblue][B] Yerli Diziler[/B][/COLOR]","[COLOR brown][B]>>[/B][/COLOR][COLOR beige][B] Eski Diziler[/B][/COLOR]","[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B] Tv Showlar[/B][/COLOR]","[COLOR red][B]>>[/B][/COLOR][COLOR pink][B] Yabanci Diziler[/B][/COLOR]"]
        for x in range(0,4):
                name=div_list[x]
                url=str(x)
                araclar.addDir(fileName,name,"panel(url)",url,"YOK")
                

def yeni(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="dizi-box"><a href="(.*?)"><img src="(.*?)" width="120" height="90" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR]'+'[COLOR lightblue][B]'+name+'[/B][/COLOR]',"resolver(name,url)",url,thumbnail)
def panel(url):
        link=araclar.get_url(web)
        soup=BS(link.decode('utf-8','ignore'))
        div = soup.findAll("div",{"class":"blok-liste"})
        for li in div[int(url)].findAll('li'):#-------------dizi anasayfalari bulur
                url= li.a['href']
                name = li.a.text
                name=name.encode("utf-8")
                araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR][COLOR pink][B]'+name+'[/B][/COLOR]',"kategoriler(url)",url,"YOK") 
def kategoriler(url):                    
        data=araclar.get_url(url)
        match=re.compile('<div class="dizi-box2"><a title="(.*?)" href="(.*?)"><img src="(.*?)"').findall(data)#-----dizi bolumleri bulur
        for name,url,thumbnail in match:
                if not thumbnail:
                     thumbnail="yok"   
                araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B]'+name+'[/B][/COLOR]',"resolver(name,url)",url,thumbnail)
                
        veri=data.strip(' \t\n\r').replace(" ","")
        page=re.compile('class="active"><ahref=".*?">.*?</a></li>\r\n<li><ahref="(.*?)"').findall(veri)# ----- sonraki sayfa
        if page:
                try:
                        url=page[0]
                        araclar.addDir(fileName,'Sonraki Sayfa',kategoriler(url),url,"next")
                except:
                        pass
def resolver(name,url):
        value=[]
        tablist=[]
        urllist=[]
        sayfa=araclar.get_url(url)
        data=sayfa.strip(' \t\n\r').replace(" ","")
        tek=re.compile('<a href="(.*?)">Tek Part</a>').findall(sayfa)
        if tek:
                url=tek[0].replace('rel="nofollow',"").replace('"',"").replace('rel=""rel="nofollow',"")
                tablist.append("http://www.ddizi.net"+url)
        parts=re.compile('<ahref="/izle/(.*?)">.*?.Par\xc3\xa7a</a>').findall(data)
        if parts:
                for url in parts:
                        url=url.replace('rel="nofollow',"").replace('"',"").replace('rel=""rel="nofollow',"")
                        link="http://www.ddizi.net/izle/"+url
                        tablist.append(link)
        print "tablist",tablist
        #--------------- IC FONKSIYON SAYFA TARAR --------------------------
        def sub_scan(url):
                
                data=araclar.get_url(url)
                #-----------------------------------------------------------------------
                xml=re.compile('settingsFile: "(.*?)"').findall(data)
                if xml:
                        veri=araclar.get_url(xml[0])
                        veri2=veri.strip(' \t\n\r').replace(" ","")
                        links=re.compile('videoPathvalue="(.*?)"').findall(veri2)
                        i=0
                        for url in links:
                                urllist.append(('Part '+str(i),url))
                                i+=1
                        
                        
                #------------------------------------------------------------------------
                adres=re.compile('encodeURIComponent\(\'(.*?)\'').findall(data)
                if adres:
                        urllist.append(('Part ',adres[0]))
                        

                        
                #-----------------------------------------------------------------------

                vk=re.compile('iframe src="http://vk.com(.*?)"').findall(data)
                if vk:
                        url="http://vk.com"+vk[0]
                        #--------------------------------eklenecek kısım -------------------------
                        urlList=cozucu.videobul(url)
                        #-----------------liste olarak geri gelir for url in urlList: gerekir-------------#
                        print "cozucu donen veri :"+str(urlList)
                        for url in urlList if not isinstance(urlList, basestring) else [urlList]:
                                urllist.append(("Vk Server",url))
                        
                
                return urllist
        #---------------burdan devam ediyor ----------------
        if len(tablist)>0:
                for url in tablist:
                        sonuc=sub_scan(url)
                
        else:                
                sonuc=sub_scan(url)
                

        if sonuc:
                play(sonuc)
        else:
                dialog = xbmcgui.Dialog()
                i = dialog.ok(name,"Site uyarısı","     Film Siteye henuz yuklenmedi   ","  Yayınlandıktan sonra yüklenecektir.  ")
                return False 

def play(sonuc):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
        playList.clear()
        for x in sonuc:
                name=x[0]
                url=x[1]
                if "youtube" in str(url):
                        code=url.replace("http://www.youtube.com/watch?v=","")
                        url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)
                playList.add(url)
                araclar.addLink(name,url,"")
                
        if playList:
               xbmcPlayer.play(playList)
        


##########  eklenecek kısım 2  #####################################


