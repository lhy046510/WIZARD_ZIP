# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

import araclar,cozucu

web="http://www.ddizi.org"

fileName="DDIZI"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR][COLOR beige][B]Yeniler[/B][/COLOR]','yeni(url)',web,"")
        div_list=["[COLOR blue][B]>>[/B][/COLOR][COLOR lightblue][B] Yerli Diziler[/B][/COLOR]","[COLOR brown][B]>>[/B][/COLOR][COLOR beige][B] Eski Diziler[/B][/COLOR]","[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B] Tv Showlar[/B][/COLOR]","[COLOR red][B]>>[/B][/COLOR][COLOR pink][B] Yabanci Diziler[/B][/COLOR]"]
        for x in range(0,4):
                name=div_list[x]
                url=str(x)
                araclar.addDir(fileName,name,"panel(url)",url,"YOK")
                

def yeni(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="dizi-box"><a href="(.*?)"><img src="(.*?)" width="120" height="90" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR]'+'[COLOR lightblue][B] '+name+'[/B][/COLOR]',"parts(url)",url,thumbnail)
def panel(url):
        link=araclar.get_url(web)
        soup=BS(link.decode('utf-8','ignore'))
        div = soup.findAll("div",{"class":"blok-liste"})
        for li in div[int(url)].findAll('li'):#-------------dizi anasayfalari bulur
                url= li.a['href']
                name = li.a.text
                name=name.encode("utf-8")
                araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR][COLOR pink][B] '+name+'[/B][/COLOR]',"kategoriler(url)",url,"YOK") 
def kategoriler(url):                    
        data=araclar.get_url(url)
        match=re.compile('<div class="dizi-box2"><a title="(.*?)" href="(.*?)"><img src="(.*?)"').findall(data)#-----dizi bolumleri bulur
        for name,url,thumbnail in match:
                if not thumbnail:
                     thumbnail="yok"   
                araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B] '+name+'[/B][/COLOR]',"parts(url)",url,thumbnail)
                
        veri=data.strip(' \t\n\r').replace(" ","")
        page=re.compile('class="active"><ahref=".*?">.*?</a></li>\r\n<li><ahref="(.*?)"').findall(veri)# ----- sonraki sayfa
        if page:
                try:
                        url=page[0]
                        araclar.addDir(fileName,'Sonraki Sayfa',kategoriler(url),url,"next")
                except:
                        pass
def parts(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" rel="nofollow">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://www.ddizi.org'+url
                araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR]'+'[COLOR lightblue][B] '+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')

def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        vk_1=re.compile(' src="https://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        youtube=re.compile('encodeURIComponent\(\'(.*?)\'').findall(link)
        for url in youtube:
                url=url.replace('http://www.youtube.com/watch?v=','')
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        dm=re.compile('src="http\:\/\/www.dailymotion.com\/embed\/video\/(.*?)\?autoplay\=0').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        mailru3=re.compile('movieSrc=mail\/(.*?)&').findall(link)
        for mailrugelen in mailru3:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                #print url
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
