# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulSoup


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
subs = xbmc.translatePath(os.path.join(home, 'resources', 'subs'))

fileName ="DIZIHD"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

web = 'http://dizihdtv.net/'
renk_code=0
def renkler(renk):
    global renk_code
    liste=['[COLOR aliceblue]', '[COLOR antiquewhite]', '[COLOR aqua]', '[COLOR aquamarine]', '[COLOR azure]', '[COLOR beige]', '[COLOR bisque]', '[COLOR black]', '[COLOR blanchedalmond]', '[COLOR blue]', '[COLOR blueviolet]', '[COLOR brown]', '[COLOR burlywood]', '[COLOR cadetblue]', '[COLOR chartreuse]', '[COLOR chocolate]', '[COLOR coral]', '[COLOR cornflowerblue]', '[COLOR cornsilk]', '[COLOR crimson]', '[COLOR cyan]', '[COLOR darkblue]', '[COLOR darkcyan]', '[COLOR darkgoldenrod]', '[COLOR darkgray]', '[COLOR darkgreen]', '[COLOR darkkhaki]', '[COLOR darkmagenta]', '[COLOR darkolivegreen]', '[COLOR darkorange]', '[COLOR darkorchid]', '[COLOR darkred]', '[COLOR darksalmon]', '[COLOR darkseagreen]', '[COLOR darkslateblue]', '[COLOR darkslategray]', '[COLOR darkturquoise]', '[COLOR darkviolet]', '[COLOR deeppink]', '[COLOR deepskyblue]', '[COLOR dimgray]', '[COLOR dodgerblue]', '[COLOR firebrick]', '[COLOR floralwhite]', '[COLOR forestgreen]', '[COLOR fuchsia]', '[COLOR gainsboro]', '[COLOR ghostwhite]', '[COLOR gold]', '[COLOR goldenrod]', '[COLOR gray]', '[COLOR green]', '[COLOR greenyellow]', '[COLOR honeydew]', '[COLOR hotpink]', '[COLOR indianred ]', '[COLOR indigo  ]', '[COLOR ivory]', '[COLOR khaki]', '[COLOR lavender]', '[COLOR lavenderblush]', '[COLOR lawngreen]', '[COLOR lemonchiffon]', '[COLOR lightblue]', '[COLOR lightcoral]', '[COLOR lightcyan]', '[COLOR lightgoldenrodyellow]', '[COLOR lightgrey]', '[COLOR lightgreen]', '[COLOR lightpink]', '[COLOR lightsalmon]', '[COLOR lightseagreen]', '[COLOR lightskyblue]', '[COLOR lightslategray]', '[COLOR lightsteelblue]', '[COLOR lightyellow]', '[COLOR lime]', '[COLOR limegreen]', '[COLOR linen]', '[COLOR magenta]', '[COLOR maroon]', '[COLOR mediumaquamarine]', '[COLOR mediumblue]', '[COLOR mediumorchid]', '[COLOR mediumpurple]', '[COLOR mediumseagreen]', '[COLOR mediumslateblue]', '[COLOR mediumspringgreen]', '[COLOR mediumturquoise]', '[COLOR mediumvioletred]', '[COLOR midnightblue]', '[COLOR mintcream]', '[COLOR mistyrose]', '[COLOR moccasin]', '[COLOR navajowhite]', '[COLOR navy]', '[COLOR none]', '[COLOR oldlace]', '[COLOR olive]', '[COLOR olivedrab]', '[COLOR orange]', '[COLOR orangered]', '[COLOR orchid]', '[COLOR palegoldenrod]', '[COLOR palegreen]', '[COLOR paleturquoise]', '[COLOR palevioletred]', '[COLOR papayawhip]', '[COLOR peachpuff]', '[COLOR peru]', '[COLOR pink]', '[COLOR plum]', '[COLOR powderblue]', '[COLOR purple]', '[COLOR red]', '[COLOR rosybrown]', '[COLOR royalblue]', '[COLOR saddlebrown]', '[COLOR salmon]', '[COLOR sandybrown]', '[COLOR seagreen]', '[COLOR seashell]', '[COLOR sienna]', '[COLOR silver]', '[COLOR skyblue]', '[COLOR slateblue]', '[COLOR slategray]', '[COLOR snow]', '[COLOR springgreen]', '[COLOR steelblue]', '[COLOR tan]', '[COLOR teal]', '[COLOR thistle]', '[COLOR tomato]', '[COLOR turquoise]', '[COLOR violet]', '[COLOR wheat]', '[COLOR white]', '[COLOR whitesmoke]', '[COLOR yellow]', '[COLOR yellowgreen]']
    renk=liste[int(renk_code)]
    renk_kode=renk_code+1
    return renk
############# ANA GIRIS KLASORLERI ##############################
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    url=web
    araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","")
    araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
    araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR beige][B]Yerli [/B][/COLOR]', "yerli(url)",url,"")
    araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR] [COLOR pink][B]Yabancı [/B][/COLOR]', "yabanci(url)",url,"")
        

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
            url = ('http://dizihdtv.net/?s='+ query +'&x=0&y=0')
            yeni(url)

############
def yeni(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src="(.*?)" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>').findall(link)
        for date,url,t,name in match:
            name=name+' [COLOR beige]'+date+'[/COLOR]'         
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,t)


        #sayfalama basladi
        page=re.compile('<span class="current">.+?</span><a href="http://dizihdtv.net/(.+?)" title="(.+?)">').findall(link)
        thumbnail="image/sonrakisayfa.jpg"
        for url,name in page:
                name="Sonraki Sayfa"
                url="http://dizihdtv.net/"+str(url)
                araclar.addDir(fileName,'[COLOR blue][B]>>>>>>'+name+'[/B][/COLOR]',"yeni(url)",url,thumbnail)

def yerli(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel=soup.find("div", {"id": "panel-1"})
        for a in panel.findAll('a',href=True,title=True):
                url=a['href']
                name1=re.findall(r".*?dizihdtv.net/dizi-izle/(.*?)$", url)
                name1=name1[0].replace('-izle',"").replace('-'," ")
                thumbnail="http://dizihdtv.net/img/"+name1.replace(" ","")+".png"
                # name=name.capitalize()
                name = a.find(text=True)
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name.encode('utf-8')+'[/B][/COLOR]',"sezon(url)",url,thumbnail)

        

def yabanci(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel=soup.find("div", {"id": "panel-2"})
        for a in panel.findAll('a',href=True,title=True):
                url=a['href']
                name=re.findall(r".*?dizihdtv.net/dizi-izle/(.*?)$", url)
                name=name[0].replace('-izle',"").replace('-'," ")
                thumbnail="http://dizihdtv.net/img/"+name.replace(" ","")+".png"
                name=name.capitalize()
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"sezonn(url)",url,thumbnail)

def sezon(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="diziadi"></div>\r\n                                                <div class=".*?">.*?</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src="(.*?)" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a>').findall(link)
        for url,thumbnail,name in match:
            #name1=re.findall(r".*?dizihdtv.net/(.*?)$", url)
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        page=re.compile('<span class="current">.+?</span><a href="http://dizihdtv.net/(.+?)" title="(.+?)">').findall(link)
        thumbnail="image/sonrakisayfa.jpg"
        for url,name in page:
                name="Sonraki Sayfa"
                url="http://dizihdtv.net/"+str(url)
                araclar.addDir(fileName,'[COLOR blue][B]>>>>>>'+name+'[/B][/COLOR]',"sezon(url)",url,thumbnail)

def sezonn(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="diziadi"></div>\r\n                                                <div class=".*?">.*?</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src="(.*?)" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a>').findall(link)
        for url,thumbnail,name in match:
            #name1=re.findall(r".*?dizihdtv.net/(.*?)$", url)
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        page=re.compile('<span class="current">.+?</span><a href="http://dizihdtv.net/(.+?)" title="(.+?)">').findall(link)
        thumbnail="image/sonrakisayfa.jpg"
        for url,name in page:
                name="Sonraki Sayfa"
                url="http://dizihdtv.net/"+str(url)
                araclar.addDir(fileName,'[COLOR blue][B]>>>>>>'+name+'[/B][/COLOR]',"sezonn(url)",url,thumbnail)
    
##    #name=re.findall(r".*?dizihdtv.net/dizi-izle/(.*?)$", url)
##    link=araclar.get_url(url)
##    match=re.compile('<a href=".*?"><img src="(.*?)"></a>\n<h2><a href="(.*?)">(.*?)</a>').findall(link)
##    for thumbnail,url,name in match:
##        #name=re.findall(r".*?dizihdtv.net/(.*?)$", url)
##        name=name.replace('&#8211;',";").replace('-'," ")
##       # name=name.capitalize()
##        araclar.addDir(fileName,'[COLOR blue][B]'+name+'[/B][/COLOR]',"video(name,url)",url,thumbnail)                       
        
##def xml_scanner(url):
##        link=araclar.get_url(url)
##        match=re.compile(' xmlAddress = \'(.*?)\'').findall(link)
##        for url2 in match:
##            idi=url2
##            print idi,url2
##            link=araclar.get_url(url2)
##            match=re.compile('file: "rtmpe://(.*?)/liveedge/(.*?)"\n').findall(link)
##            for rtmp,kanalname in match:
##                
##            value=[]
##            xmlScan=araclar.get_url(url)
##            xmlScan=xmlScan.replace("http://www.youtube.com/embed/g6gn1vHdjfw","").replace("http://www.youtube.com/watch?v=g6gn1vHdjfw","")
##            dizihd=re.compile('git=(.*?)"').findall(xmlScan)
##            face_1=re.compile('videoPath value="(.+?)"').findall(xmlScan)#xml ici face link
##            youtube_1=re.compile('v=(.*?)"').findall(xmlScan)#xml içi youtube link
##            dizimag=re.compile('url="(.*?)"').findall(xmlScan) #xml ici dizimag                               
##            music=re.compile('<file>(.*?)</file>').findall(xmlScan)
##            if len(youtube_1)> 0  :
##                    for i, url in enumerate(youtube_1):
##                            Url='http://www.youtube.com/embed/'+str(youtube_1[0])
##                            value.append(Url)
##            
##            if len(face_1)> 0:
##                    for i, url in enumerate(face_1):
##                            value.append(url)
##                            
##            if len(dizimag)> 0:
##                    for i, url in enumerate(dizimag):
##                            value.append(url)
##                           
##            if len(music)> 0  :
##                    for i, url in enumerate(music):
##                            value.append(url)
##                         
##            
##            return value
##        playList.clear()

def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR orange]>>>   [/COLOR] V Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
                 
        youtube=re.compile(' src="\/\/www.youtube.com\/embed\/(.*?)\?rel\=0"').findall(link)
        #youtube=re.compile('http:\/\/www.youtube.com\/embed\/(.*?)').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR lightblue]>>>   [/COLOR] Y Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('<iframe src=\'http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html\'').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                name='[COLOR beige][B][COLOR green]>>>   [/COLOR] V Server [/B][/COLOR]'
                urlList.append(url)
        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
