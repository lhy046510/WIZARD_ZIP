# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="FULLFILM"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        FULLFILM='http://www.filmifullizle.com/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "FULLFILMRecent(url)",FULLFILM,"yeni")
        link=araclar.get_url(FULLFILM)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" >(.*?)</a>\n</li>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR lightgreen][B][COLOR red]> [/COLOR]'+name+'[/B][/COLOR]', "FULLFILMRecent(url)",url,"")

def FULLFILMRecent(url):
        link=araclar.get_url(url)
        match1=re.compile('<div style="float: left;">\n<a href="(.*?)"><img src="(.*?)" alt="(.*?)" ').findall(link)
        for url,thumbnail,name in match1:
                name=name.replace('&#8211',' ').replace('&#8217',' ')
                name=name_fix(name)
                
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('<li class="active_page"><a href=".*?">.*?</a></li>\n<li><a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FULLFILMRecent(url)",url,"next")

def ayrisdirma(name,url):
        link=araclar.get_url(url)
        match1=re.compile('<div id="(.*?)"> B\xc3\xb6l\xc3\xbcm 1 <a').findall(link)
        for code in match1:
                code=''
                name='PART 1'
                url=url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match2=re.compile('<a href="(.*?)">B\xc3\xb6l\xc3\xbcm (.*?)</a>').findall(link)
        for url,name in match2:
                name='PART '+name
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match3=re.compile('>Fragman</a> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in match3:
                #name='Tek Part'
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match4=re.compile('>Tek.*?</a> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in match4:
                #name='Tek Part'
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match=re.compile('rel="nofollow"(.*?)">Part(.*?)</a>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]Vk -'+name+'  PART [/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match7=re.compile('onclick="(.*?)"><img src="http://resim.filmifullizle.com/fpaylas.jpg"').findall(link)
        for code in match7:
                code=''
                name='Diger Resolver'
                url=url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR red][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        	
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.filmifullizle.com/i.php?s='+query)
            FULLFILMRecent(url)

def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

		#---------------------------------------------#

        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

		#---------------------------------------------#

        mailru2=re.compile("src=\'http://videoapi.my.mail.ru/videos/embed/mail/(.*?).html").findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#

        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x
