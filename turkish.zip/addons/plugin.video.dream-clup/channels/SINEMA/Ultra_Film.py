# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Ultra_Film"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        FILMSAATI='http://www.ultrafilmizle.com/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "FILMSAATIRecent(url)",FILMSAATI,"yeni")
        link=araclar.get_url(FILMSAATI)
        match=re.compile(' class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.*?"><a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR lightblue][B][COLOR lightgreen]>  [/COLOR]'+name+'[/B][/COLOR]', "FILMSAATIRecent(url)",url,'')    
        
def FILMSAATIRecent(url):
        link=araclar.get_url(url)
        match=re.compile(' src="(.*?)" alt="(.*?)" height=".*?" width=".*?" /></a>\n<div class="movief"><a href="(.*?)">.*?</a>').findall(link)
        for t,name,url in match:
                name=name.replace('&#8211','').replace('&','')
                araclar.addDir(fileName,'[COLOR lightblue][B][COLOR lightgreen]>  [/COLOR]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,t)
        page=re.compile('class=\'current\'>.*?</span><a class="page larger" href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                name='[COLOR blue][B]'+'Sonraki Sayfa >>'+'[/B][/COLOR]'+'  '+name
                araclar.addDir(fileName,name, "FILMSAATIRecent(url)",url,'')

def ayrisdirma(name,url):
        link=araclar.get_url(url)
        match3=re.compile('</span>\t\t\t\t\t\t <span>Tek Par\xc3\xa7a(.*?)</span>').findall(link)
        for name in match3:
                name=name+' - TEK Parca'
                url=url
                #print name,url
                araclar.addDir(fileName,'[COLOR red][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,"")
        match1=re.compile('</span>                                     <span>(.*?).Par\xc3\xa7a</span>').findall(link)
        for name in match1:
                name=name+' Parca'
                url=url
                araclar.addDir(fileName,'[COLOR red][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,"")
        match=re.compile(' <a href="(.*?)"><span>(.*?)</span').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR red][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,"")

                
                

            
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.ultrafilmizle.com/?s='+query)
            FILMSAATIRecent(url)

def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        import cozucu
        link=link.replace('&amp;', '&').replace('&', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

        #---------------------------------------------#
        vk_2=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url=url.replace('#038;','')
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        #---------------------------------------------#

        youtube=re.compile('src="//www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        #---------------------------------------------#
        mailru2=re.compile("<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html").findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #---------------------------------------------#

        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('–', '-').replace('&', '&').replace('&amp;', '&')
        return x
