# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64,time
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Media64_EVRENSEL"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        ######
        url2='http://xbmctr.com/ahd.mp4'
        name2='[COLOR orange]~~~Reklami Izlediginiz Icin Tesekkür ederiz !!~~~[/COLOR]'
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name2,url2,'')
        listitem = xbmcgui.ListItem(name2)
        playList.add(url2, listitem)
        xbmcPlayer.play(playList)
        ######
        url='http://www.evrenselfilm.net/'
        link=araclar.get_url(url)
        match=re.compile('<li id="menu-item-.*?" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.*?"><a href="(.*?)">(.*?)</a></li>\n').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"evrenselfilmkategoriicerik(url)",url,'http://www.evrenselfilm.net/wp-content/themes/evrenselwp/img/evrenselfilmlogo.png')

def evrenselfilmkategoriicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" class=".*?">.*?</a></li>\n\n</ul>\n\n</div>\n\n</div>\n\n\n<div class=".*?">\n\n<div class=".*?"><img src="(.*?)" width=".*?" height=".*?" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match:
                name=name.replace('&#8211','').replace('&#8217','')
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        sayfalama=re.compile('<span class=\'current\'>.*?</span><a class="page larger" href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in sayfalama:
                name='Sonraki Sayfa'+' '+name 
                araclar.addDir(fileName,'[COLOR blue][B]'+name+'[/B][/COLOR]',"evrenselfilmkategoriicerik(url)",url,'http://www.evrenselfilm.net/wp-content/themes/evrenselwp/img/evrenselfilmlogo.png')

def ayris(url):
        urlList=[] 
        link=araclar.get_url(url)
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for code in vk_2:
                code=''
                #url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                name='Vk bulundu izle'
                araclar.addDir(fileName,'[COLOR lightyellow][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
                                #http://api.video.mail.ru/videos/embed/mail/robinroot/_myvideo/536.html
##        mailru=re.compile('http:\/\/videoapi.my.mail.ru\/videos\/embed/mail\/(.*?).html').findall(link)
##        for mailrugelen in mailru:
##                url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+str(mailrugelen)#+'&autoplay=0'
##                urlList.append(url)
##                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"cozucu.MailRu_Player(url)",url,'')
class Anapencere( xbmcgui.WindowXMLDialog ):
    def __init__( self, *args, **kwargs ):
        self.shut = kwargs['close_time'] 
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        xbmc.executebuiltin( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
        pass

    def setTableText(self, tab):
        self.tabText = tab
        
    def getTableText(self):
        return self.tabText     
        
                                       
    def onInit( self ):
 
        while self.shut > 0:
            xbmc.sleep(1000)
            self.shut -= 1
##        xbmc.Player().stop()
        self._close_dialog()

    
    def getLabel(self):
        """Returns the listitem label."""
        self.getControl(MESSAGE_TITLE).setLabel(self.getTableText()[''])

    def onFocus( self, controlID ): pass
    
    def onClick( self, controlID ): 
        if controlID == 12:
##            xbmc.Player().stop()
            self._close_dialog()
        if controlID == 7:
##            xbmc.Player().stop()
            self._close_dialog()

    def onAction( self, action ):
        if action in [ 5, 6, 7, 9, 10, 92, 117 ] or action.getButtonCode() in [ 275, 257, 261 ]:
##            xbmc.Player().stop()
            self._close_dialog()

    def _close_dialog( self ):
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        time.sleep( .4 )
        self.close()
        

def pencere():
    if xbmc.getCondVisibility('system.platform.ios'):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.atv"):           
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.linux"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.android"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.osx"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.windows"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    else:
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    ac.doModal()
    del ac


def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------# 
        urlList=[] 
        #---------------------------# 
        playList.clear() 
        link=araclar.get_url(url) 
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
  
        #---------------------------------------------# 
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for url in vk_2: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url)#
                try:
                        
                        time.sleep(30)
                        pencere()
                        time.sleep(2500)
                        pencere()
                except:
                        pass
        #---------------------------------------------# 
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link) 
        for url in youtube: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        youtube1=re.compile(' value="http://www.youtube.com/v/(.*?)\?.*?"').findall(link) 
        for url in youtube1: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url)
                
        mailru=re.compile('http:\/\/videoapi.my.mail.ru\/videos\/embed/mail\/(.*?).html').findall(link) 
        for mailrugelen in mailru: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url 
                cozucu.MailRu_Player(url) 

        #---------------------------------------------# 
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
        for videodgelen in video: 
                url =videogelen 
                cozucu.magix_player(name,url) 
        if not urlList: 
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
                print match 
                if match: 
                        for url in match: 
                                VIDEOLINKS(name,url) 
         
        if urlList: 
                Sonuc=playerdenetle(name, urlList) 
                for name,url in Sonuc: 
                        araclar.addLink(name,url,'') 
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='') 
                        listitem.setInfo('video', {'name': name } ) 
                        playList.add(url,listitem=listitem) 
                xbmcPlayer.play(playList) 
       
def playerdenetle(name, urlList): 
        value=[] 
        import cozucu 
        for url in urlList if not isinstance(urlList, basestring) else [urlList]: 
  
  
                if "mail.ru" in url: 
                    value.append((name,cozucu.MailRu_Player(url))) 
                      
        if  value: 
            return value 
