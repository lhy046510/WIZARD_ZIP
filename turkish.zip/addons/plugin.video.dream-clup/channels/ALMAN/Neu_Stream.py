# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Neu_Stream"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        FILMSAATI='http://neu-stream.com/'
        neukino='http://neu-stream.com/stuff/online_film/23'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B]Filme Suche - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Neue Filme [/B][/COLOR]', "FILMSAATIRecent(url)",FILMSAATI,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Neu KINO [/B][/COLOR]', "FILMSAATIRecent2(url)",neukino,"yeni")
        link=araclar.get_url(FILMSAATI)
        match=re.compile('id=".*?" valign="top"><a href="(.*?)" class="catName"><b>(.*?)</b>').findall(link)
        if match >10:
                del match[23]
                del match[22]
                #del match[21]
        

                for url,name in match:
                        name=name.replace('&#8211','').replace('&','')
                        url='http://neu-stream.com'+url
              
                
                        araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "FILMSAATIRecent2(url)",url,"")

def FILMSAATIRecent(url):
        link=araclar.get_url(url)
        match1=re.compile('Comments:.*?" href="(.*?)"><img width="170px" height="230px" src="(.*?)" alt="(.*?)" />').findall(link)
        for url,thumbnail,name in match1:
                name=name.replace('Stream','').replace('&','')
                url='http://neu-stream.com'+url
        
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('class=\'current\'>.*?</span><a class="page larger" href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Next Page >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FILMSAATIRecent(url)",url,'')

def FILMSAATIRecent2(url):
        link=araclar.get_url(url)
        match1=re.compile('href="(.*?)"><img alt="(.*?)" title=".*?" width=".*?" height=".*?" src="(.*?)" ').findall(link)
        for url,name,thumbnail in match1:
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('class="swchItemA"><span>.*?</span></b>  <a class="swchItem" href="(.*?)" onclick=".*?"><span>(.*?)</span>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Next Page >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FILMSAATIRecent2(url)",url,'')

def FILMSAATIRecent3(url):
        link=araclar.get_url(url)
        match1=re.compile('<a href=".*?">(.*?)</a></div><div class=".*?">\n<div align="center"><a href="(.*?)"><img width="170px" height="230px" src="(.*?)"').findall(link)
        for name,url,thumbnail in match1:
                name=name.replace('<b>','').replace('</b>','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('class="swchItemA"><span>.*?</span></b>  <a class="swchItem" href="(.*?)" onclick=".*?"><span>(.*?)</span>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Next Page >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FILMSAATIRecent2(url)",url,'')

def ayrisdirma(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)
        match3=re.compile('<a href="(.*?)" target="_blank"><img alt="(.*?)stream"').findall(link)
        if match3 >1:
                del match3[0]
                for url,name in match3:
                        name=name.replace('RR','')

                        araclar.addDir(fileName,'[COLOR red][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,"")


                
                

            
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://neu-stream.com/search/?q='+query+'&t=0')
            FILMSAATIRecent3(url)


