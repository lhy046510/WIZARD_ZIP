# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

#!/usr/bin/python
# -*- coding: utf-8 -*-         #print ""+url
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmkersco@gmail.com

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Sharp_ELECTRONIC"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


heygidi='http://xbmctr.com'

urll='aHR0cDovL2NyaWNmcmVlLnN4L2xpdmUv'

livet='special://home/addons/plugin.video.dream-clup/resources/images/livet.png'


hangii='aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20v'

itvhd='aHR0cDovL3R2Y2F0Y2h1cC1saXZlLmhscy5hZGFwdGl2ZS5sZXZlbDMubmV0L3R2Y2F0Y2h1cC0yMDEvc21pbDppdHZvbmVfZGVza193aWZpLnNtaWwvY2h1bmtsaXN0X2IxNjAwMDAwLm0zdTg='
itvhdt='aHR0cDovL3d3dy5pdHZtZWRpYS5jby51ay9jb21tb24vdGVtcGxhdGUvaW1hZ2VzL2l0di1sb2dvLnBuZw=='
bbconehd='aHR0cDovL3R2Y2F0Y2h1cC1saXZlLmhscy5hZGFwdGl2ZS5sZXZlbDMubmV0L3R2Y2F0Y2h1cC0yMDEvc21pbDpiYmNvbmVfZGVza193aWZpLnNtaWwvY2h1bmtsaXN0X2IxNjAwMDAwLm0zdTg='
bbconet='aHR0cDovL3BuZy0yLnZlY3Rvci5tZS9maWxlcy9pbWFnZXMvOC8wLzgwOTIxL2JiY19vbmVfdGh1bWIucG5n'

skylart='https://pbs.twimg.com/profile_images/413603704357392384/fpEWiU6t_400x400.jpeg'

def main():
        araclar.addDir(fileName,'[COLOR blue][B]>>[COLOR tomato] Sharp Electronic Repairs Can Be Found on Facebook, Happy Viewing [/B][/COLOR]','main()',heygidi,'special://home/addons/plugin.video.dream-clup/resources/images/Sharp_ELECTRONIC.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[COLOR violet] Sharp SPORTS [/B][/COLOR]','sharpsportss()',heygidi,'special://home/addons/plugin.video.dream-clup/resources/images/Sharp_Sports.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[COLOR yellow] Sharp Movies [/B][/COLOR]','sharpmovies()',heygidi,'special://home/addons/plugin.video.dream-clup/resources/images/Sharp_Movies.png')
        

def sharpsportss():
        hangi='aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20vbGl2ZS1mb290YmFsbC1vbi10di8='
        sking='http://www.streamking.org/menu.html'
        skylar='http://cricfree.tv/movie/sky-movies-action-live-stream.php'
        araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR tomato]Which Channel, Which MATCH[/B][/COLOR]','hangi(url)',(base64.b64decode(hangi)),'special://home/addons/plugin.video.dream-clup/resources/images/which.jpeg')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        araclar.addDir(fileName,'[COLOR lightblue][B]========>>> [/B][/COLOR][COLOR orange][B] All Sports Channels [COLOR lightblue][B] <<<========[/B][/COLOR]','sking(url)',sking,'special://home/addons/plugin.video.dream-clup/resources/images/hq.png')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[COLOR violet]Sky Channels [/B][/COLOR]','skylar(url)',skylar,skylart)
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        araclar.addDir(fileName,'[COLOR tomato][B]***** Live ON Matches *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        link=araclar.get_url(base64.b64decode(urll))
        match=re.compile('<td style="color:#7BA314;font-weight:bold; font-size: small" width=".*?" class="matchtime">(.*?)</td>\n\t\t\t\t\t\t\t<td style=".*?" width=".*?">(.*?)</td>\n\n\t\t\t\t\t\t\t\t<td width=".*?"> \t<img src=".*?" /></td>\n\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</table>\n\n\t\t\t\t\t\t<div style=".*?" class="hidden"><a target=\'_blank\' href=\'(.*?)\' ').findall(link)
        for saat,name,url in match:
            name=name+' '+'[COLOR beige]'+saat+'[COLOR yellow]'+' uk time zone[/COLOR]'
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]','icerik(name,url)',url,livet)

def skylar(url):#9
        link=araclar.get_url(url)
        match=re.compile('<button type=button onClick="location.href=\'(.*?).php\'"><b><img src="(.*?)"').findall(link)
        for url,t in match:
            name=url
            url='http://cricfree.tv/movie/'+url+'.php'
            t='http://cricfree.tv/movie/'+t
            name=name.replace('-',' ').replace('movies','').replace('live','').replace('stream','')
            araclar.addDir(fileName,'[COLOR lightblue][B] >> [/B][/COLOR][COLOR cyan][B]'+name+'[/B][/COLOR]','skylaricerik(name,url)',url,t)
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR moccasin][B] ITV [COLOR red]HD[/B][/COLOR]','yayin(name,url)',(base64.b64decode(itvhd)),(base64.b64decode(itvhdt)))
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR moccasin][B] BBC ONE [COLOR red]HD[/B][/COLOR]','yayin(name,url)',(base64.b64decode(bbconehd)),(base64.b64decode(bbconet)))
        

def skylaricerik(name,url):#91
        link=araclar.get_url(url)
        match=re.compile(' id="iframe" src="(.*?)" ').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile(' fid="(.*?)";').findall(link)
                for playpath in match:
                        #rtmpe://46.246.124.30:1935/live/ app=live/ playpath=thriller  swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive2.php?u=thriller&vw=620&vh=490&domain=cricfree.sx live=1
                        url='rtmpe://46.246.124.30:1935/live/ app=live/ playpath='+playpath+' swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive2.php?u='+playpath+'&vw=620&vh=490&domain=cricfree.sx live=1'
                        playList.clear()
                        araclar.addLink(name,url,livet)
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)
                        
def yayin(name,url):#3
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()

        araclar.addLink(name,url,'special://home/addons/plugin.video.dream-clup/resources/images/livet.png')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
##
##        dialog = xbmcgui.Dialog()
##        if dialog.yesno("Quality POLL", '', "Do You Like Quality?"):
##            path=loglocation()
##            import glob
##            for infile in glob.glob(os.path.join(path, 'xbmc_crashlog*.*')):
##                 File=infile
##                 print infile
##                 os.remove(infile)
##        dialog = xbmcgui.Dialog(e)
##        i = dialog.ok('Have Fun !!!', "[COLOR beige]Have Fun[/COLOR]","[COLOR pink] Have Fun.[/COLOR]")

def hangi(url):#5
        link=araclar.get_url(url)
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        match=re.compile('<span class="fixture"><a href="../(.*?)">\r\n                    (.*?)\r\n                    vs\r\n                    (.*?)</a></span> <span class="ground">\r\n                      \r\n                         (.*?)\r\n').findall(link)
        for url,bir,iki,saat in match:
            name='[COLOR beige]'+bir+'[COLOR lightblue] vs '+'[COLOR beige]'+iki+' '+'[COLOR yellow]'+saat
            url=base64.b64decode(hangii)+url
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]','hangikanal(url)',url,'')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        araclar.addDir(fileName,'[COLOR tomato][B]***** Live ON Matches *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        link=araclar.get_url(base64.b64decode(urll))
        match2=re.compile('<td style="color:#7BA314;font-weight:bold; font-size: small" width=".*?" class="matchtime">(.*?)</td>\n\t\t\t\t\t\t\t<td style=".*?" width=".*?">(.*?)</td>\n\n\t\t\t\t\t\t\t\t<td width=".*?"> \t<img src=".*?" /></td>\n\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</table>\n\n\t\t\t\t\t\t<div style=".*?" class="hidden"><a target=\'_blank\' href=\'(.*?)\' ').findall(link)
        for saat,name,url in match2:
            name=name+' '+'[COLOR beige]'+saat+'[COLOR yellow]'+' uk time zone[/COLOR]'
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]','icerik(name,url)',url,livet)

def hangikanal(url):#6
        sking='http://www.streamking.org/menu.html'
        araclar.addDir(fileName,'[COLOR lightblue][B]========>>> [/B][/COLOR][COLOR violet][B] If You Allready Know Which Channel is Your Game [COLOR lightblue][B] <<<========[/B][/COLOR]',"sking(url)",sking,'special://home/addons/plugin.video.dream-clup/resources/images/hq.png')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        link=araclar.get_url(url)
        match2=re.compile('<h2><a href=".*?"><img title=".*?" src=".*?" alt="" /></a>&nbsp;(.*?)&nbsp;<a href=".*?"><img title=".*?" src=".*?" alt="" /></a></h2>\r\n   \t<span class="live">Live on (.*?)</span>\r\n').findall(link)
        for bir,iki in match2:
                name=bir+'[COLOR lightblue] Live ON [COLOR lightgreen]'+iki+'[/COLOR]'

        match=re.compile('<div class="channel-logo"> <a href=""><img src="../(.*?)" alt=".*?"').findall(link)
        for t in match:
                t=(base64.b64decode(hangii))+t.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR] [COLOR orange][B]'+name+'[/B][/COLOR]', "main()",url,t)
        match1=re.compile('<div class="channel-logo"> <a href=".*?"><img src="../(.*?)" alt=".*?"').findall(link)
        for t in match1:
                t=(base64.b64decode(hangii))+t.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "main()",url,t)
        

def icerik(name,url):#7
        link=araclar.get_url(url)
        match=re.compile('<iframe frameborder="0" marginheight="0" marginwidth="0" height="490" src="(.*?)"').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile('fid=\'(.*?)\';').findall(link)
                for kanal in match:
                        #rtmp://31.220.0.103:1935/live playpath=sskk2 swfUrl=http://www.flashtv.co/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live=sskk2&vw=620&vh=490 live=1                        
                        url='rtmp://31.220.0.195:1935/live playpath='+kanal+' swfUrl=http://www.flashtv.co/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live='+kanal+'&vw=620&vh=490 live=1'
                        playList.clear()
                        araclar.addLink(name,url,livet)
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

def INFO():#8

    class AnaPencere(xbmcgui.Window): 
        def __init__(self):
            self.addControl(xbmcgui.ControlImage(200,100,720,480, 'special://home/addons/plugin.video.dream-clup/resources/images/ana.jpg'))
            xbmc.Player().play(song)
          

    W = AnaPencere()
    W.doModal()
    kapa = xbmc.Player().stop(song)
    del W, kapa

def sking(url):#11
        araclar.addDir(fileName,'[COLOR lightgreen][B] Selecet Your Channell [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)" target="_top">(.*?)</a></li>').findall(link)
        for url,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]',"skingicerik(name,url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/hq.png')
##        if match >0:
##                del match [8]
##                del match [7]
##                del match [6]
##                del match [5]
##                del match [4]
##                del match [3]
##                del match [2]
##                del match [1]
##                del match [0]
##                for url,name in match:
##                        araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]',url,12,'special://home/addons/plugin.video.dream-clup/resources/images/hq.png')

def skingicerik(name,url):#12
        link=araclar.get_url(url)
        match=re.compile('  src="(.*?)" ').findall(link)
        for url2 in match:
                url2='http://www.streamking.org/'+url2
                link=araclar.get_url(url2)
                match=re.compile(' fid="(.*?)";').findall(link)
                for playpath in match:
                        url='rtmpe://46.246.124.31:1935/live/ app=live/ playpath='+playpath+' swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive2.php?u='+playpath+'&vw=854&vh=480&domain=www.streamking.org live=1'
                        playList.clear()
                        #araclar.addLink(name,url,'special://home/addons/plugin.video.dream-clup/resources/images/livet.png')
                        araclar.addLink(name,url,livet)
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)
####################################################################################################################################################################################################
####################################################################################################################################################################################################
####################################################################################################################################################################################################
####################################################################################################################################################################################################
####################################################################################################################################################################################################
####################################################################################################################################################################################################

def sharpmovies():   
        url='http://afdah.com/'
        tvshows='http://afdah.com/category/watch-tv-shows/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Movie - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.jpg")
        link=araclar.get_url(url)
        match=re.compile('<li><a href="/genre/(.*?)/"><span>.*?</span></a></li>').findall(link)
        for url in match:
                name=url
                url='http://afdah.com/genre/'+url+'/'                
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','Yeni(url)',url,'special://home/addons/plugin.video.dream-clup/resources/images/Sharp_Movies.png')

def Yeni(url):#2
    link=araclar.get_url(url)
    match=re.compile('<img src="(.*?)s.jpg" width=".*?" height=".*?" alt="(.*?)" /></a></div><h3 class="entry-title"><a href="(.*?)"').findall(link)
    for t,name,url in match:
            t='http://afdah.com'+t+'.jpg'
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','ayris(url)',url,t)

    page=re.compile('<link rel=\'next\' href=\'(.*?)\'').findall(link) 
    for url in page:
            name='[COLOR purple][B]>> Sonraki Sayfa [/B][/COLOR]'
            araclar.addDir(fileName,name,'Yeni(url)',url,'')

def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://afdah.com/?s='+query+'&x=7&y=16&type=title')
            Yeni(url)

def Searchicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<img src="(.*?)" width="120" height="160" alt="(.*?)" /></a></div><h3 class="entry-title"><a href="(.*?)"').findall(link)
        for t,name,url in match:
                t='http://afdah.com'+t
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]','tvshowsayris(url)',url,'')

def tvshowsayris(url):#7
        link=araclar.get_url(url)
        match=re.compile('<iframe width="710" height="400" src="http:\/\/afdah.com\/embed(.*?)\/(.*?)" marginheight="0"').findall(link)
        for name,url in match:
                url='http://afdah.com/embed'+name+'/'+url
                name='Server '+ name
                araclar.addDir(fileName,name,'UrlResolver_Player(name,url',url,'')
        match1=re.compile('<iframe width="710" height="400" src="http:\/\/afdah.com\/trailer\/(.*?)" marginheight="0"').findall(link)
        for url in match1:
                url='http://afdah.com/trailer/'+url
                name='Trailer'
                araclar.addDir(fileName,name,'UrlResolver_Player(name,url)',url,'')

def ayris(url):#3
    link=araclar.get_url(url)    
    match=re.compile('<img src="/player/bullet.gif" border="0"> (.*?)</td><td style="text-align:center;">(.*?)</td><td style="width:100px;"><a rel="nofollow" href="(.*?)"').findall(link)
    for name,iki,url in match:
            name=name+'  '+'[COLOR orange]'+iki+'[/COLOR]'
            name=name.replace('.com','').replace('.net','').replace('.eu','').replace('.sx','').replace('.me','').replace('.is','').replace('.es','').replace('.in','')
            araclar.addDir(fileName,name,'UrlResolver_Player(name,url)',url,"http://afdah.com/player/play_video.gif")

def UrlResolver_Player(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul   
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)                
