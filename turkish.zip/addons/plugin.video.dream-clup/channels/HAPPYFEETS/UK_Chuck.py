# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="UK_Chuck"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul    
        url='http://afdah.com/'
        tvshows='http://afdah.com/category/watch-tv-shows/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Movie - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        link=araclar.get_url(url)
        match=re.compile('<li><a href="/genre/(.*?)/"><span>.*?</span></a></li>').findall(link)
        for url in match:
                name=url
                url='http://afdah.com/genre/'+url+'/'                
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','Yeni(url)',url,'')

def Yeni(url):#2
    link=araclar.get_url(url)
    match=re.compile('<img src="(.*?)s.jpg" width=".*?" height=".*?" alt="(.*?)" /></a></div><h3 class="entry-title"><a href="(.*?)"').findall(link)
    for t,name,url in match:
            t='http://afdah.com'+t+'.jpg'
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','ayris(url)',url,t)

    page=re.compile('<link rel=\'next\' href=\'(.*?)\'').findall(link) 
    for url in page:
            name='[COLOR purple][B]>> Sonraki Sayfa [/B][/COLOR]'
            araclar.addDir(fileName,name,'Yeni(url)',url,'')

def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://afdah.com/?s='+query+'&x=7&y=16&type=title')
            Yeni(url)

def Searchicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<img src="(.*?)" width="120" height="160" alt="(.*?)" /></a></div><h3 class="entry-title"><a href="(.*?)"').findall(link)
        for t,name,url in match:
                t='http://afdah.com'+t
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]','tvshowsayris(url)',url,'')

def tvshowsayris(url):#7
        link=araclar.get_url(url)
        match=re.compile('<iframe width="710" height="400" src="http:\/\/afdah.com\/embed(.*?)\/(.*?)" marginheight="0"').findall(link)
        for name,url in match:
                url='http://afdah.com/embed'+name+'/'+url
                name='Server '+ name
                araclar.addDir(fileName,name,'UrlResolver_Player(name,url',url,'')
        match1=re.compile('<iframe width="710" height="400" src="http:\/\/afdah.com\/trailer\/(.*?)" marginheight="0"').findall(link)
        for url in match1:
                url='http://afdah.com/trailer/'+url
                name='Trailer'
                araclar.addDir(fileName,name,'UrlResolver_Player(name,url)',url,'')

def ayris(url):#3
    link=araclar.get_url(url)    
    match=re.compile('<img src="/player/bullet.gif" border="0"> (.*?)</td><td style="text-align:center;">(.*?)</td><td style="width:100px;"><a rel="nofollow" href="(.*?)"').findall(link)
    for name,iki,url in match:
            name=name+'  '+'[COLOR orange]'+iki+'[/COLOR]'
            name=name.replace('.com','').replace('.net','').replace('.eu','').replace('.sx','').replace('.me','').replace('.is','').replace('.es','').replace('.in','')
            araclar.addDir(fileName,name,'UrlResolver_Player(name,url)',url,"http://afdah.com/player/play_video.gif")

def UrlResolver_Player(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul   
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
