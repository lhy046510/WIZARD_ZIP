# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys,time
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString

#---------------------------------------------------
web='aHR0cDovL3hibWN0ci5jb20vYmVzaXIv'

fileName="BESIR_EURO_TV"
#--------------- YENI KOMUTLAR  --------------------
# sayfa taratma --> araclar.get_url(url)
# klasor ekleme --> araclar.addDir(fileName,name, mode, url="", thumbnail="")
# link ekleme   --> araclar.addLink(name,url,thumbnail)
# videolink bulma --> urlList=cozucu.videobul(url)
# sonrasında     --> for url in urlList if not isinstance(urlList, basestring) else [urlList]:
#                               araclar.addlink(name,url,thumbnail) yada playList.add(url)
#---------------------------------------------------
        
def main():
        ######
        url2='http://xbmctr.com/ahd.mp4'
        name2='[COLOR orange]~~~Reklami Izlediginiz Icin Tesekkür ederiz !!~~~[/COLOR]'
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name2,url2,'')
        listitem = xbmcgui.ListItem(name2)
        playList.add(url2, listitem)
        xbmcPlayer.play(playList)
        ######
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Turkce Ulusual Kanallar[/B][/COLOR]', "BuildPage(code='tr',dil='TR.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/tr.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Deutsche Sender[/B][/COLOR]', "BuildPage(code='de',dil='DE.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/de.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Besir Filmler[/B][/COLOR]', "BuildPage(code='sn',dil='Sinema.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/sn.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Yabanci Kanallar[/B][/COLOR]', "BuildPage(code='muz',dil='yabanci.xml')",web,'http://www.volkanmakina.com.tr/FileUpload/bs438266/File/1-1.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Turkce Radyolar[/B][/COLOR]', "BuildPage(code='rdy',dil='Radyo.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/rdy.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Turkce Spor Kanallari[/B][/COLOR]', "BuildPage(code='spr',dil='SPOR.xml')",web,'http://www.tav-sanpark.com/images/spor_all.png')
        #araclar.addDir(fileName,__language__(30052), "BuildPage(code='dini',dil='ULUSAL.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/XBMCTRSPOR.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Cocuk Kanallari[/B][/COLOR]', "BuildPage(code='cocuk',dil='cocuk.xml')",web,'http://evdonaucity.wdfiles.com/local--files/news-2008-2009/VBSLogoKinder.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Muzik Kanallari[/B][/COLOR] ', "BuildPage(code='muz',dil='muz.xml')",web,'http://www.heridan.com/butonlar/mp3-muzik.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Dini Kanallar[/B][/COLOR] ', "BuildPage(code='muz',dil='dini.xml')",web,'http://www.abload.de/img/pic69001zqp8h.png')
                

def BuildPage(code,dil):
    a=0
    link=araclar.get_url(base64.b64decode(web)+dil)
    
    tr=re.compile('<item>\n.*?<title>(.*?)</title>\n.*?<link>(.*?)</link>\n.*?<thumbnail>(.*?)</thumbnail>\n.*?</item>').findall(link)
    de=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    sn=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    klp=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    rdy=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    spr=re.compile('<item>\n.*?<title>(.*?)</title>\n.*?<link>(.*?)</link>\n.*?<thumbnail>(.*?)</thumbnail>\n.*?</item>').findall(link)
    ulus=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    cocuk=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    muz=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    if code is 'tr':
#------------------------------------------------ 
         for videoTitle,Url,Thumbnail in tr:
              addVideoLink(videoTitle,Url,Thumbnail)
#------------------------------------------------
              ############
    else:
        pass
    if code is 'de':
          for videoTitle,Url,Thumbnail in de:
                  addVideoLink(videoTitle,Url,Thumbnail)
    else:
        pass
    if code is 'sn':
          for name,url,thumbnail in sn:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass
    if code is 'klp':
          for name,url,thumbnail in sn:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass
    if code is 'rdy':
          for videoTitle,Url,Thumbnail in sn:
                  addVideoLink(videoTitle,Url,Thumbnail)
    else:
        pass

    if code is 'spr':
          for videoTitle,Url,Thumbnail in spr:
               addVideoLink(videoTitle,Url,Thumbnail)
    else:
        pass

    if code is 'cocuk':
          for videoTitle,Url,Thumbnail in cocuk:
               addVideoLink(videoTitle,Url,Thumbnail)

    else:
        pass

    if code is 'muz':
            for videoTitle,Url,Thumbnail in muz:
               addVideoLink(videoTitle,Url,Thumbnail)

    else:
        pass
def yeni4(name,url):
        xbmcPlayer = xbmc.Player() 
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
        playList.clear() 
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name) 
        playList.add(url, listitem) 
        xbmcPlayer.play(playList)

######--BURADAN BASLIYOR-------------##### 
def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        link=link.replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xc3\xbc',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"?").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
        response.close()
        return link

def addFolder(FILENAME, videoTitle, method, url="", thumbnail="",fanart=""):
        u = sys.argv[0]+"?fileName="+urllib.quote_plus(FILENAME)+"&videoTitle="+urllib.quote_plus(videoTitle)+"&method="+urllib.quote_plus(method)+"&url="+urllib.quote_plus(url)+"&fanart="+urllib.quote_plus(fanart)
        if thumbnail != "":
                thumbnail = os.path.join(IMAGES_PATH, thumbnail+".png")
        liz = xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz.setProperty( "Fanart_Image", fanart )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    

def addVideoLink(linkTitle, url, thumbnail=""):
    liz = xbmcgui.ListItem(linkTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
    liz.setInfo(type="Video", infoLabels={"Title":linkTitle})
    liz.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
###BURAYA KADAR ####################################################




def INFO(url):
  try:
        #CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "www.xmbctr.com TEAM katkilariyla","Iyi seyirler dileriz...","Hazirlayan @Besir")
  except:
        #print "Hata olustu"
        pass 
