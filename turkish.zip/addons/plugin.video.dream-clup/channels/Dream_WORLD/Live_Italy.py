# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

#!/usr/bin/python
# -*- coding: utf-8 -*-         #print ""+url
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmkersco@gmail.com

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Live_Italy"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

ithumb='http://www.fornokia.net/data/programs/images/31790004_256x256-192x192__programView1_8225.jpg'

def main():
        hasbah='aHR0cDovLzAxLmdlbi50ci9IYXNCYWhDYV9JUFRWL2l0YWx5YS5tM3U='
        link=araclar.get_url(base64.b64decode(hasbah))
        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link)
        if match >0:
                del match[0]
                for name,url in match:
                        name=name.replace('mmsh','').replace('mms','')
                        araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]','oynat(name,url)',url,ithumb)

def oynat(name,url):#4
        playList.clear()        
        araclar.addLink(name,url,ithumb)
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList) 
                



