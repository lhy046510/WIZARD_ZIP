#
from BeautifulSoup import BeautifulSoup
import xbmc, xbmcgui, xbmcplugin, urllib2, urllib, re, string, sys, os, traceback, xbmcaddon
#from subprocess import call

__plugin__ = 'CTV'
__author__ = 'jacker <jacker@causal.ca>'
__url__ = 'http://www.causal.ca'
__svn_url__ = "https://www.causal.ca:8888/aur/xbmc/"
__date__ = '05-11-2011'
__version__ = '0.9.1'
__XBMC_Revision__ = xbmc.getInfoLabel('System.BuildVersion')
__settings__ = xbmcaddon.Addon( id = 'plugin.video.ctv' )


# debug level, 0 being silent, 2 being the more verbose
debug = 0
# enable "Play All" option
# its a bit of a hack and requires you also edit your playercorefactory.xml
# (it uses an external program to drive xbmc)
# thus False by default
hackEn = False

#
##
# Channels Data

chandata = [
	('ctv','CTV','watch.ctv.ca','esi.ctv.ca'),
	('tsn','TSN','watch.tsn.ca','esi.ctv.ca'),
	('thecomedynetwork','The Comedy Network','watch.thecomedynetwork.ca','esi.ctv.ca'),
	('discoverychannel','Discovery Channel','watch.discoverychannel.ca','esi.ctv.ca'),
	('space','Space','watch.spacecast.com','esi.ctv.ca'),
#	('muchmusic','Much Music','watch.muchmusic.com','esi.ctv.ca'),
	('bravo','Bravo','watch.bravo.ca','esi.ctv.ca')
]

def fullpath(img):
	return os.path.join(__settings__.getAddonInfo( 'path' ), img)

def getfanart(shortname):
	fanart = fullpath("fanart/"+shortname+".jpg")
	if(os.path.isfile(fanart)):
		return fanart
	else:
		return ''

# I wish it would let me use nested dicts, but apparently it wont,
# so I use this slightly more awkward data structure
cname  = {}
chost  = {}
cmhost = {}
cart   = {}
cimg   = {}
for i,n,h,m in chandata:
	cname[i]  = n
	chost[i]  = h
	cmhost[i] = m
	cart[i]   = getfanart(i)
	cimg[i]   = fullpath("imgs/"+i+".png")

#
##
# Controls

def open_url(url):
	req = urllib2.Request(url)
	content = urllib2.urlopen(req)
	data = content.read()
	content.close()
	return data

def build_site_directory():
	xbmcplugin.setPluginFanart(handle=int(sys.argv[1]), image=cart['ctv'])
	for i,n,h,m in chandata:
		addLink(n, h, 1, cimg[i], '', i, i, cart[i], True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)

def build_main_directory(host, mode):
	url = "http://"+chost[host]+"/AJAX/VideoLibraryContents.aspx"
	data = open_url(url)
	tree = BeautifulSoup(data, convertEntities=BeautifulSoup.HTML_ENTITIES)
	build_level1_dir(host, tree, "ShowID", mode, '')

#
##
def build_level(name, url, mode):
	# parse for channel
	urli = url.find(',')
	if(urli < 0):
		host = 'ctv'
	else:
		host = url[0:urli]
		url = url[urli+1:len(url)]
	# parse for the show shortname, used for fanart
	urli = url.find(',')
	if(urli < 0):
		shortname = ''
	else:
		shortname = url[0:urli]
		url = url[urli+1:len(url)]
		# if fan art exists for this shortname, set it as the default (ie. we must be in a show)
		fanart = getfanart(shortname)
		if(len(fanart) > 0):
			xbmcplugin.setPluginFanart(handle=int(sys.argv[1]),image=fanart)
	#
	if debug > 0:
		st = "mode:%d|name:%s|host:%s|shortname:%s|url:%s" % (mode, name, host, shortname, url)
		os.system("echo '"+st+"' >> /tmp/log.txt")
	#
	mode += 1
	if(mode == 2): #if mode 1
		build_main_directory(host, mode)
	else:
		# find out if we are at clip level (url will just be digits at that point)
		cid = re.compile('^\d+$').findall(url)
		cids = re.compile('^\d+:\d+[^\.]*$').findall(url)
		cidurl = re.compile('0:\S+$').findall(url)
		if len(cid) > 0:
			return build_play(url, host)
		elif len(cids) > 0:
			return build_playall(url)
		elif len(cidurl) > 0:
			return build_playurl(cidurl)
		else:
			data = open_url(url)
			soup = BeautifulSoup(data)
			tree=BeautifulSoup(data, convertEntities=BeautifulSoup.HTML_ENTITIES)
			leveltest = tree.find('div')
			if leveltest['class'] == 'Level1':
				build_level1_dir(host, tree, 'SeasonID', mode, shortname)
			elif leveltest['class'] == 'Level3':
				build_level3_dir(host, tree, name, url, shortname)
			else:
				build_level4_dir(host, name, url, shortname)
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)

#
##
def build_level1_dir(host, tree, idname, mode, shortname):
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
	menu = tree.find("div", { "id" : "Level1" }, {"class" : "Level1"})
	for x in menu.findAll('a'):
		vid = x.attrs[0][1]
		name = x.attrs[3][1]
		# url should be like
		# 'view-source:http://watch.ctv.ca/AJAX/VideoLibraryContents.aspx?GetChildOnly=true&SeasonID=1814'
		url = 'http://'+chost[host]+'/AJAX/VideoLibraryContents.aspx?GetChildOnly=true'
		url += '&'+idname+'='+vid
		# if its a show we have fanart for, we should add it in for each show selector
		if(idname == "ShowID"):
			shortname = name.replace(' ','').replace(':','').replace('"','').replace('\'','').replace('&','').replace('-','')
			shortname = shortname.replace('/','').replace('\\','').replace('#','').replace("@",'').replace('!','').replace('+','').lower()
			fanart = getfanart(shortname)
		else:
			# if we arent browsing shows, fanart should already be set as background image
			fanart = ''
		addLink(name, url, mode, '', '', host, shortname, fanart, True)

#
##
def build_level3_dir(host, tree, name, url, shortname):
	if debug > 2:
		os.system("echo ' beginning build level 3' >> /tmp/log.txt")
	# level 3 has a decent description and thumbnail as well (As level 4)
	img = {}
	plot = {}
	i=0
	for x in tree.findAll('img'):
		if len(x.attrs) == 1:
			img[i] = x.attrs[0][1]
			i=i+1
	if debug > 2:
		os.system("echo ' parsed imgs' >> /tmp/log.txt")
	i=0
	for x in tree.findAll('dd'):
		if x.attrs[0][1] == "Description":
			if x(text=True):
				plot[i] = x(text=True)[0]
			else:
				plot[i] = ""
			i=i+1
	if debug > 2:
		os.system("echo ' parsed plots' >> /tmp/log.txt")
	# ok final parse for major info
	i=0
	for x in tree.findAll('a', id=True):
		eppid = x.attrs[0][1]
		eppid = re.compile('Episode_(.*)').findall(eppid)
		url = 'http://'+chost[host]+'/AJAX/VideoLibraryContents.aspx?GetChildOnly=true&EpisodeID='+eppid[0]
		name = x.attrs[3][1]
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		addLink(name, url, mode, img[i], plot[i], host, shortname, '', True)
		i=i+1
	if debug > 2:
		os.system("echo ' completed level 3' >> /tmp/log.txt")

#
##
def build_level4_dir(host, name, url, shortname):
	xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	genre = name
	#change the url to "infinitescrolling" to get more items. NOTE: we can't use infinitescrolling in level 3 because it returns nothing
	#if there is zero level3 items
	showid = re.compile('ShowID=(.*)').findall(url)
	#try the InfiniteScrollingContents.aspx because it returns more items, but can't be used for 3 level videos.
	try:
		url = 'http://'+chost[host]+'/AJAX/InfiniteScrollingContents.aspx?ShowID='+showid[0]+'&NumberToGet=100&StartOffset=0'
	except:
		pass
	data = open_url(url)
	soup = BeautifulSoup(data)
	tree=BeautifulSoup(data, convertEntities=BeautifulSoup.HTML_ENTITIES)
	cids = {}
	i = 0
	for x in tree.findAll('dt'):
		url = x.a.attrs[0][1]
		cid = get_clipid(name, url)
		cids[i] = cid
		i += 1
	i = 0
	for x in tree.findAll('dt'):
		name = x.a(text=True)[0]
		plot = re.compile('Description:\'(.+?)\',').findall(x.a.attrs[1][1])[0]
		#if the plot contains slash apostropie, then we remove the slash. so that "it's" displays properly.
		plot = plot.replace('\\\'', '\'')
		image = re.compile(' Thumbnail:\'(.+?)\'').findall(x.a.attrs[1][1])[0]
		if(hackEn):
			url = cids[i]
			for j in range(i+1,len(cids)):
				url += ':'+cids[j]
			addLink(name, url, mode, image, '', host, shortname, '', False)
		else:
			addLink(name, cids[i], mode, image, '', host, shortname, '', False)
		i += 1
	if(hackEn):
		addLink("Play Episode Browser", "0:http://"+chost[host]+"/#clip"+cids[0], mode, image, '', host, shortname, '', False)
		addLink("Stop Play All", "0:0", mode, image, '', host, shortname, '', False)

#
##
def build_playall(url):
	url = "apr://"+url
	liz=xbmcgui.ListItem(path=url)
	return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	# could build a stack:// of urls, but what if they are time sensitive?
	# and i don't know if this works with swf type files or just avis/jpgs/mpgs

#
##
def build_play(cid, host):
	rtmp = get_rtmpe(cid, host)
	liz=xbmcgui.ListItem(path=rtmp)
	return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

#
##
def build_playurl(url):
	url = "aprx://web:"+url
	liz=xbmcgui.ListItem(path=url)
	return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

#
##
def get_clipid(name, url):
	##this section turns the http://watch.tsn.ca/featured/clip437575#clip437575 url into an rtmp and playpath
	#get the clip id from the url
	clipid = re.compile('#clip(.*)').findall(url)
	#and append that clip id onto the next url
	# not sure why its always ctv (even for say tsn feeds)
	return clipid[0]

#
##
def get_rtmpe(cid, host):
	tempurl = 'http://'+cmhost[host]+'/datafeed/urlgenjs.aspx?vid=' + cid
	#and open that tempurl
	data = open_url(tempurl)
	#get the entire rtmpe:// out of the contents of the esi.ctv.ca...
	temprtmpe = re.compile('Video.Load\({url:\'(.+?)\'').findall(data)
	#break that down into 3 parts so that we can build the final url and playpath
	firstpart = re.compile('rtmpe(.+?)ondemand/').findall(temprtmpe[0])
	# if it was already rmtp to begin with, next will fail
	if len(firstpart) != 0:
#		print "rtmpe url: '%s'" % temprtmpe
		firstpart = 'rtmp' + firstpart[0] + 'ondemand?ovpfv=2.1.4'
		secondpart = re.compile('.mp4\?(.+?)\'').findall(data)
		firstpart = firstpart + secondpart[0]
		playpath = re.compile('ondemand/(.+?).mp4').findall(temprtmpe[0])
		playpath = ' playpath=mp4:' + playpath[0]
		url = firstpart + playpath
	else:
#		url = temprtmpe
		url = temprtmpe[0]
	return url

#
##
#

def addLink(name, url, mode, thumbnail, plot, host, shortname, fanart, isDir):
	if(mode > 0):
		url = host+","+shortname+","+url
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
#	liz.setContent('tvshows')
	if(len(fanart) > 0):
		liz.setProperty('fanart_image', fanart)
	if(isDir):
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
	else:
		liz.setProperty('IsPlayable','true')
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
	return ok

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

# Main
if debug > 1:
	os.system("echo 'argv="+sys.argv[2]+"' >> /tmp/log.txt")
params=get_params()
url=None
name=None
mode=None
try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

#
##
#

if mode==None or url==None or len(url)<1:
	build_site_directory()
else:
	build_level(name, url, mode)

#
