# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os

def stream_decoder(url):
    req = urllib2.Request(url, headers={'X-Forwarded-For': '77.132.237.189','User-Agent': 'Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A403 Safari/8536.25' })
    f = urllib2.urlopen(req)
    try:
        html = f.read()
        f.close()
        rtmp = re.findall('urlLive : "(.*?)"',html)
        return rtmp[0]+'|X-Forwarded-For=77.132.237.189&amp;User-Agent=Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20rv%3A31.0)%20Gecko%2F20100101%20Firefox%2F31.0'
    except:
        return url
