# -*- encoding: utf-8 -*- 

import unittest
from czechtvPlugin import CzechtvPlugin, get_pg_num, date2label
from testPluginInterface import *
import re
import datetime


class TestCzechTVPlugin(unittest.TestCase):

    def setUp(self):
        self.iface = TestPluginInterface()
        self.plugin = CzechtvPlugin(self.iface)


    def test_root(self):
        self.plugin.call()
        self.assertEqual( len(self.iface.ITEMS), 5 )


    def test_date2label(self):
        d = datetime.datetime(year=2010, month=6, day=14)
        self.assertEqual(date2label(d), u'Po 14.6.2010')
        d = datetime.datetime(year=2010, month=6, day=15)
        self.assertEqual(date2label(d), u'Út 15.6.2010')
        d = datetime.datetime(year=2010, month=6, day=20)
        self.assertEqual(date2label(d), u'Ne 20.6.2010')


    def test_get_pg_num(self):
        self.assertEqual(get_pg_num('asdasd/3223-ads-34/'), None)
        self.assertEqual(get_pg_num('asdasd/37/34/'), '34')
        self.assertEqual(get_pg_num('asdasd/37/35'), '35')


    def test_root(self):
        self.plugin.call()
        self.assertEqual( len(self.iface.ITEMS), 3 )

        i = 0
        self.assertEqual(self.iface.ITEMS[i].label, u'Pořady podle abecedy')
        self.assertEqual(self.iface.ITEMS[i].call, 'listByName')
        self.assertEqual(self.iface.ITEMS[i].param, {})
        self.assertTrue(self.iface.ITEMS[i].isFolder)

        i += 1
        self.assertEqual(self.iface.ITEMS[i].label, u'Pořady podle data vysílání')
        self.assertEqual(self.iface.ITEMS[i].call, 'dateList')
        self.assertEqual(self.iface.ITEMS[i].param, {})
        self.assertTrue(self.iface.ITEMS[i].isFolder)

        i += 1
        self.assertEqual(self.iface.ITEMS[i].label, u'Pořady podle žánrů')
        self.assertEqual(self.iface.ITEMS[i].call, 'listByGenre')
        self.assertEqual(self.iface.ITEMS[i].param, {})
        self.assertTrue(self.iface.ITEMS[i].isFolder)


    def test_listByName(self):
        self.plugin.call('listByName')
        self.assertTrue( len(self.iface.ITEMS) > 20 )

        self.assertEqual(self.iface.ITEMS[0].label, u'A')
        self.assertEqual(self.iface.ITEMS[0].call, 'listPrograms')
        self.assertEqual(self.iface.ITEMS[0].param, {'path': '/ivysilani/a/'})
        self.assertTrue(self.iface.ITEMS[0].isFolder)

        self.assertEqual(self.iface.ITEMS[-2].label, u'#')
        self.assertEqual(self.iface.ITEMS[-2].call, 'listPrograms')
        self.assertEqual(self.iface.ITEMS[-2].param, {'path': '/ivysilani/!/'})
        self.assertTrue(self.iface.ITEMS[-2].isFolder)

        self.assertEqual(self.iface.ITEMS[-1].label, u'všechny')
        self.assertEqual(self.iface.ITEMS[-1].call, 'listPrograms')
        self.assertEqual(self.iface.ITEMS[-1].param, {'path': '/ivysilani/abeceda-vse/'})
        self.assertTrue(self.iface.ITEMS[-1].isFolder)


    def test_listByGenre(self):
        self.plugin.call('listByGenre')
        self.assertTrue( len(self.iface.ITEMS) > 5 )

        self.assertEqual(self.iface.ITEMS[0].label, u'Filmy')
        self.assertEqual(self.iface.ITEMS[0].call, 'listPrograms')
        self.assertEqual(self.iface.ITEMS[0].param, {'path': '/ivysilani/filmy/'})
        self.assertTrue(self.iface.ITEMS[0].isFolder)

        self.assertEqual(self.iface.ITEMS[-2].label, u'Náboženské')
        self.assertEqual(self.iface.ITEMS[-2].call, 'listPrograms')
        self.assertEqual(self.iface.ITEMS[-2].param, {'path': '/ivysilani/nabozenske/'})
        self.assertTrue(self.iface.ITEMS[-2].isFolder)

        self.assertEqual(self.iface.ITEMS[-1].label, u'všechny')
        self.assertEqual(self.iface.ITEMS[-1].call, 'listPrograms')
        self.assertEqual(self.iface.ITEMS[-1].param, {'path': '/ivysilani/zanr-vse/'})
        self.assertTrue(self.iface.ITEMS[-1].isFolder)


    def test_listPrograms_by_name(self):
        self.plugin.call('listPrograms', path='/ivysilani/a/')
        self.assertTrue( len(self.iface.ITEMS) > 10 )

        found = filter(lambda i: i.info['title'] == u'Abeceda hvězd',
                        self.iface.ITEMS)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].call, 'listEpizodes')
        self.assertEqual(found[0].param,
            {'path' : '/ivysilani/10097772488-abeceda-hvezd/'})
        self.assertEqual(found[0].label,
            u'Abeceda hvězd - Hudební féerie Vladimíra Hrona a\xa0jeho hostů')
        self.assertEqual(found[0].info['title'], u'Abeceda hvězd')
        self.assertEqual(found[0].info['plotoutline'],
            u'Hudební féerie Vladimíra Hrona a\xa0jeho hostů')
        self.assertTrue(found[0].isFolder)


    def test_listPrograms_by_genre(self):
        self.plugin.call('listPrograms', path='/ivysilani/filmy/')
        self.assertTrue( len(self.iface.ITEMS) > 10 )

        found = filter(lambda i: i.info['title'] == u'Pouta', self.iface.ITEMS)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].call, 'listEpizodes')
        self.assertEqual(found[0].param,
            {'path' : '/ivysilani/10215897121-pouta/'})
        self.assertEqual(found[0].label,
            u'Pouta - Thriller o\xa0temnotě a lásce, zničení a osvobození, vězení a útěku')
        self.assertEqual(found[0].info['title'], u'Pouta')
        self.assertEqual(found[0].info['plotoutline'],
            u'Thriller o\xa0temnotě a lásce, zničení a osvobození, vězení a útěku')
        self.assertTrue(found[0].isFolder)


    def test_listEpizodes_no_pages(self):
        """ list program with 3 epizodes (without pages and bonuses) """
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10097772488-abeceda-hvezd/')
        self.assertEqual( len(self.iface.ITEMS), 3 )
        
        first = self.iface.ITEMS[0]
        self.assertEqual( first.label, '12. 4. 2007 - E, C, T, O, I a V' )
        self.assertEqual( first.call, 'play' )
        self.assertEqual( first.param,
                            {'path': '/ivysilani/10097772488-abeceda-hvezd/20752216143/'} )
        self.assertEqual( first.info['title'], '12. 4. 2007' )
        self.assertEqual( first.info['date'], '12. 4. 2007' )
        self.assertEqual( first.info['plotoutline'], 'E, C, T, O, I a V' )
        self.assertTrue( re.match(r'^http://.*ceskatelevize.cz/.*\.jpg$', first.iconURL) )
        self.assertFalse( first.isFolder )

        last = self.iface.ITEMS[-1]
        self.assertEqual( last.label, '8. 2. 2007 - K a G' )
        self.assertEqual( last.call, 'play' )
        self.assertEqual( last.param,
                            {'path': '/ivysilani/10097772488-abeceda-hvezd/206522161410007/'} )
        self.assertEqual( last.info['title'], '8. 2. 2007' )
        self.assertEqual( last.info['date'], '8. 2. 2007' )
        self.assertEqual( last.info['plotoutline'], 'K a G' )
        self.assertTrue( re.match(r'^http://.*ceskatelevize.cz/.*\.jpg$', last.iconURL) )
        self.assertFalse( last.isFolder )


    def test_listEpizodes_pages(self):
        """ list program with many epizodes with paging (without bonuses) """
        self.plugin.call('listEpizodes',
            path='/ivysilani/1096898594-udalosti-komentare/209411000371230/dalsi-casti/10/')
        self.assertEqual( len(self.iface.ITEMS), 6 )

        first = self.iface.ITEMS[0]
        self.assertTrue( re.match(u'^Další strana \(11 z \d+\)$', first.label) )
        self.assertEqual( first.call, 'listEpizodes' )
        self.assertTrue( re.search('/ivysilani/1096898594-udalosti-komentare/[0-9]+/dalsi-casti/11/',
                                    first.param['path']) )
        self.assertTrue( first.isFolder )

        second = self.iface.ITEMS[1]
        self.assertTrue( re.match('^\d+\. \d+\. \d{4}$', second.info['title']) )
        self.assertTrue( re.match('^\d+\. \d+\. \d{4}$', second.info['date']) )
        self.assertTrue( second.info['plotoutline'] )
        self.assertEqual( second.label,
                    second.info['title'] + ' - ' + second.info['plotoutline'] )
        self.assertEqual( second.call, 'play' )
        self.assertTrue( second.param.has_key('path') )
        self.assertFalse( second.isFolder )

        last = self.iface.ITEMS[-1]
        self.assertTrue( re.match('^\d+\. \d+\. \d{4}$', last.info['title']) )
        self.assertTrue( re.match('^\d+\. \d+\. \d{4}$', last.info['date']) )
        self.assertTrue( last.info['plotoutline'] )
        self.assertEqual( last.label,
                    last.info['title'] + ' - ' + last.info['plotoutline'] )
        self.assertEqual( last.call, 'play' )
        self.assertTrue( last.param.has_key('path') )
        self.assertFalse( last.isFolder )

        self.assertNotEqual( second.label, last.label )
        self.assertNotEqual( second.info['title'], last.info['title'] )
        self.assertNotEqual( second.info['plotoutline'], last.info['plotoutline'] )
        self.assertNotEqual( second.info['date'], last.info['date'] )
        self.assertNotEqual( second.param['path'], last.param['path'] )


    def test_listEpizodes_last_page(self):
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10169475861-co-tyden-vzal/208522161000025/')
        self.assertEqual( len(self.iface.ITEMS), 6 )

        first = self.iface.ITEMS[0]
        self.assertTrue( first.label, '^Další strany (2 z 5)$' )
        self.assertEqual( first.call, 'listEpizodes' )
        self.assertTrue( first.param,
            {'path': '/ivysilani/10169475861-co-tyden-vzal/208522161000025/dalsi-casti/2/'} )
        self.assertTrue( first.isFolder )

        # get last page:
        self.iface.cleanup()
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10169475861-co-tyden-vzal/208522161000025/dalsi-casti/5/')
        self.assertTrue( len(self.iface.ITEMS) > 1 )

        first = self.iface.ITEMS[0]
        self.assertEqual( first.call, 'play' )
        self.assertFalse( first.isFolder )


    def test_listEpizodes_one(self):
        """ list progrem with singe epizode (no bonuses) """
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10168936145-atlet-roku-2008/')
        self.assertEqual( len(self.iface.ITEMS), 1 )
        
        item = self.iface.ITEMS[0]
        self.assertEqual( item.label, u'Atlet roku 2008 - 8. 11. 2008')
        self.assertEqual( item.call, 'play' )
        self.assertEqual( item.param,
            {'path': '/ivysilani/10168936145-atlet-roku-2008/dalsi-casti'} )
        self.assertEqual( item.info['title'], 'Atlet roku 2008' )
        self.assertEqual( item.info['date'], '8. 11. 2008' )
        self.assertEqual( item.info['plotoutline'], '8. 11. 2008' )
        self.assertEqual( item.info['plot'], u'Přenos velké zábavně-hudebně-sportovní show' )
        self.assertFalse( item.isFolder )


    def test_getProgram_with_bonuses(self):
        """ list program with epizodes and bonuses """
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10267292848-7-divu-ceska/')
        self.assertTrue( len(self.iface.ITEMS) > 2 )

        first = self.iface.ITEMS[0]
        self.assertEqual( first.label, 'Bonusy' )
        self.assertEqual( first.call, 'listEpizodes' )
        self.assertEqual( first.param,
                    {'path': '/ivysilani/10267292848-7-divu-ceska/21052216076/bonusy'} )
        self.assertTrue( first.isFolder )


    def test_getProgram_no_epizodes(self):
        """ list program with only bonuses """
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10215897121-pouta/')
        self.assertEqual( len(self.iface.ITEMS), 1 )

        first = self.iface.ITEMS[0]
        self.assertEqual( first.label, 'Bonusy' )
        self.assertEqual( first.call, 'listEpizodes' )
        self.assertEqual( first.param,
                    {'path': '/ivysilani/10215897121-pouta/40823310010/bonusy'} )
        self.assertTrue( first.isFolder )


    def test_getProgram_list_bonuses(self):
        self.plugin.call('listEpizodes',
                        path='/ivysilani/10215897121-pouta/bonusy')
        self.assertTrue( len(self.iface.ITEMS) > 2 )

        self.assertFalse( self.iface.ITEMS[0].isFolder )

        item = filter(lambda e:e.info['title'] == u'Trailer', 
                        self.iface.ITEMS)[0]
        self.assertEqual( item.label, 'Trailer' )
        self.assertEqual( item.call, 'play' )
        self.assertEqual( item.param,
                {'path': '/ivysilani/10215897121-pouta/40823310010/bonusy/589-trailer/'} )
        self.assertEqual( item.info['title'], 'Trailer' )
        self.assertEqual( item.info['plotoutline'], '' )
        self.assertTrue( re.match(r'^http://.*ceskatelevize.cz/.*\.jpg$', item.iconURL) )
        self.assertFalse( item.isFolder )


    def test_dateList_base(self):
        self.plugin.call('dateList')
        self.assertEqual( len(self.iface.ITEMS), 31 )

        first = self.iface.ITEMS[0]
        today = datetime.date.today()
        prev_month = today - datetime.timedelta(days=30)
        self.assertEqual( first.label,
                    u'Předchozí měsíc ('+date2label(prev_month)+')' )
        self.assertEqual( first.call, 'dateList' )
        self.assertEqual( first.param,
                    { 'date': prev_month.strftime('%d.%m.%Y') })
        self.assertTrue( first.isFolder )

        second = self.iface.ITEMS[1]
        self.assertEqual( second.label, date2label(today) )
        self.assertEqual( second.call, 'dayChannelList' )
        self.assertEqual( second.param,
                    { 'date': today.strftime('%d.%m.%Y') })
        self.assertTrue( second.isFolder )


    def test_dateList_param(self):
        self.plugin.call('dateList', date='12.03.2010')
        self.assertEqual( len(self.iface.ITEMS), 31 )

        first = self.iface.ITEMS[0]
        self.assertEqual( first.label, u'Předchozí měsíc (St 10.2.2010)' )
        self.assertEqual( first.call, 'dateList' )
        self.assertEqual( first.param, {'date': '10.02.2010'} )
        self.assertTrue( first.isFolder )

        second = self.iface.ITEMS[1]
        self.assertEqual( second.label, u'Pá 12.3.2010' )
        self.assertEqual( second.call, 'dayChannelList' )
        self.assertEqual( second.param, { 'date': '12.03.2010' })
        self.assertTrue( second.isFolder )

        item = self.iface.ITEMS[3]
        self.assertEqual( item.label, u'St 10.3.2010' )
        self.assertEqual( item.call, 'dayChannelList' )
        self.assertEqual( item.param, { 'date': '10.03.2010' })
        self.assertTrue( item.isFolder )

        last = self.iface.ITEMS[-1]
        self.assertEqual( last.label, u'Čt 11.2.2010' )
        self.assertEqual( last.call, 'dayChannelList' )
        self.assertEqual( last.param, { 'date': '11.02.2010' })
        self.assertTrue( last.isFolder )


    def test_dayChannelList_base(self):
        self.plugin.call('dayChannelList', date='23.11.2009')
        self.assertEqual( len(self.iface.ITEMS), 5 )

        first = self.iface.ITEMS[0]
        self.assertEqual(first.label, u'ČT1')
        self.assertEqual(first.call, 'dayProgramList')
        self.assertEqual(first.param, {'date': '23.11.2009', 'chnum': 0})
        self.assertTrue( re.match(r'^http://.*', first.iconURL) )
        self.assertTrue(first.isFolder)
        
        last = self.iface.ITEMS[-2]
        self.assertEqual(last.label, u'ČT4')
        self.assertEqual(last.call, 'dayProgramList')
        self.assertEqual(last.param, {'date': '23.11.2009', 'chnum': 3})
        self.assertTrue( re.match(r'^http://.*', last.iconURL) )
        self.assertTrue(last.isFolder)

        last = self.iface.ITEMS[-1]
        self.assertEqual(last.label, u'iVysílání Extra')
        self.assertEqual(last.call, 'dayProgramList')
        self.assertEqual(last.param, {'date': '23.11.2009', 'chnum': 4})
        self.assertTrue( re.match(r'^http://.*', last.iconURL) )
        self.assertTrue(last.isFolder)


    def test_dayChannelList_with_extra(self):
        self.plugin.call('dayChannelList', date='24.11.2009')
        self.assertEqual( len(self.iface.ITEMS), 5 )

        first = self.iface.ITEMS[0]
        self.assertEqual(first.label, u'ČT1')
        self.assertEqual(first.call, 'dayProgramList')
        self.assertEqual(first.param, {'date': '24.11.2009', 'chnum': 0})
        self.assertTrue( re.match(r'^http://.*', first.iconURL) )
        self.assertTrue(first.isFolder)
        
        last = self.iface.ITEMS[-1]
        self.assertEqual(last.label, u'iVysílání Extra')
        self.assertEqual(last.call, 'dayProgramList')
        self.assertEqual(last.param, {'date': '24.11.2009', 'chnum': 4})
        self.assertTrue( re.match(r'^http://.*', last.iconURL) )
        self.assertTrue(last.isFolder)


    def test_listChannelPrograms(self):
        self.plugin.call('dayProgramList', date='24.11.2009', chnum=1)  # CT2
        self.assertTrue( len(self.iface.ITEMS) > 10 )

        self.assertEqual( self.iface.ITEMS[2].label, '08:30 - Panorama' )
        self.assertEqual( self.iface.ITEMS[2].call, 'play' )
        self.assertEqual( self.iface.ITEMS[2].param,
                    {'path': '/ivysilani/10215161238-panorama/209263306000328/'} )
        self.assertEqual( self.iface.ITEMS[2].info['title'], u'Panorama' )
        self.assertEqual( self.iface.ITEMS[2].info['date'], '24.11.2009' )
        self.assertEqual( self.iface.ITEMS[2].info['time'], '08:30' )
        self.assertEqual( self.iface.ITEMS[2].info['plotoutline'], '' )

        self.assertEqual( self.iface.ITEMS[3].label,
                            '09:10 - Kosmopolis - Grafitti' )
        self.assertEqual( self.iface.ITEMS[3].param,
                    {'path': '/ivysilani/1095908415-kosmopolis-velky-vuz/209562210300027-kosmopolis/'} )
        self.assertEqual( self.iface.ITEMS[3].info['title'], 'Kosmopolis' )
        self.assertEqual( self.iface.ITEMS[3].info['date'], '24.11.2009' )
        self.assertEqual( self.iface.ITEMS[3].info['time'], '09:10' )
        self.assertEqual( self.iface.ITEMS[3].info['plotoutline'], 'Grafitti' )


    def test_play(self):
        self.plugin.call('play', path='/ivysilani/10097772488-abeceda-hvezd/')
        self.assertEqual( len(self.iface.ITEMS), 0 )

        self.assertEqual( self.iface.LOG[0], 
            "log DEBUG get_program_info on path:"
                + " '/ivysilani/10097772488-abeceda-hvezd/'")

        self.assertTrue( re.match("^log DEBUG play_stream u?'rtmp://[^ ]+ playpath=mp4:",
                            self.iface.LOG[1]) )

        self.assertEqual( self.iface.LOG[2][0], 'play' )
        self.assertTrue( re.match('^rtmp://[^ ]+ playpath=mp4:', self.iface.LOG[2][1]) )

        item = self.iface.LOG[2][2]
        self.assertEqual( item.label, u'Abeceda hvězd - 12. 4. 2007' )
        self.assertEqual( item.info['title'], u'Abeceda hvězd' )
        self.assertEqual( item.info['date'], '12. 4. 2007' )
        self.assertEqual( item.info['plotoutline'], '12. 4. 2007' )
        self.assertEqual( item.info['plot'], 'E, C, T, O, I a V' )
        self.assertFalse( item.isFolder )
        


if __name__ == '__main__':
    unittest.main()
