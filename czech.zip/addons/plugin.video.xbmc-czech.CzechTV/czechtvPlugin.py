# -*- encoding: utf-8 -*- 
""" CzechTV plugin for accessing www.ceskatelevize.cz videos from XBMC """

__all__ = ["CzechtvPlugin"]

from basePlugin import *
import re
import time
import datetime
import urllib2
import json

DATE_FORMAT = '%d.%m.%Y'
DAY_NAME = (u'Po', u'Út', u'St', u'Čt', u'Pá', u'So', u'Ne')

RE_DATE   = re.compile('(\d{1,2}\.\s*\d{1,2}\.\s*\d{4})')
RE_PGNUM  = re.compile('/(\d+)/?$')
#RE_PLAYLIST_URL = re.compile('flashvars.playlistURL *= *["\']([^"\']*)["\']')
RE_PLAYLIST_URL = re.compile('callSOAP\((.+?)\)')


def date2label(date):
    """ Generate label for date """
    dayname = DAY_NAME[date.weekday()]
    return "%s %s.%s.%s" % (dayname, date.day, date.month, date.year)


def get_pg_num(path):
    """ Get page number from url/path """
    m = RE_PGNUM.search(path)
    if m:
        return m.group(1)

def strToDict(inStr, keyList, sep=''):
    rxPieces = [pc + sep + '(.*?)' for pc in keyList]
    rx = re.compile(''.join(rxPieces) + '$')
    match = rx.match(inStr)
    return dict(zip(kl, match.groups()))

def http_build_query(params, topkey = ''):
    from urllib import quote_plus
    
    if len(params) == 0:
       return ""
 
    result = ""

    # is a dictionary?
    if type (params) is dict:
       for key in params.keys():
           newkey = quote_plus (key)
           
           if topkey != '':
              newkey = topkey + quote_plus('[' + key + ']')
           
           if type(params[key]) is dict:
              result += http_build_query (params[key], newkey)

           elif type(params[key]) is list:
                i = 0
                for val in params[key]:
                    if type(val) is dict:
                       result += http_build_query (val, newkey + '[' + str(i) + ']')

                    else:
                       result += newkey + quote_plus('[' + str(i) + ']') + "=" + quote_plus(str(val)) + "&"

                    i = i + 1              

           # boolean should have special treatment as well
           elif type(params[key]) is bool:
                result += newkey + "=" + quote_plus(str(int(params[key]))) + "&"

           # assume string (integers and floats work well)
           else:
                try:
                  result += newkey + "=" + quote_plus(str(params[key])) + "&"       # OPRAVIT ... POKUD JDOU U params[key] ZNAKY > 128, JE ERROR, ALE FUNGUJE TO I TAK
                except:
                  result += newkey + "=" + quote_plus("") + "&"  

    # remove the last '&'
    if (result) and (topkey == '') and (result[-1] == '&'):
       result = result[:-1]       
  
    return result
  
  
class CzechTVProgram:
    LOGPREFIX = "[CzechTV plugin] "
    bonusy = False
    bonusyPath = None

    def __init__(self, api, path):
        self.api = api
        self.path = path

        if '/bonusy' in self.path:
            self.bonusy = True
        elif '/dalsi-casti' not in self.path:
            self.path = re.sub(r'/*(?=([?].*)?$)', '/dalsi-casti', self.path, 1)
            self.path = self.path.replace('//','/')

        self.api.wget.request(self.api.BASE_URL + self.path)
        self.page = self.api.wget.select('div.mainPanel')
        if not self.page:
            raise Exception('div.mainPanel not found')

        if not self.bonusy:
            for tab_a in self.page.select('#programmeTabBox li a'):
                if tab_a.text == u'Bonusy':
                    self.bonusyPath = tab_a['href']
                    break

        self.info_div = self.api.wget.select('div#programmeDetail')
        if not self.info_div:
            raise Exception('div#programmeDetail not found')


    def getInfo(self):
        info = {
                'title': self.info_div.select_first('#programmeInfoDetail h2').text.strip(),
                'plotoutline': self.info_div.select_first('#programmeInfoDate strong').text,
            }
        # add plot
        p_tag = self.info_div.select_first('div#programmeInfoDetail h2 + p')
        if p_tag:
            info['plot'] = p_tag.text.strip()
        # add date 
        m = RE_DATE.search( info['plotoutline'] )
        if m:
            info['date'] = m.group(1)
        # icon url 
        img = self.info_div.select_first('li.active a.itemImage img')
        optargs = {}
        if img:
            optargs['iconURL'] = img['src']
        # label 
        label = info['title']
        if info['plotoutline']:
            label += ' - ' + info['plotoutline']

        error_screen = self.page.select_first('#errorScreen')
        if error_screen:
            if u'Vybraná část není v iVysílání k dispozici.' in error_screen.text:
                return None
            if u'U zvoleného pořadu si můžete přehrát pouze bonusy' in error_screen.text:
                return None

        return PItem(label,
                    info=info, 
                    call='play',
                    param={'path': self.path},
                    **optargs
                )


    def getEpizodeList(self):
        content = self.page.select('div.contentBox')
        list_title = u'Další části'
        if self.bonusy:
            list_title = u'Bonusy'
        active_tab = content.select_first('#programmeTabBox li.active')
        if not active_tab or active_tab.text != list_title:
            return # no epizodes/bonuses tab found

        for item in content.select('li.itemBlock'):
            # description
            plotoutline = ''
            for p in item.select('p'):
                if p.text and not p.get('class') and p.contents:
                    plotoutline += ' ' + unicode(p.contents[0]).strip()

            h3_a = item.select_first('h3 a')
            info = {
                    'title': h3_a.text.strip(),
                    'plotoutline': plotoutline.strip(),
                }
            # add date 
            m = RE_DATE.search( info['title'] )
            if m:
                info['date'] = m.group(1)
            # icon url 
            img = item.select_first('.itemImage img')
            optargs = {}
            if img:
                optargs['iconURL'] = img['src']
            # label 
            label = info['title']
            if info['plotoutline']:
                label += ' - ' + info['plotoutline']

            yield PItem(label,
                        info=info,
                        call='play',
                        param={'path': h3_a['href']},
                        **optargs
                    )


    def getPageLinks(self):
        links = self.page.select('.contentBox .pagingContent')
        out = {}
        if links:
            for key in ['first', 'prev', 'next', 'last']:
                pg_link = links.select_first('a.'+key)
                if pg_link:
                    out[key] = pg_link['href']
        return out


    def playlistURL(self):
        player_div = self.page.select_first('div#programmePlayer')
        if not player_div:
            raise Exception("div#programmePlayer not found!\n Path: %r" \
                                % (self.path, ))
        m = RE_PLAYLIST_URL.search(str(player_div))
        if not m:
            raise Exception("RE_PLAYLIST_URL not found in script %r on path: %r" \
                                % (player_div, self.path) )

        return m.group(1)


    def getStreamURL(self):
        # Converting text to dictionary
        query = json.loads(self.playlistURL())
        # Converting dictionary to text arrays    options[UserIP]=xxxx&options[playlistItems][0][..]....
        strquery = http_build_query(query)
        # Ask a link page XML
        request = urllib2.Request('http://www.ceskatelevize.cz/ajax/playlistURL.php', strquery)
        con = urllib2.urlopen(request)
        # Read lisk XML page
        data = con.read()
        con.close()

        # Parse XML page
        self.api.wget.request(data)
        for e in self.api.wget.select('switchitem'):
            if 'AD' in e['id']:
                continue # probably advert - skip it

            base_url = e['base']
            video_src = e.select_first('video')['src']
            return '%s/%s' % (base_url, video_src)    #%s playpath=%s             - UPRAVA %s/%s
        raise Exception("StreamURL not found!\nContent: "
                            + self.api.wget.content)


class CzechtvPlugin(BasePlugin):
    """ CzechTV plugin class """
    BASE_URL = "http://www.ceskatelevize.cz"


    @plugin_folder
    def root(self):
        """ plugin root folder """
        self.core.setSorting('NONE')
        yield PFolder(u'Pořady podle abecedy', call='listByName')
        yield PFolder(u'Pořady podle data vysílání', call='dateList')
        yield PFolder(u'Pořady podle žánrů', call='listByGenre')


    @plugin_folder
    def listByName(self, listID='programmeAlphabet'):
        """ List alphabet links """
        self.core.setSorting('NONE')

        url = self.BASE_URL + '/ivysilani/podle-abecedy/'
        self.wget.request(url)

        for a in self.wget.select("ul#%s li a" % listID):
            href = a.get('href')
            yield PFolder( a.text.strip(), call='listPrograms', \
                            param={'path': href})


    @plugin_folder
    def listByGenre(self):
        """ list genre links """
        self.listByName(listID='programmeGenre')


    @plugin_folder
    def listPrograms(self, path):
        """ List programs on given path """
        self.core.setSorting('NONE')

        url = self.BASE_URL + path
        self.wget.request(url)

        for a in self.wget.select("#programmeAlphabetContent a"):
            info = {
                    'title': a.text.strip(),
                    'plotoutline': a.get('title', '').strip(),
                }
            # label:
            label = info['title']
            if info['plotoutline']:
                label += ' - ' + info['plotoutline']
            yield PFolder(
                    label   = label,
                    call    = 'listEpizodes',
                    param   = {'path': a['href']},
                    info    = info,
                )


    @plugin_folder
    def listEpizodes(self, path):
        """ List program epizodes or bonuses """
        self.core.setSorting('NONE')
        
        prog = CzechTVProgram(self, path)
        epizodes = list( prog.getEpizodeList() )
        pages = prog.getPageLinks()

        # Add link to next page:
        if epizodes and pages.get('next'):
            if pages.get('next'):
                next_num = get_pg_num( pages['next'] )
                last_num = get_pg_num( pages['last'] )
                yield PFolder(u'Další strana (%s z %s)' % (next_num, last_num),
                                call='listEpizodes',
                                param={'path': pages['next']}
                            )

        # Add link to bonuses:
        if prog.bonusyPath:
            yield PFolder('Bonusy',
                        call='listEpizodes', 
                        param={'path': prog.bonusyPath}
                    )

        if epizodes:
            for item in epizodes:
                yield item
        else:
            item = prog.getInfo()
            if item:
                yield item


    @plugin_folder
    def dateList(self, date=None):
        """ Date-list for "list program by date" """
        self.core.setSorting('NONE')

        if date:
            date = datetime.date( *time.strptime(date, DATE_FORMAT)[:3] )
        else:
            date = datetime.date.today()

        # Add link to previous month virtual folder 
        pdate = date - datetime.timedelta(days=30)
        yield PFolder(u'Předchozí měsíc (%s)' % date2label(pdate),
                        call = 'dateList',
                        param = {'date': pdate.strftime(DATE_FORMAT)}
                    )
                
        for i in range(0, 30):
            pdate = date - datetime.timedelta(i)
            yield PFolder(date2label(pdate),
                        call = 'dayChannelList',
                        param = {'date': pdate.strftime(DATE_FORMAT)}
                    )


    @plugin_folder
    def dayChannelList(self, date):
        """ List channels for "list program by date" """
        self.core.setSorting('NONE')

        url = self.BASE_URL + '/ivysilani/podle-data-vysilani/' + date
        self.wget.request(url)
        
        icons = self.wget.select('.programmeColumn .logo img')
        for i in range(0, len(icons)):
            img = icons[i]
            yield PFolder(img['alt'].strip(),
                        call = 'dayProgramList',
                        param = {'date': date, 'chnum': i},
                        iconURL = img['src']
                    )


    @plugin_folder
    def dayProgramList(self, date, chnum ):
        """ List programs on given channel ID and date """
        self.core.setSorting('NONE')

        url = self.BASE_URL + '/ivysilani/podle-data-vysilani/' + date
        self.wget.request(url)

        cols = self.wget.select('.programmeColumn')
        chColumn = cols[ int(chnum) ]

        for item in chColumn.select('li.active'):
            title_a = item.select_first('.title a')
            info = {
                    'path': title_a['href'],
                    'title': title_a.text.strip(),
                    'time': item.select_first('.time').text.strip(),
                    'date': date,
                    'plotoutline': '',
                }
            desc = item.select_first('.title + p')
            if desc:
                info['plotoutline'] = desc.text.strip()
            # label 
            label = info['time'] + ' - ' + info['title']
            if info['plotoutline']:
                label += ' - ' + info['plotoutline']
            yield PItem(label,
                        call = 'play',
                        param = {'path': title_a['href']},
                        info = info
                    )


    @plugin_call
    def play(self, path):
        """ Play stream on given path """
        self.debug('get_program_info on path: ' + repr(path))
        prog = CzechTVProgram(self, path)
        infoItem = prog.getInfo()

        if not infoItem:
            self.core.okDialog('CzechTV plugin error',
                    u'Vybraná část není v iVysílání k dispozici.')
            return

        streamURL = prog.getStreamURL()
        self.debug('play_stream %s' % repr(streamURL))
        self.core.play(streamURL, infoItem)


