# -*- encoding: utf-8 -*- 

import unittest
from stvPlugin import *
from testPluginInterface import *
import re


class TestSTVlugin(unittest.TestCase):

    def setUp(self):
        self.iface = TestPluginInterface()
        self.plugin = STVPlugin(self.iface)


    def test_root(self):
        self.plugin.call()

        self.assertTrue( len(self.iface.ITEMS) > 10 )

        found = filter(lambda i:i.label == u'Elixír', self.iface.ITEMS)
        self.assertEqual( found[0].label, u'Elixír' )
        self.assertEqual(self.iface.ITEMS[0].call, 'relacia')
        self.assertEqual( found[0].param, {'path': '/online/archiv/elixir'} )
        self.assertTrue( found[0].isFolder )


    def test_relacia(self):
        self.plugin.call('relacia', path='/online/archiv/kapura')

        self.assertTrue( len(self.iface.ITEMS) > 20 )

        i1 = self.iface.ITEMS[-1]
        self.assertEqual( i1.label, u'04.10.2008 - Kapura' )
        self.assertEqual( i1.call, 'play')
        self.assertEqual( i1.param,
            { 'url': 'http://www.stv.sk/online/archiv/kapura?id=41633&scroll=&list-all=1'} )
        self.assertFalse( i1.isFolder )

        i2 = self.iface.ITEMS[-3]
        self.assertEqual( i2.label, u'18.10.2008 - Kapura' )
        self.assertEqual( i2.call, 'play')
        self.assertEqual( i2.param,
            {'url': u'http://www.stv.sk/online/archiv/kapura?id=41635&scroll=&list-all=1'} )
        self.assertFalse( i2.isFolder )


    def test_relacia_not_found(self):
        self.plugin.call('relacia', path='/online/archiv/sport-vo-svete')

        self.assertEqual( self.iface.LOG[0],
            "okDialog heading='STV plugin error' line1=u'Dan\\xe1 rel\\xe1cia sa v novom videoarch\\xedvezatia\\u013e nenach\\xe1dza.'")


    def test_play(self):
        self.plugin.call('play', url='http://www.stv.sk/online/archiv/slovensko-dnes?id=35481&scroll=')

        self.assertEqual( self.iface.LOG[-1][0], 'play' )
        self.assertTrue( re.match(r'^rtmp://[^ ]* playpath=mp4:.*.mp4$', 
                                    self.iface.LOG[-1][1]) )
        self.assertEqual( self.iface.LOG[-1][2], None )


if __name__ == '__main__':
    unittest.main()
