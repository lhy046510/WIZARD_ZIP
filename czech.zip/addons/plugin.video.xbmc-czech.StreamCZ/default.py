"""
 Plugin for accessing streams/videos on http://www.stream.cz
"""

import sys
from xbmcPluginInterface import *

def run():
    from streamczPlugin import StreamCZPlugin
    iface = XBMCPluginInterface("plugin.video.xbmc-czech.StreamCZ")
    plugin = StreamCZPlugin( iface )
    plugin.call( *sys.argv )


if __name__ == '__main__':
    run()

