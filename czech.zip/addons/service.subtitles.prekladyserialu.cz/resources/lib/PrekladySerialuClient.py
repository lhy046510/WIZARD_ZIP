# # -*- coding: utf-8 -*- 

from utilities import log
import urllib, re, os, copy, xbmc, xbmcgui
import HTMLParser
from stats import results_with_stats
from difflib import SequenceMatcher

class PrekladySerialuClient(object):

	def __init__(self,addon):
		self.server_url = "http://www.prekladyserialu.cz"
		self.addon = addon
		self._t = addon.getLocalizedString

	def download(self,link):

		dest_dir = os.path.join(xbmc.translatePath(self.addon.getAddonInfo('profile').decode("utf-8")), 'temp')
		dest = os.path.join(dest_dir, "download.tmp")

		log(__name__,'Downloading subtitles from %s' % link)
		res = urllib.urlopen(link)
		
		subtitles_filename = re.search("Content\-Disposition: filename=\"(.+?)\"",str(res.info())).group(1)
		log(__name__,'Filename: %s' % subtitles_filename)
		subtitles_format = re.search("\.(\w+?)$", subtitles_filename, re.IGNORECASE).group(1)
		log(__name__,"Subs in %s" % subtitles_format)
		
		subtitles_data = res.read()

		log(__name__,'Saving to file %s' % dest)
		zip_file = open(dest,'wb')
		zip_file.write(subtitles_data)
		zip_file.close()

		final_dest = os.path.join(dest_dir, "download." + subtitles_format)

		log(__name__,'Changing filename to %s' % final_dest)
		os.rename(dest, final_dest)

		return final_dest

	def get_tv_show_list(self):
		res = urllib.urlopen(self.server_url + "/prekladane-serialy")
		if not res.getcode() == 200: return None

		tv_shows = []
		for tv_show_html in re.findall("<div class=\"serialyTitle\">(.+?)</div>", res.read().decode("utf-8"), re.IGNORECASE | re.DOTALL):
			tv_show_url, tv_show_name = re.search("<a href=\"(.+?)\".*?>(.+?)</a>", tv_show_html, re.IGNORECASE).groups()
			tv_shows.append({ "url" : tv_show_url, "title": tv_show_name })

		return tv_shows

	def search_show_url(self, title, show_list):
		log(__name__,"Starting search by TV Show: %s" % title)
		if not title: return None

		for threshold_ratio in range(100,50,-5):
			if threshold_ratio == None: return show_list
			tv_show_list = []
			for tv_show in show_list:
				matcher = SequenceMatcher(None, re.sub(r'(?i)^The ',"", tv_show["title"]), re.sub(r'(?i)^The ',"", title)).ratio() * 100
				if matcher >= threshold_ratio: tv_show_list.append(tv_show)

			if tv_show_list: break

		if not tv_show_list: tv_show_list = show_list

		if (len(tv_show_list) == 0):
			log(__name__,"No TV Show found")
			return None
		elif (len(tv_show_list) == 1):
			log(__name__,"One TV Show found, autoselecting")
			tvshow_url = tv_show_list[0]['url']
		else:
			log(__name__,"More TV Shows found, user dialog for select")
			menu_dialog = []
			for tv_show in tv_show_list: menu_dialog.append(tv_show['title'])
			dialog = xbmcgui.Dialog()
			found_tv_show_id = dialog.select(self._t(32003), menu_dialog)
			if (found_tv_show_id == -1): return None # cancel dialog
			tvshow_url = tv_show_list[found_tv_show_id]['url']

		log(__name__,"Selected show URL: " + tvshow_url)
		return tvshow_url

	def normalize_input_title(self, title):
		if self.addon.getSetting("search_title_in_brackets") == "true":
			log(__name__, "Searching title in brackets - %s" % title)
			search_second_title = re.match(r'.+ \((.{3,})\)',title)
			if search_second_title and not re.search(r'^[\d]{4}$',search_second_title.group(1)): title = search_second_title.group(1)
		
		if re.search(r', The$',title,re.IGNORECASE):
			log(__name__, "Swap The - %s" % title)
			title =  "The " + re.sub(r'(?i), The$',"", title) # normalize The
		
		if self.addon.getSetting("try_cleanup_title") == "true":
			log(__name__, "Title cleanup - %s" % title)
			title = re.sub(r"(\[|\().+?(\]|\))","",title) # remove [xy] and (xy)

		return title.strip()

	def search(self, item):

		# --
		# Server ukoncil cinnost
		dialog = xbmcgui.Dialog()
		dialog.ok(self.addon.getAddonInfo('name'),self._t(32199))
		# --

		if item['mansearch']:
			title = item['mansearchstr']
			dialog = xbmcgui.Dialog()
			item['season'] = dialog.numeric(0, self._t(32111), item['season'])
			item['episode'] = dialog.numeric(0, self._t(32112), item['episode'])
		else:
			title = self.normalize_input_title(item['tvshow'])

		if not title or not item['season'] or not item['episode']:
			xbmc.executebuiltin("XBMC.Notification(%s,%s,5000,%s)" % (
						self.addon.getAddonInfo('name'), self._t(32110),
						os.path.join(xbmc.translatePath(self.addon.getAddonInfo('path')).decode("utf-8"),'icon.png')
			))
			log(__name__, ["Input validation error", title, item['season'], item['episode']])
			return results_with_stats(None, self.addon, title, item)

		if item['3let_language'] and "cze" not in item['3let_language']:
			dialog = xbmcgui.Dialog()
			if dialog.yesno(self.addon.getAddonInfo('name'), self._t(32100), self._t(32101)):
				xbmc.executebuiltin("ActivateWindow(videossettings)")
			return results_with_stats(None, self.addon, title, item)

		all_tv_show_list = self.get_tv_show_list()
		if not all_tv_show_list: return results_with_stats(None, self.addon, title, item)

		tvshow_url = self.search_show_url(title, all_tv_show_list)
		if tvshow_url == None: return results_with_stats(None, self.addon, title, item)

		episode_link = self.search_season_episode(tvshow_url,item['season'],item['episode'])
		log(__name__, ["Episode link", episode_link])
		if episode_link == None: return results_with_stats(None, self.addon, title, item)

		episode_subtitle_list = self.search_episode_subtitles(episode_link)
		log(__name__, ["Subtitle list", episode_subtitle_list])
		if episode_subtitle_list == None: return results_with_stats(None, self.addon, title, item)

		lang_filetred_episode_subtitle_list = self.filter_subtitles_by_language(item['3let_language'], episode_subtitle_list)
		log(__name__, ["Language filter", lang_filetred_episode_subtitle_list])
		if not lang_filetred_episode_subtitle_list: return results_with_stats(None, self.addon, title, item)

		result_subtitles = []
		for found_subtitle in lang_filetred_episode_subtitle_list:
			print_out_filename = found_subtitle['title']
			if not found_subtitle['author'] == None: print_out_filename += " by " + found_subtitle['author']
			result_subtitles.append({ 
				'filename': HTMLParser.HTMLParser().unescape(print_out_filename),
				'link': self.server_url + found_subtitle['link'],
				'lang': found_subtitle['lang'],
				'rating': "0",
				'sync': False,
				'lang_flag': xbmc.convertLanguage(found_subtitle['lang'],xbmc.ISO_639_1),
			})

		log(__name__,["Search result", result_subtitles])

		return results_with_stats(result_subtitles, self.addon, title, item)

	def search_episode_subtitles(self, episode_link):
		res = urllib.urlopen(self.server_url + episode_link)
		if not res.getcode() == 200: return None

		subtitles_list = []
		for subtitles_html in re.findall("<div class=\"titulkyHeight\">\s+?<table class=\"nahraneTitulky\">(.+?)</table>\s+?</div>", res.read().decode("utf-8"), re.IGNORECASE | re.DOTALL ):
			title = re.search(r"Verze: <strong>(.+?)</strong>", subtitles_html ,re.IGNORECASE).group(1)
			author = re.search(r"Překlad: <strong>(.+?)</strong>".decode("utf-8"), subtitles_html ,re.IGNORECASE).group(1)
			link = re.search(r"<a href=\"(.+?)\" title=", subtitles_html, re.IGNORECASE).group(1)
			lang = re.search(r"<img src=\"\/img\/flag_(.+?)\.png", subtitles_html, re.IGNORECASE).group(1)
			if lang == "cz": lang = "Czech"
			if lang == "sk": lang = "Slovak"
			if lang == "en": lang = "English"
			if re.match("<em>", author): author = None
			subtitles_list.append({'title': title, 'author': author, 'link': link, 'lang': lang})

		return subtitles_list

	def filter_episode_from_season_episodes(self, season_subtitles, season, episode):
		for season_subtitle in season_subtitles:
			if (season_subtitle['episode'] == int(episode) and season_subtitle['season'] == int(season)):
				return season_subtitle
		return None

	def search_season_episode(self, show_url, show_series, show_episode):
		res = urllib.urlopen(self.server_url + show_url + "/" + "serie-" + show_series)
		if not res.getcode() == 200: return None

		episode_list = []
		for episode_html in re.findall("<div class=\"titulkyHeight\">\s+?<table>(.+?)</table>\s+?</div>", res.read().decode("utf-8"), re.IGNORECASE | re.DOTALL ):
			episode_url = re.search(r"<a href=\"(.+?)\" title=", episode_html, re.IGNORECASE).group(1)
			episode_season, episode_number = re.search(r"<td class=\"titulkyEpizoda text-right\">\s+?S(\d+?)E(\d+?)\s+?</td>", episode_html, re.IGNORECASE | re.DOTALL).groups()
			if (int(episode_season) == int(show_series) and int(episode_number) == int(show_episode)): return episode_url
	
		return None

	def filter_subtitles_by_language(self, set_languages, subtitles_list):
		if not set_languages: return subtitles_list

		log(__name__, ['Filter by languages', set_languages])
		filter_subtitles_list = []
		for subtitle in subtitles_list:
			if xbmc.convertLanguage(subtitle['lang'],xbmc.ISO_639_2) in set_languages:
				filter_subtitles_list.append(subtitle)

		if not filter_subtitles_list:
			if "cze" not in set_languages and "slo" not in set_languages:
				dialog = xbmcgui.Dialog()
				if dialog.yesno(self.addon.getAddonInfo('name'), self._t(32100), self._t(32101)):
					xbmc.executebuiltin("ActivateWindow(videossettings)")
			return None
		else:
			return filter_subtitles_list