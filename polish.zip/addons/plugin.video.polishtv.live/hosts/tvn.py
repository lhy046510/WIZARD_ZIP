# -*- coding: utf-8 -*-

#NOTES:
# - pomija ULUBIONE i KONTYNUUJ,
# - uzywa settings: quality i proxy


import os, sys
import xbmcaddon, xbmcgui
import traceback

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json

scriptID = 'plugin.video.polishtv.live'
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdSettings, sdParser, sdCommon, sdErrors, sdNavigation

log = sdLog.pLog()

SERVICE = 'tvn'
THUMB_SERVICE = 'http://sd-xbmc.org/repository/xbmc-addons/'+ SERVICE + '.png'
MAINURL =  'https://api.tvnplayer.pl'
APIURL = MAINURL + '/api/?platform=ConnectedTV&terminal=Samsung&format=json&v=3.0&authKey=ba786b315508f0920eca1c34d65534cd&'
IMAGEURL = 'http://dcs-193-111-38-250.atmcdn.pl/scale/o2/tvn/web-content/m/'
HOST = 'Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV; Maple2012) AppleWebKit/534.7 (KHTML, like Gecko) SmartTV Safari/534.7'

qualities = [
            'HD',
            'Bardzo wysoka',
            'Wysoka',
            'Standard',
            'Średnia'
            'Niska',
            'Bardzo niska'
            ]

tvn_proxy = ptv.getSetting('tvn_proxy')
tvn_quality = ptv.getSetting('tvn_quality')


class tvn:
    def __init__(self):
        log.info('Loading ' + SERVICE)
        self.parser = sdParser.Parser()
        self.gui = sdNavigation.sdGUI()
        self.common = sdCommon.common()
        self.api = API()
    
    
    def getMenu(self, args):
        data = self.api.getAPI(args)
        for item in data['categories']:
            #pomin ULUBIONE i KONTYNUUJ
            if item['type'] != 'favorites' and  item['type'] != 'pauses':                
                if item['thumbnail'] != None:
                    icon =self.api.getImage(item['thumbnail'][0]['url'])
                else:
                    icon = THUMB_SERVICE
                params = {'service': SERVICE, 'category': item['type'], 'id': item['id'], 'title': item['name'].encode('UTF-8'), 'icon': icon}
                self.gui.addDir(params)
        self.gui.endDir()
        
        
    def getItems(self, args):
        sort = True
        data = self.api.getAPI(args)

        if (not 'seasons' in data) or (len(data['seasons']) == 0) or ('season=' in args): #bez sezonow albo odcinki w sezonie
            for item in data['items']:
                if item['thumbnail'] != None:
                    icon =self.api.getImage(item['thumbnail'][0]['url'])
                else:
                    icon = THUMB_SERVICE
                    
                title = item['title'].encode('UTF-8')
   
                if item['type'] == 'episode' and item['type_episode'] != 'preview_catchup': #planowane
                    sort = False
                    if item['season'] != 0 and item['season'] != None:
                        title = title + ', sezon ' + str(item['season'])
                    if item['episode'] != 0 and item['episode'] != None:
                        title = title + ', odcinek ' + str(item['episode'])

                if item['type'] == 'series':
                    sort = True
                    if item['season'] != 0 and item['season'] != None:
                        title = title + ', sezon ' + str(item['season'])
                    
                params = {'service': SERVICE, 'category': item['type'], 'id': item['id'], 'title': title.strip(), 'icon': icon}
                self.gui.addDir(params)
                    
        else: #listuj sezony
            for item in data['seasons']:
                if item['thumbnail'] != None:
                    icon =self.api.getImage(item['thumbnail'][0]['url'])
                else:
                    icon = THUMB_SERVICE
                    
                params = {'service': SERVICE, 'category': item['type'], 'id': item['id'], 'title': item['name'].encode('UTF-8'), 'icon': icon, 'seriesId': item['vdp_id']}
                self.gui.addDir(params)
        print "SSS: " + str(sort)
        self.gui.endDir(sort)
    
    
    def getVideoUrl(self, args):
        ret = ''
        
        if tvn_proxy == 'true':
            useProxy = True
        else:
            useProxy = False
    
        data = self.api.getAPI(args, useProxy)
        
        #znajdz jakosc z settings wtyczki      
        if data['item']['videos']['main']['video_content'] != None and len(data['item']['videos']['main']['video_content']) != 0:
            url = ''
            for item in data['item']['videos']['main']['video_content']:
                if item['profile_name'].encode('UTF-8') == tvn_quality:
                    print "FOUND: " + item['profile_name'].encode('UTF-8')
                    url = item['url'] #znalazlem wybrana jakosc
                    break;
            #jesli jakosc nie znaleziona (lub Maksymalna) znajdz pierwsza najwyzsza jakosc
            if url == '':
                for q in qualities:
                    for item in data['item']['videos']['main']['video_content']:
                        if item['profile_name'].encode('UTF-8') == q:
                            url = item['url']
                            break
                    if url != '':
                        break            
                   
            query_data = {'url': url, 'use_host': True, 'host': HOST, 'use_header': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
            try:
                ret = self.common.getURLRequestData(query_data)
            except Exception, exception:
                traceback.print_exc()
                self.exception.getError(str(exception))
                exit()                        
        return ret
    
    
    def handleService(self):
        params = self.parser.getParams()
        title = str(self.parser.getParam(params, "title"))
        category = str(self.parser.getParam(params, "category"))
        id = str(self.parser.getParam(params, "id"))
        seriesId = str(self.parser.getParam(params, "seriesId"))

        #MAINMENU
        if category == 'None':
            if self.api.geoCheck():
                self.getMenu('m=mainInfo')
        
        #WSZYSTKO
        if category != 'None' and category != 'episode' and seriesId == 'None':
            self.getItems('m=getItems&sort=newest&limit=500&type=' + category + '&id=' + id)
        
        #ODCINKI W SEZONIE
        if seriesId != 'None':
            self.getItems('m=getItems&sort=newest&limit=500&type=series&id=' + seriesId + '&season=' + id)
        
        #VIDEO
        if category == 'episode':
            videoUrl = self.getVideoUrl('m=getItem&type=' + category + '&id=' + id)
            self.common.LOAD_AND_PLAY_VIDEO(videoUrl, title)
            
            
class API:
    def __init__(self):
        self.exception = sdErrors.Exception()
        self.common = sdCommon.common()
        self.proxy = sdCommon.proxy()
    
    
    def geoCheck(self):
        ret = True
        if tvn_proxy != 'true':
            data = self.getAPI('m=checkClientIp', False)
            if data['result'] == False:
                d = xbmcgui.Dialog()
                d.ok(SERVICE, 'Serwis niedostepny na terenie twojego kraju.', 'Odwiedz sd-xbmc.org w celu uzyskania dostepu.')
            ret = data['result']
        return ret


    def getAPI(self, args, useProxy = False):
        if useProxy:
            url = self.proxy.useProxy(APIURL + args)
        else:
            url = APIURL + args
            
        query_data = {'url': url, 'use_host': True, 'host': HOST, 'use_header': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
        try:
            data = self.common.getURLRequestData(query_data)
            #if (iplex_proxy == 'true' and self.proxy.isAuthorized(data) != False) or iplex_proxy == 'false':
            result = _json.loads(data)

        except Exception, exception:
            traceback.print_exc()
            self.exception.getError(str(exception))
            exit()
            
        if not 'status' in result or result['status'] != 'success':
            d = xbmcgui.Dialog()
            d.ok(SERVICE, 'Blad API', '')
            exit()
        return result
    
    
    def getImage(self, path):
        return IMAGEURL + path + '?quality=70&dstw=290&dsth=187&type=1'



