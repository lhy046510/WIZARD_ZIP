# -*- coding: utf-8 -*-
import urllib, urllib2, re, os, sys, math
import xbmcgui, xbmc, xbmcaddon, xbmcplugin
from urlparse import urlparse, parse_qs
import urlparser
import json


scriptID = 'plugin.video.mrknow'
scriptname = "Filmy online www.mrknow.pl - plej"
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import pLog, libCommon, Parser, settings

log = pLog.pLog()

mainUrl = 'http://plejer.tv/'
#chanels = 'http://plej.tv/index.php?p=kanal'
chanels = 'http://plejer.tv/index.php?p=kanal&id=517711e9409d4'
categories = 'http://plejer.tv/index.php?p=cats'
playerUrl = 'http://www.youtube.pl/'

HOST = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:21.0) Gecko/20100101 Firefox/21.0'

MENU_TAB = {1: "Lista kanałów",
            3: "Kategorie",
            5: "Ustawienia" }


class plej:
    def __init__(self):
        log.info('Starting plej.pl')
        self.cm = libCommon.common()
        self.parser = Parser.Parser()
        self.up = urlparser.urlparser()
        self.cm = libCommon.common()
        self.settings = settings.TVSettings()
        self.COOKIEFILE = ptv.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + "plej.cookie"
        self.zalogowany = 0
        
    def login(self):    
        print "Zalogowany--->", self.zalogowany
        
        if ptv.getSetting('plej_login') == 'true':
            post_data = {'login': ptv.getSetting('plej_user'), 'pass': ptv.getSetting('plej_pass'), 'log_in2':'Zaloguj'}
            query_data = {'url': mainUrl+'index.php?p=login', 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': False, 'cookiefile': self.COOKIEFILE, 'use_post': True, 'return_data': True}
            data = self.cm.getURLRequestData(query_data, post_data)
            #print ("Data1",data)
            #post_data = {'login': ptv.getSetting('plej_user'), 'pass': ptv.getSetting('plej_pass'), 'log_in2':'Zaloguj'}
            #query_data = {'url': mainUrl+'index.php?p=login', 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': False, 'cookiefile': self.COOKIEFILE, 'use_post': True, 'return_data': True}
            #data = self.cm.getURLRequestData(query_data, post_data)
            #print ("Data2",data)
            if self.isLoggedIn(data) == True:
                xbmc.executebuiltin("XBMC.Notification(" + ptv.getSetting('plej_user') + ", Zostales poprawnie zalogowany,4000)")
                self.zalogowany = 2
            else:
                xbmc.executebuiltin("XBMC.Notification(Blad logowania, sprawdź login i hasło. Używam Player z limitami,4000)")  
        else:
            query_data = { 'url': 'http://plej.tv/ajax/alert.php', 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': False, 'cookiefile': self.COOKIEFILE, 'use_post': False, 'return_data': True }
            link = self.cm.getURLRequestData(query_data)
            xbmc.executebuiltin("XBMC.Notification(Skonfiguruj konto w ustawieniach, obecnie uzywam Player z limitami,4000)")  
        
    def isLoggedIn(self, data):
        lStr = '<li><a class="play" href="index.php?p=logout" title="" >WYLOGUJ</a></li>'
        if lStr in data:
          return True
        else:
          return False

    def listsMain(self, table):
        for num, val in table.items():
            self.add('plej', 'main-menu', val, 'None', 'None', 'None', 'None', 'None', True, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


    def listsMainMenu(self, table):
        query_data = { 'url': chanels, 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': True, 'cookiefile': self.COOKIEFILE, 'use_post': False, 'return_data': True }
        link = self.cm.getURLRequestData(query_data)
        match = re.compile('<table style="width:100%"><tr><td style="width:30%;vertical-align:middle;"><a href="(.*?)" title="(.*?)" rel="tooltip"><img style="width:50px;height:40px;" src="(.*?)" alt="" /></a></td>', re.DOTALL).findall(link)
        #print match
        for o in range(len(match)):
            #if self.getMovieType(mainUrl+match[o][0]) == True:
                #add(self, service, name,               category, title,     iconimage, url, desc, rating, folder = True, isPlayable = True):
                #self.add('plej', 'playSelectedMovie', 'None', nazwa, mainUrl+image, stream, 'None', 'None', True, False)
                self.add('plej', 'playSelectedMovie', 'None', match[o][1], mainUrl+match[o][2], mainUrl+match[o][0], 'None', 'None', False, False)
            #else:
            #    self.add('plej', 'items-menu', 'None', match[o][1], mainUrl+match[o][2], mainUrl+match[o][0], 'None', 'None', True, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def listsCategoriesItems(self,url):
        query_data = { 'url': url, 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': True, 'cookiefile': self.COOKIEFILE, 'use_post': False, 'return_data': True }
        link = self.cm.getURLRequestData(query_data)
        match = re.compile('<div class="left">(.*?)<div class="right">', re.DOTALL).findall(link)
        if len(match) > 0:
            match1 = re.compile('\n            \n          <a href="(.*?)" title="(.*?)"><img style="border: 3px solid green;" class="logo" src="(.*?)" alt="" /></a>\n          <h2><a class="play" href="(.*?)" title="(.*?)">(.*?)</a></h2>', re.DOTALL).findall(match[0])
            for i in range(len(match1)):
                url = mainUrl + match1[i][0] + '&online=1'
                img = mainUrl + match1[i][2]
                self.add('plej', 'playSelectedMovie', 'None', match1[i][1], img, url, 'None', 'None', False, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


    def listsCategoriesMenu(self):
        query_data = { 'url': categories, 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': True, 'cookiefile': self.COOKIEFILE, 'use_post': False, 'return_data': True }
        link = self.cm.getURLRequestData(query_data)
        #print ("Link",link)
        match = re.compile('<div class="left">(.*?)<div class="right">', re.DOTALL).findall(link)
        #print match
        if len(match) > 0:
            #<a href="index.php?p=kanaly&cat=10" title="Blogerzy i Vlogerzy"><img class="logo" src="images/tvtv.png" alt="" /></a>\n          <h2><a class="play" href="index.php?p=kanaly&cat=10" title="Blogerzy i Vlogerzy">Blogerzy i Vlogerzy (11)</a></h2>
            match1 = re.compile('<a href="(.*?)" title="(.*?)"><img class="logo" src="(.*?)" alt="" /></a>\n          <h2><a class="play" href="(.*?)" title="(.*?)">(.*?)</a></h2>', re.DOTALL).findall(match[0])
            print match1
        #    log.info('Listuje kategorie: ')
            for i in range(len(match1)):
                url = mainUrl + match1[i][0] + '&online=1'
                img = mainUrl + match1[i][2]
                #    def add(self, service, name, category, title, iconimage, url, desc, rating, folder = True, isPlayable = True):
                self.add('plej', 'categories-menu', match1[i][1].strip(), 'None', img, url, 'None', 'None', True, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def listsItems(self, url):
        query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
        link = self.cm.getURLRequestData(query_data)
        match = re.compile("\n            'playlist':(.*?)'autostart': 'true',",re.DOTALL).findall(link)
        print ("LINK",match)
        match1 = re.compile('{"file":"(.*?)"}],"title":"(.*?)"}', re.DOTALL).findall(match[0])
        print ("Match1",match1)
        pl=xbmc.PlayList(1)
        pl.clear()

        #linkVideo = self.up.getVideoLink(match[0])
        for i in range(len(match1)):
 	#           self.add('plej', 'playYoutube', 'None', str(i) +'. ' +match1[i][1], 'None', self.up.getVideoLink(match1[i][0].replace('\\','')), 'aaaa', 'None', True, True)
		print ("ZZZZZZZ",self.up.getVideoLink(match1[i][0].replace('\\','')))
		listitem = xbmcgui.ListItem(str(i) +'. ' +match1[i][1], thumbnailImage='None')
		url = self.up.getVideoLink(match1[i][0].replace('\\',''))
		xbmc.PlayList(1).add(url, listitem)
	

	xbmc.Player().play(pl)
	return True



    def listsItemsPage(self, url):
        if not url.startswith("http://"):
            url = mainUrl + url
        if self.getSizeAllItems(url) > 0  and self.getSizeItemsPerPage(url) > 0:
            a = math.ceil(float(self.getSizeAllItems(url)) / float(self.getSizeItemsPerPage(url)))
            for i in range(int(a)):
                num = i + 1
                title = 'Lista ' + str(num)
                destUrl = url + sort_asc + '&page=' + str(num)
                self.add('plej', 'items-menu', 'None', title, 'None', destUrl, 'None', 'None', True, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))        


    def listsItemsSerialPage(self, url, sizeOfSerialParts):
        if not url.startswith("http://"):
            url = mainUrl + url
        if sizeOfSerialParts > 0  and self.getSizeItemsPerPage(url) > 0:
            a = math.ceil(float(sizeOfSerialParts) / float(self.getSizeItemsPerPage(url)))
            for i in range(int(a)):
                num = i + 1
                title = 'Lista ' + str(num)
                destUrl = url + sort_asc + '&page=' + str(num)
                self.add('plej', 'items-menu', 'None', title, 'None', destUrl, 'None', 'None', True, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1])) 

    def getMovieType(self, url):
        query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
        link = self.cm.getURLRequestData(query_data)
        match = re.compile('streamer  : \'(.*?)\',', re.DOTALL).findall(link)
        match1 = re.compile('var asrc = "(.*?)";', re.DOTALL).findall(link)
        match2 = re.compile('file:\'(.*?)\',', re.DOTALL).findall(link)

        print ("ZZZZZZZZ",match,url)
        if len(match)>0:
            return True
        elif len(match1)>0:
            return True
	elif len(match2)>0:
	    return True
        else:
            return False
        
    def getMovieLinkFromXML(self, url):
        #print ("URL",url)
        #query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
        query_data = { 'url': url, 'use_host': False, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': self.COOKIEFILE, 'use_post': False, 'return_data': True }
        link = self.cm.getURLRequestData(query_data)
        match = re.compile('var asrc = "(.*?)";', re.DOTALL).findall(link)
        match1 = re.compile('streamer  : \'(.*?)\',', re.DOTALL).findall(link)
        match2 = re.compile('file:\'(.*?)\',', re.DOTALL).findall(link)
        match10 = re.compile('jQuery.ajaxSetup\({async:true}\);\n  \n  \$.get\("(.*?)",', re.DOTALL).findall(link)
        print "Match10",match10
        if len(match10)>0:
            query_data = { 'url': mainUrl+match10[0], 'use_host': False, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': self.COOKIEFILE, 'use_post': False, 'return_data': True }
            link = self.cm.getURLRequestData(query_data)
        
        print ("AAAAAAAAAAAAAA",link)
        if len(match)>0:
            print "Match--->  0"
            linkVideo = match[0]
            #return linkVideo + ' live=true swfUrl=http://plej.tv/StrobeMediaPlayback.swf pageUrl='+url
            return linkVideo 
            
        elif len(match1)>0:
            print "Match--->  1"
            match2 = re.compile('video     : \'(.*?)\',', re.DOTALL).findall(link)
            print match2
            linkVideo = match1[0] + '/'+match2[0]
            print linkVideo
            return linkVideo
        elif len(match2)>0:
            print "Match--->  2"
            linkVideo = match2[0]
            return linkVideo
 

    

    def add(self, service, name, category, title, iconimage, url, desc, rating, folder = True, isPlayable = True):
        u=sys.argv[0] + "?service=" + service + "&name=" + name + "&category=" + category + "&title=" + title + "&url=" + urllib.quote_plus(url) + "&icon=" + urllib.quote_plus(iconimage)
        #log.info(str(u))
        if name == 'main-menu' or name == 'categories-menu':
            title = category 
        if iconimage == '':
            iconimage = "DefaultVideo.png"
        liz=xbmcgui.ListItem(title, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        if isPlayable:
            liz.setProperty("IsPlayable", "true")
        liz.setInfo( type="Video", infoLabels={ "Title": title } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=folder)
            

    def LOAD_AND_PLAY_VIDEO(self, videoUrl, title, icon):
        ok=True
        if videoUrl == '':
                d = xbmcgui.Dialog()
                d.ok('Nie znaleziono streamingu.', 'Może to chwilowa awaria.', 'Spróbuj ponownie za jakiś czas')
                return False
        liz=xbmcgui.ListItem(title, iconImage=icon, thumbnailImage=icon)
        liz.setInfo( type="Video", infoLabels={ "Title": title, } )
        try:
            xbmcPlayer = xbmc.Player()
            xbmcPlayer.play(videoUrl, liz)
            
           # if not xbmc.Player().isPlaying():
           #     xbmc.sleep( 10000 )
                #xbmcPlayer.play(url, liz)
            
        except:
            d = xbmcgui.Dialog()
            d.ok('Błąd przy przetwarzaniu.', 'Problem')        
        return ok


    def handleService(self):
    	params = self.parser.getParams()
        name = self.parser.getParam(params, "name")
        category = self.parser.getParam(params, "category")
        url = self.parser.getParam(params, "url")
        title = self.parser.getParam(params, "title")
        icon = self.parser.getParam(params, "icon")
        print("aaa",name,category,url,title)
        if name == None:
            self.login()
            self.listsMain(MENU_TAB)
            
        elif name == 'main-menu' and category == 'Lista kanałów':
            self.listsMainMenu(chanels)
        elif name == 'main-menu' and category == 'Kategorie':
            self.listsCategoriesMenu()
        elif name == 'main-menu' and category == 'Ustawienia':
            log.info('Wyświetlam ustawienia')
            self.settings.showSettings()
        
        elif name == 'categories-menu' and category != 'None':
            log.info('url: ' + str(url))
            self.listsCategoriesItems(url)
        if name == 'playSelectedMovie':
            if self.getMovieType(url) == True:
                print "JJJJJJJJJJJJEESSSSTTTT TRUE"
                self.LOAD_AND_PLAY_VIDEO(self.getMovieLinkFromXML(url), title, icon)
            else:
                self.listsItems(url)
        
  
