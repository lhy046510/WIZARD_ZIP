#!/usr/bin/python
# -*- coding: utf-8 -*-

############################################
#                                          #
# plugin.video.kino-pecetowiec-pl for xbmc #
# author: t0mus                            #
#                                          #
############################################

""" XBMC plugin for kino.pecetowiec.pl site """

import os
import sys
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui

__this_plugin__ = int(sys.argv[1])
reload(sys)
sys.setdefaultencoding('utf-8')

__addon__ = 'plugin.video.kino-pecetowiec-pl'
__settings__ = xbmcaddon.Addon(id=__addon__)
__plugin_string__ = 'plugin://' + __addon__ + '/?'
__baseurl_string__ = 'http://kino.pecetowiec.pl/'

__images_dir__ = \
    xbmc.translatePath(os.path.join(__settings__.getAddonInfo('path'),
                       'resources', 'images'))
__lib_dir__ = \
    xbmc.translatePath(os.path.join(__settings__.getAddonInfo('path'),
                       'resources', 'lib'))

__temp_dir__ = \
    xbmc.translatePath(os.path.join(__settings__.getAddonInfo('path'),
                       'resources', 'temp'))

sys.path.append(__lib_dir__)

from strings import __categories_string__, __search_string__, \
    __header_string__, __loadingcategories_string__, \
    __movietitle_string__, __loadingmovies_string__
from t0mus.common.common import *
from BeautifulSoup import BeautifulSoup

__tools__ = TOOLS()
__tools__.load_parameters(sys.argv[2])
__get__ = __tools__.get_cmd


def create_main_menu():
    """ Creates main menu."""

    browse = xbmcgui.ListItem(__categories_string__,
                              iconImage=os.path.join(__images_dir__,
                              'Folder 2.png'),
                              thumbnailImage=os.path.join(__images_dir__,
                              'Folder 2.png'))
    search = xbmcgui.ListItem(__search_string__,
                              iconImage=os.path.join(__images_dir__,
                              'Folder 2 Search.png'),
                              thumbnailImage=os.path.join(__images_dir__,
                              'Folder 2 Search.png'))
    xbmcplugin.addDirectoryItem(__this_plugin__, __plugin_string__
                                + 'browse=true', browse, isFolder=True)
    xbmcplugin.addDirectoryItem(__this_plugin__, __plugin_string__
                                + 'search=true', search, isFolder=True)
    xbmcplugin.endOfDirectory(__this_plugin__, succeeded=True)


def create_categories():
    """ Creates categories menu."""

    dialog = xbmcgui.DialogProgress()
    dialog.create(__header_string__, __loadingcategories_string__)
    count = 0
    soup = BeautifulSoup(open_url(__baseurl_string__+'categories').read())
    div = soup.find('div', 'general-left-container-728')
    for cat in div.findAll('div','community-thumb-box'):
        img = cat.find('div','community-thumb-img').find('img')['src']
        div2 = cat.find('div','community-thumb-box-texts')
        name = unescape(div2.find('span','title').string)
        img_path = __temp_dir__+'/cat'+str(count)+'.jpg'
        write_url_to_file(img,img_path)
        link = div2.find('a')['href']
        list_item = xbmcgui.ListItem(unescape(name), iconImage=img_path)
        xbmcplugin.addDirectoryItem(__this_plugin__, __plugin_string__
                                    + 'category=' + link, list_item,
                                    isFolder=True)
        count = count + 1
        dialog.update(count * 10, __loadingcategories_string__)
    dialog.close()
    xbmcplugin.endOfDirectory(__this_plugin__, succeeded=True)


def add_movies(url):
    """ Adds list items representing movies."""

    dialog = xbmcgui.DialogProgress()
    count = 0
    dialog.create(__header_string__, __loadingmovies_string__)
    soup = BeautifulSoup(open_url(url).read())
    general=soup.find('div', 'general-left-container-728')
    if general != None:
        for wrapper in general.findAll('div','channel-details-thumb-box'):
            img=wrapper.find('div','channel-details-thumb-img').find('img')['src']
            div=wrapper.find('div','channel-details-thumb-box-texts')
            title=div.find('a')
            name = unescape(title.string)
            link = title['href']
            img_path = __temp_dir__+'/item'+str(count)+'.jpg'
            write_url_to_file(img,img_path)
            list_item = xbmcgui.ListItem(name, iconImage=img_path)
            xbmcplugin.addDirectoryItem(__this_plugin__,
                    __plugin_string__ + 'movie=' + link + '&name='
                    + name, list_item, isFolder=True)
            count = count + 2
            dialog.update(count, __loadingmovies_string__)
    dialog.close()
    return count


from t0mus.common.hosting import recognize_video_hosting

if __get__('category') != None:
    __category__ = str(__get__('category'))
    if __get__('page') != None:
        __page__ = int(__get__('page'))
    else:
        __page__ = 1
    spl=__category__.split('/')
    tmp=spl[-1]
    spl[-1]=str(__page__)
    spl.append(tmp)
    result="/".join(spl)
    __count__ = add_movies(result)
    if __count__ > 8:
        __nextp__ = __page__ + 1
        __nextPage__ = create_next_page_list_item(__page__, __count__,
                10)
        xbmcplugin.addDirectoryItem(__this_plugin__, __plugin_string__
                                    + 'category=' + __category__
                                    + '&page=' + str(__nextp__),
                                    __nextPage__, isFolder=True)
    xbmcplugin.endOfDirectory(__this_plugin__, succeeded=True)
elif __get__('movie') != None:
    __movie__ = str(__get__('movie'))
    __item_name__ = str(__get__('name'))
    recognize_video_hosting(__this_plugin__, __movie__, __item_name__)
    xbmcplugin.endOfDirectory(__this_plugin__, succeeded=True)
elif __get__('browse') != None:
    create_categories()
elif __get__('search') != None:
    __text__ = None
    if __get__('query') != None:
        __text__ = __get__('query')
    else:
        __kb__ = xbmc.Keyboard('', __movietitle_string__, False)
        __kb__.doModal()
        if __kb__.isConfirmed():
            __text__ = __kb__.getText()

    if __text__ != None:
        if __get__('page') != None:
            __page__ = int(__get__('page'))
        else:
            __page__ = 1
        __count__ = add_movies(__baseurl_string__ + 'search/'
                               + str(__page__) + '/?sort=&search_type=search_videos&search_key=&search_id=' + __text__ )
        if __count__ > 8:
            __nextp__ = __page__ + 1
            __nextPage__ = create_next_page_list_item(__page__,
                    __count__, 10)
            xbmcplugin.addDirectoryItem(__this_plugin__,
                    __plugin_string__ + 'search=true&query=' + __text__
                    + '&page=' + str(__nextp__), __nextPage__,
                    isFolder=True)
        xbmcplugin.endOfDirectory(__this_plugin__, succeeded=True)
else:
    create_main_menu()
