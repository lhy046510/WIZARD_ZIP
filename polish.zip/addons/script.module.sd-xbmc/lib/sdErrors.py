# -*- coding: utf-8 -*-
import os, string
import urllib, urllib2, re, sys, math
import xbmcgui, xbmc, xbmcaddon, xbmcplugin
import sdLog

pmod = xbmcaddon.Addon(id='script.module.sd-xbmc')
t = lambda x: pmod.getLocalizedString(x).encode('utf-8')

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg

ERRORS = [
    [ 'HTTP Error 403: Forbidden', t(55900), t(55901) ],
    [ 'HTTP Error 404: Not Found', t(55900), t(55910) ],
    [ 'urlopen error [Errno -2]', t(55900), t(55902) ],
    [ 'No JSON object could be decoded', t(55903), t(55904) ],
    [ '\'NoneType\' object has no attribute', t(55900), t(55905) ],
    [ 'global name', t(55900), t(55906) ],
    [ 'cannot concatenate', t(55900), t(55906) ],
    [ 'expected string or buffer', t(55900), t(55906) ],
    [ 'Expecting property name:', t(55900), t(55906) ],
    [ 'urlopen error timed out', t(55900), t(55907) ],
    [ '[Errno 2]', t(55900), t(55906) ],
    [ '[Errno 10035]', t(55900), t(55906) ],
    [ 'xml.parsers.expat.ExpatError', t(55900), t(55908)],
    [ 'must be string or read-only character buffer', t(55900), t(55909) ],
    [ 'not a valid non-string sequence or mapping object', t(55900), t(55909) ],
]

class Exception:
    def __init__(self):
	pass

    def getError(self, error):
	title = ''
	content = ''
	d = xbmcgui.Dialog()
	if dbg == 'true':
	    log.info('Errors - getError()')
	for i in range(len(ERRORS)):
	    log.info('Errors - getError()[for] ' + ERRORS[i][0] + ' = ' + error)
	    if ERRORS[i][0] in error:
		log.info('Errors - getError()[for] ' + ERRORS[i][0] + ' = ' + error)
		title = ERRORS[i][1]
		content1 = ERRORS[i][2]
		content2 = error
		break
	    elif (i + 1) == len(ERRORS):
		title = t(55900)
		content1 = t(55906)
		content2 = error
	d.ok(title, content1, content2)
