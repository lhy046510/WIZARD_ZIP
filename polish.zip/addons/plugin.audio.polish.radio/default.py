 # -*- coding: utf-8 -*-
import sys, os, xbmcaddon, string

ptv = xbmcaddon.Addon()
scriptID = ptv.getAddonInfo('id')
scriptname = ptv.getAddonInfo('name')
language = ptv.getLocalizedString
t = sys.modules[ "__main__" ].language
dbg = ptv.getSetting('default_debug') in ("true")

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
sys.path.append( os.path.join( ptv.getAddonInfo('path'), "hosts" ) )

import sdLog, sdSettings, sdParser, sdServiceInfo, sdNavigation

import stations, mpr, ninateka, rmf, polskastacja, openfm, polskieradio, planetafm

log = sdLog.pLog()

#ToDo:
#- napraw historię wyszukiwania!

RADIO_ONLINE = {
	100:["Stacje radiowe [alfabetycznie]", 'alfabet'],
	101:["Stacje radiowe [wg gatunku]", 'gatunek'],
	102:["Stacje radiowe [wg regionu]", 'region'],
	103:["Stacje radiowe [wg nadawcy]", 'nadawca'],
	104:["Wyszukaj", 'szukaj'],
	105:["Historia wyszukiwania", 'historia']
}
AUDIO_TABLE = {
	200:["Ninateka", 'ninateka'],
	201:["Moje Polskie Radio", 'mpr'],
	202:["RMF", 'rmf'],
        203:["PolskaStacja", 'polskastacja'],
        204:["Open FM", 'openfm'],
        205:["Polskie Radio", 'polskieradio'],
        206:["Planeta FM", 'planetafm']
}

class PolishRadio:
    def __init__(self):
	log.info('Starting: '+scriptname)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.gui = sdNavigation.sdGUI()

    def CATEGORIES(self):
	self.gui.addDir({'mode': 1, 'title': 'Stacje radiowe', 'icon': self.setIcon("stacjeradiowe")})
	self.gui.addDir({'mode': 2, 'title': 'Programy audio', 'icon': self.setIcon("program")})
	self.gui.addDir({'mode': 21, 'title': 'Informacje o serwisach', 'icon': self.setIcon("info")}, False)
	self.gui.addDir({'mode': 20, 'title': 'Ustawienia', 'icon': self.setIcon("ustawienia")}, False)
	self.gui.endDir()

    def setIcon(self, icon):
	return os.path.join(ptv.getAddonInfo('path'), "images/") + icon + '.png'

    def showListOptions(self):
	params = self.parser.getParams()
	mode = self.parser.getIntParam(params, "mode")
	name = self.parser.getParam(params, "name")
	service = self.parser.getParam(params, 'service')

	self.parser.debugParams(params, True)

	if mode == None and name == None and service == None:
	    log.info('Wyświetlam kategorie')
	    self.CATEGORIES()

	elif mode == 1:
	    self.LIST(RADIO_ONLINE)
	elif (mode >= 100 and mode < 200) or service == 'stations':
	    radio = stations.StreamStations()
	    radio.handleService()

	elif mode == 2:
	    self.LIST(AUDIO_TABLE)
	elif mode == 200 or service == AUDIO_TABLE[200][1]:
	    radio = ninateka.Ninateka()
	    radio.handleService()
	elif mode == 201 or service == AUDIO_TABLE[201][1]:
	    radio = mpr.mojePolskieRadio()
	    radio.handleService()
	elif mode == 202 or service == AUDIO_TABLE[202][1]:
	    radio = rmf.RMF()
	    radio.handleService()
	elif mode == 203 or service == AUDIO_TABLE[203][1]:
	    radio = polskastacja.PolskaStacja()
	    radio.handleService()
	elif mode == 204 or service == AUDIO_TABLE[204][1]:
	    radio = openfm.OpenFM()
	    radio.handleService()
	elif mode == 205 or service == AUDIO_TABLE[205][1]:
	    radio = polskieradio.PolskieRadio()
	    radio.handleService()
	elif mode == 206 or service == AUDIO_TABLE[206][1]:
	    radio = planetafm.PlanetaFM()
	    radio.handleService()

	elif mode == 20:
	    log.info('Wyświetlam ustawienia')
	    self.settings.showSettings()
	elif mode == 21:
	    log.info('Wyświetlam service info')
	    si = sdServiceInfo.ServiceInfo()
	    si.getWindow()

    def LIST(self, table = {}):
	for num, tab in table.items():
	    try:
		icon = self.setIcon(tab[1])
	    except:
		icon = self.setIcon("stacjeradiowe")
	    self.gui.addDir({'mode': num, 'title': string.capwords(tab[0]), 'icon': icon})
	self.gui.endDir()

init = PolishRadio()
init.showListOptions()
