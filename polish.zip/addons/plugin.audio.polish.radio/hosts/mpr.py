# -*- coding: utf-8 -*-
import string, sys
import os, simplejson as json
import xbmcaddon, xbmc

ptv = xbmcaddon.Addon()
scriptID = ptv.getAddonInfo('id')
scriptname = ptv.getAddonInfo('name')

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg

SERVICE = 'mpr'
LOGOURL = os.path.join(ptv.getAddonInfo('path'), "images/") + SERVICE + '.png'

IDKEY = '20439fdf-be66-4852-9ded-1476873cfa22'
API_URL = 'http://moje.polskieradio.pl/api/'

CHAN_URL = API_URL + '?key=' + IDKEY + '&output=json'
CAT_URL = API_URL + 'categories/?key=' + IDKEY + '&output=json'
swfUrl = 'http://moje.polskieradio.pl/_swf/player.swf'

SERVICE_MENU_TABLE = {
	0:'Słowo',
	1:'Muzyka',
	2:'Kategorie',
	3:'Wszystkie kanały'
}

class mojePolskieRadio:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.gui = sdNavigation.sdGUI()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()

    def setTable(self):
	return SERVICE_MENU_TABLE

    def listsMainMenu(self, table):
	for i in range(len(table)):
	    params = {'service': SERVICE, 'name': 'main-menu','category': table[i], 'title': table[i], 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def getAudioData(self, url):
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	result_object = json.loads(data)
	channelTab = result_object["channel"]
	for i in range(len(channelTab)):
	    title = string.capwords(channelTab[i]["title"])
	    #desc = channelTab[i]["description"]
	    image = channelTab[i]["image"]
	    stream = channelTab[i]["streaming_uri"]
	    #category = channelTab[i]["category"]
	    playPath = channelTab[i]["streaming_channel"]
	    if title != '' and stream != '' and playPath != '':
		rtmpTab = stream.split(playPath)
                rtmp = rtmpTab[0]
                rtmp += ' swfUrl=' + swfUrl
               #rtmp += ' pageUrl=' + pageUrl
                rtmp += ' playpath=' + playPath
                rtmp += ' swfVfy=true'
                rtmp += ' live=true'
		params = {'service': SERVICE, 'title': title.encode('UTF-8'), 'page': rtmp, 'icon' : image}
		self.gui.playAudio(params, False)
	self.gui.endDir()

    def listsCategories(self, url):
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	result_object = json.loads(data)
	categoryTab = result_object["category"]
	for i in range(len(categoryTab)):
	    cid = categoryTab[i]["id"]
	    name = categoryTab[i]["name"]
	    self.gui.addDir({'service': SERVICE, 'name': 'cat-menu','category': cid, 'title': name.encode('UTF-8')})
	self.gui.endDir()

    def handleService(self):
        params = self.parser.getParams()
	mode = self.parser.getIntParam(params, "mode")
        name = self.parser.getParam(params, "name")
	category = self.parser.getParam(params, "category")
        page = self.parser.getParam(params, "page")
	title = self.parser.getParam(params, "title")
	self.parser.debugParams(params, dbg)

	if name == None:
	    self.listsMainMenu(self.setTable())

	if category == self.setTable()[0]:
	    url = CHAN_URL + '&category=slowo'
	    self.getAudioData(url)

	if category == self.setTable()[1]:
	    url = CHAN_URL + '&category=muzyka'
	    self.getAudioData(url)

	if category == self.setTable()[2]:
	    self.listsCategories(CAT_URL)

	if name == 'cat-menu':
	    url = CHAN_URL + '&subcategory='+category
	    self.getAudioData(url)

	if category == self.setTable()[3]:
	    self.getAudioData(CHAN_URL)

	if name == 'playSelectedAudio':
	    self.gui.LOAD_AND_PLAY_AUDIO(page, title)