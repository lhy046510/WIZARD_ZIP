# -*- coding: utf-8 -*-
import string, sys
import os, simplejson as json
import xbmcaddon, xbmc

ptv = xbmcaddon.Addon()
scriptID = ptv.getAddonInfo('id')
scriptname = ptv.getAddonInfo('name')

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg

SERVICE = 'polskastacja'

API_URL = 'http://tv.polskastacja.pl/samsung/'
CHAN_URL = 'http://tv.polskastacja.pl/samsung/index.php?action=playlist&chan='

class PolskaStacja:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.gui = sdNavigation.sdGUI()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()

    def listsStations(self, url):
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	result_object = json.loads(data)
	for i in range(len(result_object)):
	    stream = 'http://' + result_object[i]["stream_url"]
	    title = result_object[i]["title"].encode('UTF-8')
	    #ids = result_object[i]["id"]
	    image = result_object[i]["icon"]
	    params = {'service': SERVICE, 'page': stream, 'title': title, 'icon' : image}
	    self.gui.playAudio(params, False)
	self.gui.endDir()

    def handleService(self):
        params = self.parser.getParams()
	mode = self.parser.getIntParam(params, "mode")
        name = self.parser.getParam(params, "name")
	category = self.parser.getParam(params, "category")
        page = self.parser.getParam(params, "page")
	title = self.parser.getParam(params, "title")
	self.parser.debugParams(params, dbg)

	if name == None:
	    self.listsStations(API_URL)

	if name == 'playSelectedAudio':
	    self.gui.LOAD_AND_PLAY_AUDIO(page, title)
