# -*- coding: utf-8 -*-
import string, sys
import os, simplejson as json
import xbmcaddon, xbmc

ptv = xbmcaddon.Addon()
scriptID = ptv.getAddonInfo('id')
scriptname = ptv.getAddonInfo('name')

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg

SERVICE = 'polskieradio'

API_URL = 'http://moje.polskieradio.pl/api/?key=d590cafd-31c0-4eef-b102-d88ee2341b1a'

class PolskieRadio:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.gui = sdNavigation.sdGUI()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()

    def listsStations(self, url):
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	result_object = json.loads(data)
	obj = result_object["channel"]
	for i in range(len(obj)):
            title = obj[i]["title"].encode('UTF-8')
	    image = obj[i]["image"]
	    stream = obj[i]["AlternateStationsStreams"]
	    for i in range(len(stream)):
                mp3 = stream[i]["name"]
                if mp3 == 'MP3-AAC':
                    link = stream[i]["link"]
	    params = {'service': SERVICE, 'page': link, 'title': title, 'icon' : image}
	    self.gui.playAudio(params, False)
	self.gui.endDir()

    def handleService(self):
        params = self.parser.getParams()
	mode = self.parser.getIntParam(params, "mode")
        name = self.parser.getParam(params, "name")
	category = self.parser.getParam(params, "category")
        page = self.parser.getParam(params, "page")
	title = self.parser.getParam(params, "title")
	self.parser.debugParams(params, dbg)

	if name == None:
	    self.listsStations(API_URL)

	if name == 'playSelectedAudio':
	    self.gui.LOAD_AND_PLAY_AUDIO(page, title)
