RadioMA Addon for XBMC
========================
version 1.0

### Summary ###
This is a plugin for [XBMC](http://xbmc.org) that enables you to listen to the
Moroccan radio stations that are broadcasting online.

### Setup/Installation ###
The plugin should be available in the official XBMC addon repository. You can
install it within XBMC.

Contact: <ayoubuto@gmail.com> or [Apolikamixitos](http://twitter.com/Apolikamixitos) on <http://twitter.com>.
