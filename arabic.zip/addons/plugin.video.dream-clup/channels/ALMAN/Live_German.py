# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString


fileName="Live_German"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

a='rtmp://server101-yt.stream-company.org/live/'
b=' swfUrl=http://www.yourtv.to/js/jwplayer.flash.swf pageUrl=http://www.yourtv.to/online/live/fernsehen/stream/'
c='.html'
d='http://www.yourtv.to/img/data/channels/'
e='.gif'
f=' live=1'
k=''
t='rtmp://server101-yt.stream-company.org/live/ playpath='

yenit='http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg'

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #Live='http://www.yourtv.to/'
        yeni='http://www.live-stream.tv/'
        #hasbah='http://01.gen.tr/HasBahCa_IPTV/GERMAN_DEUTSCH.m3u'
        #araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B] German TV List [/B][/COLOR]', "hasbah(url)", hasbah,yenit)
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] Your TV List [/B][/COLOR]', "Livee(url)", Live,"http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg")
        link=araclar.get_url(yeni)
        match=re.compile('<a href="(.*?)" title="(.*?) Online Live Stream TV">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src="(.*?)" ').findall(link)
        for url,name,t in match:
                url='http://www.live-stream.tv'+url+'#tab2-tab'
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [/B][/COLOR]'+'[COLOR lightblue][B]' + name+'[/B][/COLOR]',"yeni(name,url)",url,t)             
        
def Livee(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="/online/live/fernsehen/stream/(.*?).html" title=".*?Online Live Stream">').findall(link)
        for x in match:
                name=x
                name=Liveeename_fix(name)
                url=a+x+b+x+c+f
                url=t+x+b+x+c+f
                thumbnail=d+x+e
                araclar.addLink('[COLOR beige][B]>> '+name+' [/B][/COLOR]',url,thumbnail)

def Liveeename_fix(x):        
        x=x.replace('aaa','bbb').replace("-",' ')
        return x[0].capitalize() + x[1:]


def yeni(name,url):
        link=araclar.get_url(url)
        match=re.compile(' src=&quot;http://embed.live-stream.tv/(.*?)&quot;').findall(link)
        for url2 in match:
                idi=url2
                url2='http://embed.live-stream.tv/'+url2
                link=araclar.get_url(url2)
                match=re.compile('streamer\|(.*?)\|server').findall(link)
                for server in match:
                        url='rtmp://'+server+'.stream-server.org:1935/live playpath='+idi+'.stream swfUrl=http://static.live-stream.tv/player/player.swf pageUrl=http://www.live-stream.tv/online/fernsehen/'+idi+'.html#tab2-tab live=1'
                        playList.clear()
                        araclar.addLink(name,url,yenit)
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

def hasbah(url):
        link=araclar.get_url(url)
        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link)
        if match >0:
                del match[0]

                for name,url in match:
                        araclar.addDir(fileName,'[COLOR beige][B]' + name+'[/B][/COLOR]',"VIDEOLINKS2(name,url)",url,'http://us.cdn1.123rf.com/168nwm/kaarsten/kaarsten1101/kaarsten110100156/8588091-cheering-blonde-woman-with-german-flag-all-on-white-background.jpg')

def VIDEOLINKS2(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

##################
