# -*- coding: utf-8 -*-
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import araclar, cozucu
from BeautifulSoup import BeautifulSoup
Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
addon_icon    = __settings__.getAddonInfo('icon')
images = 'special://home/addons/plugin.video.dream-clup/resources/images/'
FILENAME = "HDIZLE"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        araclar.addDir(FILENAME,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "hdfilmsitesiSearch()", "",images+"search.png")
        araclar.addDir(FILENAME,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "hdfilmsitesiRecent(url)", "http://www.hdfilmsitesi.com/",images+"yeni.png")
        araclar.addDir(FILENAME,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Turkce Dublaj[/B][/COLOR]', "hdfilmsitesiRecent(url)", "http://www.hdfilmsitesi.com/izle/filmler/yabanci-filmler/turkce-dublaj-filmler","")
        araclar.addDir(FILENAME,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]TR Altyazili[/B][/COLOR]', "hdfilmsitesiRecent(url)", "http://www.hdfilmsitesi.com/izle/filmler/yabanci-filmler/turkce-altyazili-filmler","")
        araclar.addDir(FILENAME,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Boxset Filmler[/B][/COLOR]', "hdfilmsitesiRecent(url)", "http://www.hdfilmsitesi.com/izle/boxset-filmler","")
        araclar.addDir(FILENAME,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]IMDB 7.0 Uzeri[/B][/COLOR]', "hdfilmsitesiRecent(url)", "http://www.hdfilmsitesi.com/izle/filmler/yabanci-filmler/imdb-7-ve-uzeri-filmler","")

def hdfilmsitesiRecent(Url):
        sayfagit=Url
        link=araclar.get_url(Url)
        match=re.compile('<a href="(.*?)"><img class="lazy" src=".*?" data-original="(.*?)" alt="(.*?)" width="144" height="185" />').findall(link)
        for url,thumbnail,name in match:
                name=name.replace('&#8211','').replace('&#8217','')
                araclar.addDir(FILENAME,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "hdfilmsitesitek(url,name,thumbnail)",url,thumbnail)
        match1=re.compile('\t<a href="(.*?)"><img src="(.*?)" alt="(.*?)" width="132" height="172" />').findall(link)
        for url,thumbnail,name in match1:
                name=name.replace('&#8211','').replace('&#8217','')
                araclar.addDir(FILENAME,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "hdfilmsitesitek(url,name,thumbnail)",url,thumbnail)			
        #############      ^^^^SAYFAYAGIT^^^^      #############
        araclar.addDir(FILENAME,'[COLOR blue][B]SAYFAYA GIT[/B][/COLOR]', "hdfilmsitesigit(url)",sayfagit,"anasayfa")
		
        #############      ^^^^ANASAYFA^^^^      #############
        araclar.addDir(FILENAME,'[COLOR red][B]ANA SAYFA[/B][/COLOR]', "main()",Url,"anasayfa")
def hdfilmsitesiRecent2(Url):
        sayfagit=Url
        link=araclar.get_url(Url)
        match=re.compile('\t<a href="(.*?)"><img src="(.*?)" alt="(.*?)" width="132" height="172" />').findall(link)
        for url,thumbnail,name in match:
                name=name.replace('&#8211','').replace('&#8217','')
                araclar.addDir(FILENAME,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "hdfilmsitesitek(url,name,thumbnail)",url,thumbnail)			
        #############      ^^^^SAYFAYAGIT^^^^      #############
        araclar.addDir(FILENAME,'[COLOR blue][B]SAYFAYA GIT[/B][/COLOR]', "hdfilmsitesigit(url)",sayfagit,"anasayfa")
		
        #############      ^^^^ANASAYFA^^^^      #############
        araclar.addDir(FILENAME,'[COLOR red][B]ANA SAYFA[/B][/COLOR]', "main()",Url,"anasayfa")

def hdfilmsitesigit(Url):
        gelengit = Url
        if 'page' in gelengit:
            page1=re.compile('(.*?)/page/.*?').findall(gelengit)
            for url in page1:
                git=url
        else:
            git=gelengit
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=name_fix(query)
            Url = (git+'/page/'+query)
            return hdfilmsitesiRecent(Url)

def hdfilmsitesitek(url,name,thumbnail):
        thumbnail=str(thumbnail)
        print 'gelen resim     .::::', thumbnail
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("ul", {"class": "postTabs", "style": "display:none", })
        liste=BeautifulSoup(str(panel))
        for li in liste.findAll('li'):
            a=li.find('a')
            url= a['href']
            name2= li.text
            name2=name2.encode('utf-8', 'ignore')
            araclar.addDir(FILENAME,'[COLOR orange][B] >> [COLOR blue]'+str(name2)+'[COLOR orange] >> [/COLOR][COLOR lightblue]'+str(name)+'[/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)

def hdfilmsitesiSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=name_fix(query)
			
        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----HDFILMSITESI-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.hdfilmsitesi.com/'+'?s='+query)
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"class": "manset-bg"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "filmbg"})
            for i in range (len (panel)):
                # print panel[i]
                url=panel[i].find('a')['href']
                name=panel[i].find('a')['title'].encode('utf-8', 'ignore')
                thumbnailgelen=panel[i].find('a')
                thumbnail=thumbnailgelen.find('img')['src'].encode('utf-8', 'ignore')
                thumbnail=thumbnail.replace('//img.hd', 'http://img.hd')
                # print thumbnail
                araclar.addDir(FILENAME,'[COLOR cyan][B]'+replace_fix(name)+'[/B][/COLOR]', "hdfilmsitesitek(url,name,thumbnail)",url,thumbnail)
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]hdfilmsitesi Acilamadi[/B][/COLOR]")')

        araclar.addDir(FILENAME,'[COLOR yellow][B]YENI ARAMA YAP[/B][/COLOR]', "hdfilmsitesiSearch()","","Search")
        araclar.addDir(FILENAME,'[COLOR red][B]ANA SAYFAYA GIT[/B][/COLOR]', "main()",Url,"anasayfa")


def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('src=".*?vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)



        mailru=re.compilematch=re.compile('movieSrc":   "(.*?)"').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                #print url
                urlList.append(url)


        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
            
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]
        
def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&')
        return x
