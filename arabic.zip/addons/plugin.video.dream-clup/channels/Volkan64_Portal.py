# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver
import time

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Volkan64_Portal"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
vtvt='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0X0NhbmxpX1RWLnBuZw=='
vrdt='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1JhZHlvX1NlZmFzaS5wbmc='
bundest='aHR0cDovL3VwbG9hZC53aWtpbWVkaWEub3JnL3dpa2lwZWRpYS9jb21tb25zL3RodW1iLzIvMmUvRmF1eF9kcmFwZWF1X2dlcm1hbm8tdHVyYy5zdmcvODAwcHgtRmF1eF9kcmFwZWF1X2dlcm1hbm8tdHVyYy5zdmcucG5n'
urll='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0Lw=='
urlll='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0L0FsbWFuQ2FubGkv'
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        vtv='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0L1ZvbGthbjY0X0NhbmxpX1RWLnhtbA=='
        vrd='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0L1JhZHlvX1NlZmFzaS54bWw='
        url='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0Lw=='
        bundes='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L1ZvbGthbjY0L0FsbWFuQ2FubGkv'
        
        araclar.addDir(fileName,'[COLOR orange][B]>>> Volkan Canli TV ~~[/B][/COLOR][COLOR red] [B]>>>>[/B][/COLOR][COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]', "vtv(name,url)",(base64.b64decode(vtv)),(base64.b64decode(vtvt)))
        araclar.addDir(fileName,'[COLOR lightyellow][B]>>> Volkan Canli Radyo ~~[/B][/COLOR][COLOR red] [B]>>>>[/B][/COLOR][COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]', "vtv(name,url)",(base64.b64decode(vrd)),(base64.b64decode(vrdt)))
        araclar.addDir(fileName,'[COLOR lightblue][B]>>>[COLOR red] Volkan Bundes Republic ~~[/B][/COLOR][COLOR lightyellow] [B]>>>>[/B][/COLOR][COLOR orange]OTO GUNCEL [/COLOR][COLOR lightyellow]<<<<[/COLOR]', "bundes(url)",(base64.b64decode(bundes)),(base64.b64decode(bundest)))
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<li><a href="(.*?).png"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>\n').findall(link)
        for url,thumbnail in match:
                name=url
                thumbnail=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.png'
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,thumbnail)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
        match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)

def vtv(name,url):
        link=araclar.get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for videoTitle,Thumbnail,Url in match:
                addVideoLink(videoTitle,Url,Thumbnail)
##        for name,thumbnail,url in match:
##                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail)
        match1=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail)


def bundes(url):
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>').findall(link)
        for t,url in match:
                name=url
                t=(base64.b64decode(urlll))+url.encode('utf-8', 'ignore')+t
                url=(base64.b64decode(urlll))+url.encode('utf-8', 'ignore')+'.xml'
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"bundesicerik(name,url)",url,t)

def bundesicerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for name,t,url in match:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,t)

def yeni4(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
        
def UrlResolver_Player(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
######--ERGUN BURADAN BASLIYOR-------------#####
def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        link=link.replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xc3\xbc',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"?").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
        response.close()
        return link

def addFolder(FILENAME, videoTitle, method, url="", thumbnail="",fanart=""):
        u = sys.argv[0]+"?fileName="+urllib.quote_plus(FILENAME)+"&videoTitle="+urllib.quote_plus(videoTitle)+"&method="+urllib.quote_plus(method)+"&url="+urllib.quote_plus(url)+"&fanart="+urllib.quote_plus(fanart)
        if thumbnail != "":
                thumbnail = os.path.join(IMAGES_PATH, thumbnail+".png")
        liz = xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz.setProperty( "Fanart_Image", fanart )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    

def addVideoLink(linkTitle, url, thumbnail=""):
    liz = xbmcgui.ListItem(linkTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
    liz.setInfo(type="Video", infoLabels={"Title":linkTitle})
    liz.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
###BURAYA KADAR ####################################################
