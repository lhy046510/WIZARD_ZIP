# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,base64,os,base64,sys,xbmc,urlresolver
import cozucu, araclar

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName = "BELGESELTV"

from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        belgeselizle='http://www.belgeselizle.net/'
        #araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "belgeselizleSearch()", "","search")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenenler [/B][/COLOR]', "belgeselizleRecent(url)",belgeselizle,"yeni")

                ##### KATEGORILERI OKU EKLE #######
        link=araclar.get_url(belgeselizle)
        soup = BeautifulSoup(link)
        panel = soup.findAll("li", {"id": "categories-3"})
        liste=BeautifulSoup(str(panel))
        for li in liste.findAll('li'):
            a=li.find('a')
            url= a['href']
            name= li.text
            name=name.encode('utf-8', 'ignore')
            araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "belgeselizleRecent(url)",url,"")

def belgeselizleRecent(Url):
        link=araclar.get_url(Url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"id": "videos"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "video"})
        for i in range (len (panel)):
            gelenbelgeselizle=panel[i].find("div", {"class": "thumb"})
            url=gelenbelgeselizle.find('a')['href']
            name=gelenbelgeselizle.find('a')['title'].encode('utf-8', 'ignore')
            thumbnail=gelenbelgeselizle.find('img')['src'].encode('utf-8', 'ignore')
            araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
				
        #############    SONRAKI SAYFA  >>>> #############
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        for Url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "belgeselizleRecent(url)",Url,"next")

        #############     ONCEKI SAYFA  <<<< #############
        page2=re.compile('<a href=\'(.*?)\' class=\'page smaller\'>.*?</a><span class=\'current\'>.*?</span>').findall(link)
        for Url in page2:
                araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa[/B][/COLOR]', "belgeselizleRecent(url)",Url,"onceki")

        #############      ^^^^ANASAYFA^^^^      #############
        araclar.addDir(fileName,'[COLOR red][B]ANA SAYFA[/B][/COLOR]', "main()",Url,"anasayfa")	
				
########	?	ARAMA	?	########
def belgeselizleSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=name_fix(query)
			
        try:
            araclar.addDir(fileName,'[COLOR blue][B]-----belgeselizle-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.belgeselizle.net/'+'?s='+query)
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "videos"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "video"})
            for i in range (len (panel)):
                    
                    
                    gelenbelgeselizle=panel[i].find("div", {"class": "thumb"})
                    url=gelenbelgeselizle.find('a')['href']
                    name=gelenbelgeselizle.find('a')['title'].encode('utf-8', 'ignore')
                    thumbnail=gelenbelgeselizle.find('img')['src'].encod
                    araclar.addDir(fileName,'[COLOR green][B]>> - [/B][/COLOR]'+name, "VIDEOLINKS(name,url)",url,thumbnail)

            #############    SONRAKI SAYFA  >>>> #############
            page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
            for Url,name in page:
                    araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "belgeselizleRecent(url)",Url,"next")

            #############     ONCEKI SAYFA  <<<< #############
            page2=re.compile('<a href=\'(.*?)\' class=\'page smaller\'>.*?</a><span class=\'current\'>.*?</span>').findall(link)
            for Url in page2:
                    araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa[/B][/COLOR]', "belgeselizleRecent(url)",Url,"onceki")
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]SKY Center[/B][/COLOR]","[COLOR yellow][B]belgeselizle Acilamadi[/B][/COLOR]")')

        araclar.addDir(fileName,'[COLOR yellow][B]YENI ARAMA YAP[/B][/COLOR]', "belgeselizleSearch()","","Search")
        araclar.addDir(fileName,'[COLOR red][B]ANA SAYFAYA GIT[/B][/COLOR]', "main()",Url,"anasayfa")
########   linkleri topla   ########
def belgeselizlevideolinks(url,name):
	araclar.addDir(fileName,'[COLOR red]'+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")
	link=araclar.get_url(url)
	soup = BeautifulSoup(link)
	panel = soup.findAll("div", {"class": "keremiya_part"})
	match=re.compile('href="(.*?)"><span>(.*?)</span>').findall(str(panel[0]))
	for url,name in match:
		araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,"")						

						
'''#############################################################################################'''
'''#############################################################################################'''
#######################################    VIDEO    ###############################################

def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

        mynet=re.compile('<iframe class="mynetVideoEmbed" src="(.*?)"').findall(link)
        for url2 in mynet:
                link=araclar.get_url(url2)
                match=re.compile('<source src="(.*?)"').findall(link)
                for url in match:
                        playList.clear()
                        playList.add(name)
                        araclar.addLink(name,url,'')
		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#        
        vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        for url in divxstage:
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        	#---------------------------------------------#
        youtube2=re.compile(' src="//www.youtube.com/embed/(.*?)" ').findall(link)
        for url in youtube2:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        for url in movshare:
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
        for url,uploadcgelen in uploadc:
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                #print url
                cozucu.magix_player(name,url)

        #-------------------------------
        mailru4=re.compile('"movieSrc":   "mail/(.*?)"').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                cozucu.magix_player(name,url)
        #-------------------------------
                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru5:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
        for url,divxstagegelen in divxstage:
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value

def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def MAINMENU(Url):
         araclar.addDir(fileName,'[COLOR yellow][B]ANA SAYFA[/B][/COLOR]',"main()",'http://www.skymc.com/','')
