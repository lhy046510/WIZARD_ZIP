# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="UK_Thomas_Bouquet"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

hgbein='http://www.hqsport.tv/sky_sports1.php'
tlc='http://202.75.23.34:8800/live/ch35/01.m3u8'
thomast='aHR0cDovL2kwLndwLmNvbS93d3cudHNtcGx1Zy5jb20vd3AtY29udGVudC91cGxvYWRzLzIwMTMvMDYvVFYtQ2hhbm5lbHMtYnJvYWRjYXN0aW5nLUVuZ2xpc2gtUHJlbWllci1MZWFndWUtMjAxMy0yMDE0LmpwZw=='

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        ukiptv='http://en.iphone-tv.eu/channels/uk'
        get='http://skysport.tv/movie/sky-movies-action-live-stream.php'#22
        fifaembed='aHR0cDovL2hhcHB5ZmVldHMubmV0NzgubmV0L3dvcmRwcmVzcy9hbGluYWNha2tvZC9GaWZhRW1iZWQueG1s'
        skysportstv='aHR0cDovL3hibWN0ci5jb20va29kY3UvdGFta29kL1NreVNwb3J0c1RWLnhtbA=='
        skymovies='aHR0cDovL3hibWN0ci5jb20va29kY3UvdGFta29kL1NreU1vdmllcy54bWw='
        serverstreamhd='http://streamhd.eu/'
        serverfifa='http://www.fifaembed.com'
        serverhq='http://hqsport.tv/euro_sport1.php'
        
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR pink][B]Server StreamHD [/B][/COLOR]',"streamhd(url)",serverstreamhd,'')
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR yellow][B]Server Fifa [/B][/COLOR]',"fifa(url)",serverfifa,'')        
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR orange][B]Server HQ [/B][/COLOR]',"hq(url)",serverhq,(base64.b64decode(thomast)))
        

##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR pink][B] Thomas Movies [/B][/COLOR]','multibulucusky(url)',get,'http://4.bp.blogspot.com/-kwT1nw0etf8/UtZqVLNBlbI/AAAAAAAADQg/m2RSvXt-H2I/s320/SKY.jpeg')
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR orange][B]Yerli Navix [/B][/COLOR]','update(url)',update2,"http://skystreamx.com/wp-content/uploads/2013/11/script.navi-x.png")
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Yerli Navixstreme-2 [/B][/COLOR]','navixiki(url)',navixiki,"http://www.xbmchub.com/blog/wp-content/uploads/navi-x.png")
##        addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR red][B]Being Sports [/B][/COLOR]',being,16,"http://skystreamx.com/wp-content/uploads/2013/11/script.navi-x.png")
##        addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR beige][B]Thomas Sports [COLOR blue] >>>[/COLOR][COLOR orange] HQ [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]',hq,1,'special://home/addons/plugin.video.HappyFeets.Thomas/icon.png')
##        addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR lightblue][B]Thomas Sports [COLOR blue]>>>[/COLOR][COLOR orange] Embed [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]', hdembed,10,'special://home/addons/plugin.video.HappyFeets.Thomas/icon.png')
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightyellow][B] N-Joy [/B][/COLOR]','njoy(url)',njoy,"http://media-cdn.tripadvisor.com/media/photo-s/04/87/40/06/njoy-bar-and-restaurant.jpg")        
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B] Ann UK TV [/B][/COLOR]','bobliste(url)',ukiptv,"http://www.radioandtelly.co.uk/images/freeviewchannels.jpg")        

def streamhd(url):
        link=araclar.get_url(url)
        match=re.compile('<strong>(.*?)</strong>').findall(link)
        for name in match:
                url=url
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','streamhdschedule(url)',url,(base64.b64decode(thomast)))

def streamhdschedule(url):
        link=araclar.get_url(url)
        match=re.compile('<p><strong>(.*?) <a  href="(.*?)">(.*?)</a><br />\n<p>').findall(link)
        for name,url,kanal in match:
                name=name+' '+'[COLOR yellow]'+kanal+'[/COLOR]'
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','streamhdicerik(name,url)',url,(base64.b64decode(thomast)))
        url2='http://streamhd.eu/menu.html'
        link=araclar.get_url(url2)
        match1=re.compile('\t\t<li><a href="(.*?)" target="_top">(.*?)</a></li>\n ').findall(link)
        if match1 >0:
                del match1[0]
                
                for url,name in match1:
                        url='http://streamhd.eu'+url
                        araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR lightgreen][B]'+name+'[/B][/COLOR]','streamhdicerik(name,url)',url,(base64.b64decode(thomast)))

def streamhdicerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<iframe class="video"  src="(.*?)" ').findall(link)
        for url2 in match:
                url2='http://streamhd.eu/'+url2
                link=araclar.get_url(url2)
                match=re.compile(' fid="(.*?)"; ').findall(link)
                for playpath in match:
                        #rtmpe://46.246.124.3:1935/live/ app=live/ playpath=sskys1 swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive.php?u=sskys1&vw=854&vh=480&domain=streamhd.eu live=1
                        url='rtmpe://46.246.124.30:1935/live/ app=live/ playpath='+playpath+' swfUrl=http://www.hdcast.org/j2/jwplayer.flash.swf token=#yw%tt#w@kku pageUrl=http://www.hdcast.org/embedlive.php?u='+playpath+'&vw=854&vh=480&domain=streamhd.eu live=1'
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)
#############################################################################################################
#############################################################################################################
#############################################################################################################
def fifa(url):
        link=araclar.get_url(url)
        match=re.compile('<li id="menu-item-.*?" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-.*?"><a href="(.*?)">(.*?)</a></li>').findall(link)
        if match >0:
                del match[0]
        
                for url,name in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','fifaicerik(name,url)',url,(base64.b64decode(thomast)))

def fifaicerik(name,url):
        link=araclar.get_url(url)
        link=link.replace('#038;','')
        match=re.compile('<iframe src=\'(.*?)\' ').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile('file: "(.*?)"').findall(link)
                for url in match:                        
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

                match1=re.compile('fid="(.*?)"; ').findall(link)
                for playpath in match1:
                        #rtmpe://89.248.172.52/live app=live playpath=chelseatvfifaembed swfUrl=http://www.dcast.tv/player6/jwplayer.flash.swf token=%ZZri(nKa@#Z pageUrl=http://www.dcast.tv/embed.php?u=chelseatvfifaembed&vw=650&vh=480 live=1
                        url='rtmpe://89.248.172.52/live app=live playpath='+playpath+' swfUrl=http://www.dcast.tv/player6/jwplayer.flash.swf token=%ZZri(nKa@#Z pageUrl=http://www.dcast.tv/embed.php?u='+playpath+'&vw=650&vh=480 live=1'
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)
#############################################################################################################
#############################################################################################################
#############################################################################################################
def hq(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)"><img src="(.*?)" width="120" height="23" align="center" border="0" alt=""/></a>').findall(link)
        if match >0:
                del match[0]
        
                for url,t in match:
                        name=url
                        name=name.replace('/','').replace('_',' ').replace('.php','')
                        url='http://hqsport.tv'+url
                        t='http://hqsport.tv'+t
                        araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','fifaicerik(name,url)',url,(base64.b64decode(thomast)))

def hqicerik(name,url):
        link=araclar.get_url(url)
        link=link.replace('#038;','')
        match=re.compile('<iframe src=\'(.*?)\' ').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile('file: "(.*?)"').findall(link)
                for url in match:                        
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

                match1=re.compile('fid="(.*?)"; ').findall(link)
                for playpath in match1:
                        #rtmpe://89.248.172.52/live app=live playpath=chelseatvfifaembed swfUrl=http://www.dcast.tv/player6/jwplayer.flash.swf token=%ZZri(nKa@#Z pageUrl=http://www.dcast.tv/embed.php?u=chelseatvfifaembed&vw=650&vh=480 live=1
                        url='rtmpe://89.248.172.52/live app=live playpath='+playpath+' swfUrl=http://www.dcast.tv/player6/jwplayer.flash.swf token=%ZZri(nKa@#Z pageUrl=http://www.dcast.tv/embed.php?u='+playpath+'&vw=650&vh=480 live=1'
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)
#############################################################################################################
#############################################################################################################
#############################################################################################################
def fifaembed(url):
        link=araclar.get_url(url)
        match=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n        <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>').findall(link)
        for name,url in match:
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','oynat(name,url)',url,(base64.b64decode(thomast)))
        

def oynat(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul  
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,(base64.b64decode(thomast)))
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
