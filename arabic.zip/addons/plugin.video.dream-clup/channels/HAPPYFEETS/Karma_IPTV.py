#-*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
   
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
   
fileName ="Karma_IPTV"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 

canlitvt='aHR0cDovL3d3dy51c2VybG9nb3Mub3JnL2ZpbGVzL2xvZ29zL2lnb3IyMy9saXZldHZfYmxhY2sucG5n'
   
def main(): 
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul

        url='http://iptv-tv.blogspot.co.uk/'
        
##        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]Canli_Turkish[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(url)),(base64.b64decode(canlitvt)))
##        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]Canli_English[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(url1)),(base64.b64decode(canlitvt)))
##        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]Canli_Sport[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(url2)),(base64.b64decode(canlitvt)))
         
##        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]IP TV Liste-1[/I][/B][/COLOR] ', "iptvlinks(url)",iptv,"http://www.userlogos.org/files/logos/igor23/livetv_black.png")
##
##def iptvlinks(url):
        link=araclar.get_url(url)
        match=re.compile('<meta content=\'(.*?)\' itemprop=\'image_url\'/>\n<meta content=\'.*?\' itemprop=\'blogId\'/>\n<meta content=\'.*?\' itemprop=\'postId\'/>\n<a name=\'.*?\'></a>\n<h3 class=\'post-title entry-title\' itemprop=\'name\'>\n<a href=\'(.*?)\'>(.*?)</a>\n</h3>').findall(link)
        for t,url,name in match:
                araclar.addDir(fileName,'[COLOR red]''>> ''[COLOR lightblue] '+ name+'[/COLOR]',"iptvlinkicerik(url)",url,t)
##        page=re.compile(' class=\'feed-link\' href=\'(.*?)\'').findall(link)
##        for url2 in page:
##                link=araclar.get_url(url2)
##                link=link.replace=(':','%3A')
                

def iptvlinkicerik(url):
        link=araclar.get_url(url)
        link=link.replace('amp;','')
        thumbnail=re.compile('<link href=\'(.*?)\' rel=\'image_src\'/>').findall(link)
        for t in thumbnail:
                print t
        bir=re.compile('#EXTINF:-.*?,(.*?)<br />(.*?)<br />').findall(link)
        for name,url in bir:
            araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR] '+ name,"yeni4(name,url)",url,t)
        iki=re.compile('\n#EXTINF:-.*?,(.*?)<br />\n(.*?)<br />').findall(link)
        for name,url in iki:
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]> [/B][/COLOR]'+ name,"yeni4(name,url)",url,t) 
        uc=re.compile('<br />#EXTINF:-1,(.*?) &#8211; (.*?)<br />').findall(link)
        for name,url in uc:
            araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]> [/B][/COLOR]'+ name,"yeni4(name,url)",url,t)
        dort=re.compile('<br />#EXTINF:-1, (.*?)<br />(.*?)<br />').findall(link)
        for name,url in dort:
            araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]> [/B][/COLOR]'+ name,"yeni4(name,url)",url,t)
        bes=re.compile('<br />(.*?)<br />rtmp:\/\/\$OPT\:rtmp\-raw\=(.*?)<br />').findall(link)
        for name,url in bes:
            araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]> [/B][/COLOR]'+ name,"yeni4(name,url)",url,t)
        alti=re.compile('\n(.*?)<br />\n(.*?)<br />').findall(link)
        for name,url in alti:
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]> [/B][/COLOR]'+ name,"yeni4(name,url)",url,t)
        yedi=re.compile('#EXTINF:.*?,(.*?)<br />(.*?)<br').findall(link)
        for name,url in yedi:
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]> [/B][/COLOR]'+ name,"yeni4(name,url)",url,t)

def yeni4(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
