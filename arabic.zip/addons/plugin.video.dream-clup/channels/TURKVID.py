# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="TURKVID"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

web = 'http://turkvid.com/'
############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://turkvid.com/'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        #araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "tek(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR beige][B]Diziler [/B][/COLOR]', "Dublaj(url)","http://turkvid.com/diziler.php","")
        araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR] [COLOR pink][B]Yarisma Programlari [/B][/COLOR]', "Edit(url)","http://turkvid.com/bolumler.php?sayi=5","")
        araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR] [COLOR lightgreen][B]Spor [/B][/COLOR]', "Edit(url)","http://turkvid.com/bolumler.php?sayi=1","")
        ##### KATEGORILERI OKU EKLE ##########################
        
        link=araclar.get_url(url)
        match=re.compile('\n\t\t\t<a href="(.*?)" class="b3">Filimler</a>').findall(link)
        for url in match:
                url=web+url                
                araclar.addDir(fileName,'[COLOR orange][B]>>[/B][/COLOR] [COLOR beige][B]Filmler[/B][/COLOR]'+'',"Yeni(url)",url,"")
        match1=re.compile('\n\t\t\t<a href="(.*?)" class="b3">Fragman</a>').findall(link)
        for url in match1:
                url=web+url                
                araclar.addDir(fileName,'[COLOR purple][B]>>[/B][/COLOR][COLOR yellow][B] Fragman[/B][/COLOR]'+'',"Yeni(url)",url,"")

###################################################################                

                                                
######                       
#def Search():
        #keyboard = xbmc.Keyboard("", 'Search', False)
        #keyboard.doModal()
        #if keyboard.isConfirmed():
            #query = keyboard.getText()
            #url = ('http://turkvid.com/ara.php'+query)
            #tek(url)

############
def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('\n\t\t<a href="(.*?)">\n\t\t\t<h1 id="hepsi" href="hepsi" style="margin-bottom:10px;">(.*?)</h1>').findall(link)
        for url,name in match:
                url=web+url
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"Yerli(url)",url,'')

                          
        
###########        
def Edit(url):
        link=araclar.get_url(url)       
        match1=re.compile('<a class="as" href="(.*?)" title="(.*?)">(.*?)</a>').findall(link)
        for url,thumbnail,name in match1:
                url=web+url
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightblue][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
                                
###########
def Dublaj(url):
        link=araclar.get_url(url)  
        match=re.compile('<a class="as" href="(.*?)" itemprop="name" itemscope itemtype="http://schema.org/TVSeries">(.*?)</a>').findall(link)
        for url,name in match:
                url=web+url
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"Edit(url)",url,'')
                



def Yerli(url):
        link=araclar.get_url(url)  
        match=re.compile('<a class="as" href="(.*?)" title="(.*?)">(.*?)</a>').findall(link)
        for url,thumbnail,name in match:
                url=web+url
                araclar.addDir(fileName,'[COLOR brown][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
                
              
      
def tek(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)" class="dehliza">\n        <img class="dehlizresim" src="(.*?)"/><br />\n        <p class="dy"style="">(.*?)</p></a>').findall(link)
        for url,thumbnail,name in match:
                url=web+url
                araclar.addDir(fileName,'[COLOR yellow][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        
#############
def VIDEOLINKS(name,url):
        link=araclar.get_url(url)  
        match=re.compile('src="http://embed.nowvideo.eu/(.*?)&').findall(link)
        print match
        for url in match:
                url='http://embed.nowvideo.eu/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')
        match=re.compile('src="http://vk.com/(.*?)"').findall(link)
        print match
        for url in match:
                url='http://vk.com/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')
        match=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        print match
        for url in match:
                url='http://www.youtube.com/embed/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')      

        

