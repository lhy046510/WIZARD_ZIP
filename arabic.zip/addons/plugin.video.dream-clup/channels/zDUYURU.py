# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver,time

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="zDUYURU"

def main():
        url='http://forum.xbmctr.com'
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR lightgreen][B]%80 i Avrupada Yasayan 4bin den Fazla Kullaniciya Buradan Ulasabilirsiniz[/B][/COLOR]',"",url,'special://home/addons/plugin.video.dream-clup/resources/images/uye.jpg')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/reklam2.gif')
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR cyan][B] Reklam ALIMLARIMIZ Baslamistir[/B][/COLOR]',"",url,'special://home/addons/plugin.video.dream-clup/resources/images/reklam1.jpg')
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR yellow][B] Sponsor ALIMLARIMIZ Baslamistir[/B][/COLOR]',"",url,'special://home/addons/plugin.video.dream-clup/resources/images/reklam2.gif')
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR orange][B] Detayli Bilgi icin [COLOR violet]ADMIN[/COLOR][COLOR orange] lerimize Ulasabilirsiniz. [/B][/COLOR]',"",url,'special://home/addons/plugin.video.dream-clup/resources/images/admin.jpg')
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR tomato][B]Yasal Sorumluluklar / Legality [/B][/COLOR]',"yasal()",url,'special://home/addons/plugin.video.dream-clup/resources/images/legal.png')

song=__settings__.getSetting("base")
        
def yasal():
        class AnaPencere(xbmcgui.WindowDialog):
            def __init__(self):
                self.addControl(xbmcgui.ControlImage(200,100,900,600, 'special://home/addons/plugin.video.dream-clup/resources/images/yasal.png'))
                xbmc.Player().play(song)
                self.button = xbmcgui.ControlButton(500, 600, 200, 100, '[COLOR red][B]'+'ONAYLIYORUM'+'[/B][/COLOR]')
                self.addControl(self.button)
                self.setFocus(self.button)

            def onControl(self, event):
                if event == self.button:
                    self.close()

        W = AnaPencere()
        W.doModal()
        kapa = xbmc.Player().stop(song)
        del W, kapa
