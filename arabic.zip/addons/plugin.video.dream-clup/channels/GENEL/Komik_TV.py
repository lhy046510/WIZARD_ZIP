# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Komik_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

komikt='http://trandroid.com/wp-content/uploads/b512-300x300.png'
urll='aHR0cDovL3d3dy5rb21pa2xlci5jb20='
urlll='aHR0cDovL3d3dy5rb21pa2xlci5jb20va29taWt0di8='

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+'' 
        url='aHR0cDovL3d3dy5rb21pa2xlci5jb20va29taWt0di9pbmRleC5waHA/ZnI9a3Rk'
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<li class="leftMenuItem"><a href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
            url=(base64.b64decode(urll))+url
            name=replace_fix(name)
            araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]','icerik(url)',url,komikt)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('\n\t\t\t\t\t\t\t<a href="(.*?)"><img src="(.*?)"  alt="(.*?)"').findall(link)
        for url,t,name in match:
            url=(base64.b64decode(urll))+url
            name=replace_fix(name)
            araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]','oynat(name,url)',url,t)
        page=re.compile('<span class=busayfa>.*?</span> <a href ="(.*?)">.*?</a>').findall(link)
        for url in page:
            url=(base64.b64decode(urlll))+url
            name='Sonraki Sayfa'
            araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR green]'+name+'[/B][/COLOR]','icerik(url)',url,komikt)

def oynat(name,url):
        link=araclar.get_url(url)
        match=re.compile('<div class="oroll_video" title="{file:\'(.*?)\'').findall(link)
        for url in match:
            playList.clear()
            araclar.addLink(name,url,komikt)
        if playList:
                xbmcPlayer.play(playList)

def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('\xe7', 'c').replace('\xfc', 'u').replace('\xdd', 'I').replace('\xc7', 'C').replace('\xf6', 'o').replace('\xfe', 's').replace('\xfd', 'i').replace('\xdc', 'U')#.replace('\xdc', 'U')
        return x
