# -*- coding: utf-8
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re,sys, urllib, urllib2,time,datetime,os
import comuns

dbversao=00011
MEOURL = 'http://www.meocanaltv.com'
RedwebURL = 'http://www.redweb.tv'
SptveuURL = 'http://www.gosporttv.com/'
TVDezURL = 'http://www.estadiofutebol.com'
TVGenteURL = 'http://www.tvgente.eu'
TVTugaURL = 'http://www.tvtuga.com'
TugastreamURL = 'http://www.tugastream.com/'
TVPTHDURL = 'http://www.tvportugalhd.eu'
TVPTHDZuukURL = 'http://www.zuuk.pw'
TVCoresURL = 'http://tvfree.me'
LSHDURL= 'http://livesoccerhq.com'
TVZuneURL = 'http://www.tvzune.tv/'
TVZune2URL = 'http://soft.tvzune.co/'
RTPURL='http://www.rtp.pt'
VBURL= 'http://www.videosbacanas.com/'
ResharetvURL = 'http://resharetv.com/'
AltasEmocoesURL='http://www.altas-emocoes.com/'
DesgrURL = 'http://www.desportogratis.com/'
SurflineURL= 'http://www.surfline.com'
user_agent = 'Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36'
addon_id = 'plugin.video.tvpor'
art = '/resources/art/'
selfAddon = xbmcaddon.Addon(id=addon_id)
tvporpath = selfAddon.getAddonInfo('path')#.decode('utf-8') damn spch!
cachepath = os.path.join(tvporpath,'resources','cache')
menuescolha = xbmcgui.Dialog().select
mensagemok = xbmcgui.Dialog().ok
mensagemprogresso = xbmcgui.DialogProgress()
pastaperfil = xbmc.translatePath(selfAddon.getAddonInfo('profile'))#.decode('utf-8') damn spch!
downloadPath = selfAddon.getSetting('pastagravador')
pleasewait='Por favor aguarde. '
activado=False
activadoextra=[]
debug=[]

def dbver():
    return dbversao

def info_servidores():
    mensagemprogresso.create('A capturar fontes','A carregar lista de servidores.',pleasewait)
    if selfAddon.getSetting("fontes-desportogratis") == "true":
        try:
            mensagemprogresso.update(6,'',pleasewait + '(Desporto Grátis)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                desgrlink=comuns.limparcomentarioshtml(comuns.abrir_url(DesgrURL,erro=False),DesgrURL)
                desgrfinal='\n'.join(re.compile('<td>(.+?)</td>').findall(desgrlink))
            else:
                desgrfinal=comuns.openfile('desgratis',pastafinal=cachepath)
            comuns.savefile('desgratis', desgrfinal)
        except: comuns.savefile('desgratis', '')
    if selfAddon.getSetting("fontes-meocanaltv") == "true":
        try:
            mensagemprogresso.update(12,'',pleasewait + '(MEOCanal TV)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                rtplink=comuns.abrir_url(MEOURL)
                rtpfinal='\n'.join(re.compile('<a href=(.+?)/a>').findall(rtplink))
            else:
                rtpfinal=comuns.openfile('meocanaltv',pastafinal=cachepath)    
            comuns.savefile('meocanaltv', rtpfinal)
        except: comuns.savefile('meocanaltv', '')

    if selfAddon.getSetting("fontes-rtpplay") == "true":
        try:
            mensagemprogresso.update(25,'',pleasewait + '(RTP Play)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                rtplink=comuns.limparcomentarioshtml(comuns.abrir_url(RTPURL + '/play/direto',erro=False),RTPURL + '/play/direto')
                rtpfinal='\n'.join(re.compile('<li class="LiveTVLogo"(.+?)</li>').findall(rtplink))
            else:
                rtpfinal=comuns.openfile('rtpplay',pastafinal=cachepath)
            comuns.savefile('rtpplay', rtpfinal)
        except: comuns.savefile('rtpplay', '')

    if selfAddon.getSetting("fontes-thesporttveu") == "true":
        try:
            mensagemprogresso.update(37,'',pleasewait + '(Thesporttv.eu)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                sptveulink=comuns.abrir_url(SptveuURL,erro=False)
                if re.search('<script>window.location=',sptveulink) or re.search('jdfwkey',sptveulink):
                    try:
                        key=re.compile('<script>window.location="/(.+?)";</script>').findall(sptveulink)[0]
                        sptveulink=comuns.abrir_url(SptveuURL + key,erro=False)
                    except: pass
                sptvfinal='\n'.join(re.compile('<th scope="col">(.+?)</th>').findall(sptveulink))
            else:
                sptvfinal=comuns.openfile('thesporttveu',pastafinal=cachepath) 
            comuns.savefile('thesporttveu', sptvfinal)
        except: comuns.savefile('thesporttveu', '')
    if selfAddon.getSetting("fontes-tugastream") == "true":
        try:
            mensagemprogresso.update(50,'',pleasewait + '(Tugastream)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                tugastreamlink=comuns.abrir_url(TugastreamURL,erro=False)
            else:
                tugastreamlink=comuns.openfile('tugastream',pastafinal=cachepath) 
            comuns.savefile('tugastream', tugastreamlink)
        except: comuns.savefile('tugastream', '')
    if selfAddon.getSetting("fontes-tvacores") == "true":
        try:
            mensagemprogresso.update(62,'',pleasewait + '(TV a Cores)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                ref_data = {'Referer': TVCoresURL,'User-Agent':user_agent}
                post = {'limit':'0','filter_order':'','filter_order_Dir':'','limitstart':''}
                tvacoreslink=comuns.clean(comuns.abrir_url_tommy(TVCoresURL + '/ver',ref_data,form_data=post,erro=False))
                tvcfinal='\n'.join(re.compile('<strong class="list-title">(.+?)</strong>').findall(tvacoreslink))
            else:
                tvcfinal=comuns.openfile('tvacores',pastafinal=cachepath) 
            comuns.savefile('tvacores', tvcfinal)
        except: comuns.savefile('tvacores', '')
    if selfAddon.getSetting("fontes-tvdez") == "true":
        try:
            mensagemprogresso.update(75,'',pleasewait + '(TVDez)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                tvdezlink= comuns.clean(comuns.abrir_url_cookie(TVDezURL,erro=False))
                tvdezfinal='\n'.join(re.compile('<div class="canal">(.+?)</div>').findall(tvdezlink))
            else:
                tvdezfinal=comuns.openfile('tvdez',pastafinal=cachepath) 
            comuns.savefile('tvdez', tvdezfinal)
        except: comuns.savefile('tvdez', '')
    if selfAddon.getSetting("fontes-tvgente") == "true":
        try:
            mensagemprogresso.update(83,'',pleasewait + '(TVGente)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            #if selfAddon.getSetting("forcarloading") == "true":
            tvgentelink= comuns.clean(comuns.abrir_url_cookie(TVGenteURL + '/front.php',erro=False))
            tvgentefinal='\n'.join(re.compile('onclick="window.open(.+?)/></a>').findall(tvgentelink))
            #else:
            #    tvdezfinal=comuns.openfile('tvgente',pastafinal=cachepath) 
            comuns.savefile('tvgente', tvgentefinal)
        except: comuns.savefile('tvgente', '')

    if selfAddon.getSetting("fontes-tvtuga") == "true":
        try:
            mensagemprogresso.update(87,'',pleasewait + '(TVTuga)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                tvtugalink=comuns.abrir_url_cookie(TVTugaURL + '/category/portugal/',erro=False)
                tvtugafinal='\n'.join(re.compile('<option class="ddpl-form2" (.+?)/option>').findall(tvtugalink))
            else:
                tvtugafinal=comuns.openfile('tvtuga',pastafinal=cachepath)
            comuns.savefile('tvtuga', tvtugafinal)
        except: comuns.savefile('tvtuga', '')
    if selfAddon.getSetting("fontes-tvzune2") == "true":
        #try:
        #    mensagemprogresso.update(87,'',pleasewait + '(TVZune)')
        #    if mensagemprogresso.iscanceled(): sys.exit(0)
            #if selfAddon.getSetting("forcarloading") == "true":
            #    tvzunelink=comuns.clean(comuns.abrir_url_cookie(TVZuneURL,erro=False))
            #    tvzunefinal='\n'.join(re.compile('parent.Player.location.href=(.+?)</a>').findall(tvzunelink))
        #    comuns.savefile('tvzune', tvzunefinal)
        #except: comuns.savefile('tvzune', '')
        try:
            mensagemprogresso.update(87,'',pleasewait + '(TVZune)')
            if mensagemprogresso.iscanceled(): sys.exit(0)
            if selfAddon.getSetting("forcarloading") == "true":
                tvzunefinal=comuns.clean(comuns.abrir_url(TVZune2URL + 'ver.txt',erro=False))
            else:
                tvzunefinal=comuns.openfile('tvzune2',pastafinal=cachepath)
            comuns.savefile('tvzune2', tvzunefinal)
        except: comuns.savefile('tvzune2', '')
    if selfAddon.getSetting("prog-lista3") == "true": mensagemprogresso.update(100,'A carregar listas de programação.','Por favor aguarde. ')

def request_servidores(url,name,tamanho=0):
    #if name=='[B]Eventos[/B] (Cesarix/Rominhos)':
    #    obter_lista(name,url)
    #    return

    nomelista=name
    name=name.replace('[','-')
    nome=re.compile('B](.+?)/B]').findall(name)[0]
    nomega=nome.replace('-','')
    comuns.GA("listacanais",nomega)
    titles=[]; ligacao=[]

    if url=='nada' and activado==True: todosact(nomelista)
    else:


        ### CASOS ESPECIAIS ###

        if re.search('Caça e Pesca',nomelista) or re.search('Toros TV',nomelista):
            titles.append('Pontucanal')
            ligacao.append('http://verlatelegratis.com')

        if re.search('Sporting TV',nomelista):
            titles.append('Altas Emoções')
            ligacao.append(AltasEmocoesURL)
            
        #    try:
        #        torosref=int(0)
        #        temp=re.compile('<div class="video">(.+?)</div>').findall(comuns.clean(comuns.abrir_url('http://plusligaonline.com/ver-canal-plus-toros-online-opcion-2/')))[0]
        #        toros=re.compile('<a href="(.+?)"').findall(temp)
        #        if toros:
        #            for codigo in toros:
        #                torosref=int(torosref + 1)
        #                if len(toros)==1: toros2=str('')
        #                else: toros2=' #' + str(torosref)
        #                titles.append('Plus Liga Online' + toros2)
        #                ligacao.append(codigo)
        #    except: pass


        ########################################DESPORTOGRATIS############################
        if selfAddon.getSetting("fontes-desportogratis") == "true":
            try:
                desgrref=int(0)
                desgrlink=comuns.openfile('desgratis')
                nomedesgr=nome.replace('SPORTTV 1-','1.html').replace('SPORTTV 2-','2.html').replace('SPORTTV 3-','3.html').replace('SPORTTV 4-','4.html').replace('SPORTTV 5-','4.html').replace('SPORTTV LIVE-','4.html').replace('Benfica TV 1-','5.html').replace('Benfica TV 2-','5.html')
                desgr=re.compile('<a href="http://www.desportogratis.com/'+nomedesgr+'" target="iframe"><form>').findall(desgrlink)
                if desgr:
                    for resto in desgr:
                        desgrref=int(desgrref + 1)
                        if len(desgr)==1:
                            desgr2=str('')
                        else:
                            desgr2=' #' + str(desgrref)
                        titles.append('Desporto Grátis' + desgr2)
                        ligacao.append('http://www.desportogratis.com/' + nomedesgr)
                        
            except: pass

        if selfAddon.getSetting("fontes-meocanaltv") == "true":
            try:
                meocanaltv=False
                meocanaltvref=int(0)
                meocanaltvlink=comuns.openfile('meocanaltv')
                nomemeocanaltv=nome.replace('RTP 1-','RTP 1').replace('RTP 2-','RTP 2').replace('RTP Informação-','RTP INFORMACAO').replace('RTP Africa-','RTP AFRICA').replace('RTP Madeira-','RTP MADEIRA').replace('RTP Internacional-','RTP INTERNACIONAL').replace('RTP Açores-','RTP ACORES').replace('RTP Memória-','RTP MEMORIA').replace('SIC-','SIC').replace('TVI-','TVI').replace('SPORTTV 1-','Sport TV em Direto').replace('Big Brother VIP-','BB VIP').replace('SIC K-','SIC KIDS').replace('SIC Radical-','SIC RADICAL').replace('SIC Mulher-','SIC MULHER').replace('SIC Noticias-','SIC NOTICIAS Online').replace('TVI24-','TVI 24').replace('Hollywood-','HOLLYWOOD').replace('MOV-','CANAL MOV').replace('AXN-','AXN').replace('AXN Black-','AXN BLACK').replace('AXN White-','AXN WHITE').replace('FOX-','FOX').replace('FOX Crime-','FOX CRIME').replace('FOX Life-','FOX LIFE').replace('FOX Movies-','FOX MOVIES').replace('Canal Panda-','CANAL PANDA').replace('Discovery Channel-','DISCOVERY CHANNEL').replace('Eurosport-','EUROSPORT 1').replace('Benfica TV 1-','Benfica TV online').replace('Benfica TV 2-','Benfica TV online').replace('Porto Canal-','PORTO CANAL').replace('Syfy-','SYFY').replace('Odisseia-','CANAL ODISSEIA').replace('História-','CANAL HISTÓRIA').replace('National Geographic Channel-','NATIONAL GEOGRAPHIC').replace('MTV-','MTV').replace('Disney Channel-','DISNEY CHANNEL').replace('Panda Biggs-','PANDA BIGGS').replace('Motors TV-','MOTORS TV').replace('ESPN-','ESPN Online BR').replace('ESPN America-','ESPN Online BR').replace('A Bola TV-','A BOLA TV').replace('Casa dos Segredos 4-','Secret Story 4 em Direto').replace('CM TV-','CM TV').replace('TVI Ficção-','TVI FICCAO').replace('Panda Biggs-','Panda Biggs').replace('Económico TV-','Económico TV - Emissão Online').replace('Disney Junior-','Canal Disney Junior').replace('TV Record-','Record Online ao Vivo').replace('Discovery Turbo-','Discovery Turbo Brasil').replace('Caça e Pesca-','Caza y Pesca').replace('Mais TVI-','+TVI').replace('Eurosport 2-','EUROSPORT 2')
                meocanaltv=re.compile('"(.+?)">%s<' % (nomemeocanaltv)).findall(meocanaltvlink)
                if meocanaltv:
                    for codigo in meocanaltv:
                        meocanaltvref=int(meocanaltvref + 1)
                        if len(meocanaltv)==1: meocanaltv2=str('')
                        else: meocanaltv2=' #' + str(meocanaltvref)
                        titles.append('MEOCanal TV' + meocanaltv2)
                        ligacao.append(MEOURL + codigo)
            except: pass



        ########################################LIVESOCCERHD############################
        #if selfAddon.getSetting("fontes-livesoccerhd") == "true":
        #    try:
        #        lshdref=int(0)
        #        lshdlink=comuns.openfile('livesoccerhd')
        #        nomelshd=nome.replace('SPORTTV 1-','SPTV 1').replace('SPORTTV 2-','SPTV 2').replace('SPORTTV 3-','SPTV 3').replace('SPORTTV 4-','SPTV LIVE').replace('SPORTTV LIVE-','SPTV LIVE').replace('Benfica TV 1-','BENFICA TV').replace('Benfica TV 2-','BENFICA TV')
        #        lshd=re.compile("href='(.+?)'>.+?</span>"+nomelshd+".+?/span>").findall(lshdlink)
        #        if lshd:
        #            for resto in lshd:
        #                lshdref=int(lshdref + 1)
        #                if len(lshd)==1:
        #                    lshd2=str('')
        #                else:
        #                    lshd2=' #' + str(lshdref)
        #                titles.append('LivesoccerHD' + lshd2)
        #                ligacao.append(resto)
        #                
        #    except: pass

        ########################################REDWEB############################
        #if selfAddon.getSetting("fontes-redwebtv") == "true":
        #    try:
        #        redwebref=int(0)
        #        redweblink=comuns.openfile('redwebtv')
        #        nomeredweb=nome.replace('RTP 1-','RTP1').replace('RTP 2-','RTP 2').replace('FOX-','FOX').replace('AXN-','AXN').replace('AXN Black-','AXN BLACK').replace('AXN White-','AXN WHITE').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX MOVIES').replace('SPORTTV 3-','Sport TV 3').replace('SPORTTV LIVE-','Sporttv Live').replace('Canal Panda-','panda').replace('Hollywood-','CANAL HOLLYWOOD').replace('Eurosport-','Eurosport').replace('MOV-','MOV').replace('VH1-','VH1').replace('Porto Canal-','PORTO CANAL').replace('SIC Radical-','Sic Radical').replace('SIC Mulher-','SIC MULHER').replace('SIC K-','SIC K').replace('TVI Ficção-','TVI FICÇÃO').replace('Benfica TV 1-','Benfica TV').replace('Benfica TV 2-','Benfica TV').replace('Discovery Channel-','Discovery').replace('TVI24-','TVI24').replace('Mais TVI-','Mais TVI').replace('Syfy-','SYFY').replace('Odisseia-','Odisseia').replace('História-','CANAL HISTORIA').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV').replace('CM TV-','CM Tv').replace('RTP Açores-','RTP Açores').replace('RTP Informação-','RTP INFORMAÇÃO').replace('RTP Madeira-','RTP Madeira').replace('RTP Memória-','RTP Mem&oacute;ria').replace('Disney Channel-','Disney Channel').replace('Fashion TV-','Fashion TV').replace('Disney Junior-','Disney Junior').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','motors tv').replace('ESPN-','ESPN').replace('ESPN America-','ESPN').replace('A Bola TV-','ABOLA TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP INTERNACIONAL').replace('RTP Memória-','RTP Mem&oacute;ria').replace('RTP Açores-','RTP A&ccedil;ores').replace('Casa dos Segredos 4-','Casa dos segredos 4').replace('Panda Biggs-','Panda Biggs').replace('SIC-','SIC').replace('TVI-','TVI').replace('SIC Noticias-','SIC NOTÍCIAS')
        #        redweb=re.compile("mudaCanal\('"+nomeredweb+"','(.+?)','(.+?)'").findall(redweblink)
        #        if redweb:
        #            for codigo,imagem in redweb:
        #                redwebref=int(redwebref + 1)
        #                if len(redweb)==1: redweb2=str('')
        #                else: redweb2=' #' + str(redwebref)
        #                titles.append('RedWeb.tv' + redweb2)
        #                ligacao.append(RedwebURL + '/monitor.php?c=' + nomeredweb + '&s=' + codigo + '&i=' + imagem + '&')
        #    except: pass

        ########################################RTPPLAY############################
        if selfAddon.getSetting("fontes-rtpplay") == "true":
            try:
                rtpplay=False
                rtpplayref=int(0)
                rtpplaylink=comuns.openfile('rtpplay')
                nomertpplay=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('RTP Informação-','rtpinformacao').replace('RTP Africa-','rtpafrica').replace('RTP Madeira-','rtpmadeira').replace('RTP Internacional-','rtpinternacional').replace('RTP Açores-','rtpacores').replace('RTP Memória-','rtpmemoria')
                rtpplay=re.compile('id="' + nomertpplay + '" title=".+?" href="(.+?)">').findall(rtpplaylink)
                if rtpplay:
                    for codigo in rtpplay:
                        rtpplayref=int(rtpplayref + 1)
                        if len(rtpplay)==1: rtpplay2=str('')
                        else: rtpplay2=' #' + str(rtpplayref)
                        titles.append('RTP Play' + rtpplay2)
                        ligacao.append(RTPURL + codigo)
            except: pass



        ########################################THESPORTTVEU############################
        if selfAddon.getSetting("fontes-thesporttveu") == "true":
            try:
                sptveuref=int(0)
                sptveulink=comuns.openfile('thesporttveu')
                nomesptveu=nome.replace('SPORTTV 1-','Sporttv1').replace('SPORTTV 1 HD-','Sporttv1-v').replace('SPORTTV 2-','Sporttv2').replace('SPORTTV 3-','Sporttv3').replace('SPORTTV 4-','Sporttv-live').replace('SPORTTV LIVE-','Sporttv-live').replace('Benfica TV 1-','Benficatv').replace('Benfica TV 2-','Benficatv').replace('TVI-','Tvi')
                sptveu=re.compile('<a href="' + nomesptveu + '(.+?)" target="_blank"><img src=').findall(sptveulink)
                if sptveu:
                    for resto in sptveu:
                        sptveuref=int(sptveuref + 1)
                        if len(sptveu)==1:
                            sptveu2=str('')
                        else:
                            sptveu2=' #' + str(sptveuref)
                        titles.append('Thesporttv.eu' + sptveu2)
                        ligacao.append(SptveuURL + nomesptveu + resto)
                        
            except: pass


        ########################################TV A CORES############################
        if selfAddon.getSetting("fontes-tvacores") == "true":
            try:
                tvacoresref=int(0)
                tvacoreslink=comuns.openfile('tvacores')
                nometvacores=nome.replace('RTP 1-','RTP 1 Online').replace('RTP 2-','RTP 2 Online').replace('SIC-','SIC Online').replace('TVI-','TVI Online').replace('SPORTTV 1-','Sport TV em Direto').replace('Big Brother VIP-','BB VIP').replace('SIC K-','SIC K Online').replace('SIC Radical-','SIC Radical Online').replace('SIC Mulher-','SIC Mulher Online').replace('SIC Noticias-','SIC Noticias Online').replace('TVI24-','TVI24 online').replace('Hollywood-','Canal Hollywood').replace('MOV-','Canal MOV').replace('AXN-','AXN Portugal').replace('AXN Black-','AXN Black Online').replace('AXN White-','AXN White online').replace('FOX-','Fox Online PT').replace('FOX Crime-','FOX Crime Online').replace('FOX Life-','FOX Life Online').replace('FOX Movies-','FOX Movies Portugal').replace('Canal Panda-','Canal Panda').replace('Discovery Channel-','Discovery Channel PT').replace('Eurosport-','Eurosport Portugal').replace('Benfica TV 1-','Benfica TV online').replace('Benfica TV 2-','Benfica TV online').replace('Porto Canal-','Porto Canal - Emissão Online').replace('Syfy-','SYFY Channel Portugal').replace('Odisseia-','Canal Odisseia').replace('História-','Canal Historia Portugal').replace('National Geographic Channel-','National Geographic PT').replace('MTV-','MTV Portugal').replace('RTP Açores-','RTP Açores Online').replace('RTP Africa-','RTP África Online').replace('RTP Informação-','RTP Informação - Emissão Online').replace('RTP Madeira-','RTP Madeira Online').replace('RTP Memória-','RTP Memória').replace('Disney Channel-','Disney Portugal').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','Motors TV Online').replace('ESPN-','ESPN Online BR').replace('ESPN America-','ESPN Online BR').replace('A Bola TV-','A Bola TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP Internacional').replace('RTP Açores-','RTP Açores').replace('A Bola TV-','A Bola TV').replace('Casa dos Segredos 4-','Secret Story 4 em Direto').replace('CM TV-','CMTV em direto').replace('TVI Ficção-','TVI Ficção online').replace('Panda Biggs-','Panda Biggs').replace('Económico TV-','Económico TV - Emissão Online').replace('Disney Junior-','Canal Disney Junior').replace('TV Record-','Record Online ao Vivo').replace('Discovery Turbo-','Discovery Turbo Brasil').replace('Caça e Pesca-','Caza y Pesca').replace('Sporting TV-','Sporting TV online')
                tvacores=re.compile('<a href="(.*?)">'+nometvacores+'</a>').findall(tvacoreslink)
                if tvacores:
                    for codigo in tvacores:
                        tvacoresref=int(tvacoresref + 1)
                        if len(tvacores)==1: tvacores2=str('')
                        else: tvacores2=' #' + str(tvacoresref)
                        titles.append('TV a Cores' + tvacores2)
                        ligacao.append(TVCoresURL + codigo)
            except: pass
                  
        ########################################TUGASTREAM############################
        if selfAddon.getSetting("fontes-tugastream") == "true":
            try:
                tugastreamref=int(0)
                tugastreamlink=comuns.openfile('tugastream')
                nometugastream=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('SIC-','sic').replace('AXN Black-','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('SPORTTV 4-','sporttv4').replace('SPORTTV 5-','sporttv5').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('Porto Canal-','portocanal').replace('SIC Noticias-','sicnoticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao').replace('Syfy-','syfy').replace('Benfica TV 1-','benficatv').replace('Benfica TV 2-','benficatv').replace('CM TV-','cmtv').replace('RTP Africa-','rtpafrica').replace('RTP Informação-','rtpinformacao').replace('Fashion TV-','fashiontv').replace('ESPN-','espn').replace('RTP Africa-','rtpafrica').replace('RTP Madeira-','rtpmadeira').replace('RTP Internacional-','rtpinternacional').replace('Casa dos Segredos 4-','secretstory').replace('Económico TV-','economicotv')
                tugastream=re.compile('<a href="'+nometugastream + '(.+?)php">').findall(tugastreamlink)
                if tugastream:
                    for codigo in tugastream:
                        tugastreamref=int(tugastreamref + 1)
                        if len(tugastream)==1: tugastream2=str('')
                        else: tugastream2=' #' + str(tugastreamref)
                        titles.append('Tugastream' + tugastream2)
                        ligacao.append(TugastreamURL + nometugastream + codigo + 'php?altura=432&largura=768')
            except: pass

        ########################################TVGENTE############################
        if selfAddon.getSetting("fontes-tvgente") == "true":
            try:
                tvgenteref=int(0)
                tvgentelink=comuns.openfile('tvgente')
                nometvgente=nome.replace('SPORTTV 1-','sptv1novo.png').replace('SPORTTV 2-','sptv2novo.png').replace('SPORTTV 3-','sptv3novo.png').replace('SPORTTV 4-','jogooo.png').replace('SPORTTV 5-','sptv511.png').replace('Eurosport-','eurosportnovo.png').replace('Eurosport 2-','eurosport2novo.png').replace('ESPN-','espnnovo.png').replace('RTP 1-','1rtp.png').replace('RTP 2-','rtp2novo.png').replace('RTP Informação-','rtpinfonovo.png').replace('RTP Internacional-','rtp intnovo.png').replace('RTP Memória-','memoriartpnovo.png').replace('RTP Açores-','acoresnovortp.png').replace('RTP Madeira-','madeirartpnovo.png').replace('SIC-','sicnovo.png').replace('SIC Noticias-','sicnnovo.png').replace('TVI-','tvinovo.png').replace('TVI24-','tvi24novo.png').replace('Porto Canal-','portonovo.png').replace('Benfica TV 1-','btvnovo.png').replace('Benfica TV 2-','btvnovo.png').replace('Sporting TV-','sportingtv.png').replace('A Bola TV-','biolatv.png').replace('CM TV-','cmtv.png').replace('Económico TV-','ecnovo.png').replace('FOX-','foxnovo.png').replace('Discovery Channel-','discnovo.png').replace('História-','historia')
                tvgente=re.compile("\('(.+?)'.+?<img.+?" +nometvgente + '"').findall(tvgentelink)
                nometvgente=nome.replace('SPORTTV 1-','miga1.png').replace('SPORTTV 2-','miga2.png').replace('SPORTTV 3-','miga3.png').replace('SPORTTV 4-','miga 4.png').replace('SPORTTV 5-','miga5.png').replace('Benfica TV 1-','btv11.png').replace('Benfica TV 2-','btv11.png').replace('SIC Noticias-','hd1sic.png').replace('Sporting TV-','testesporting.png')
                tvgente+=re.compile("\('(.+?)'.+?<img.+?" +nometvgente + '"').findall(tvgentelink)
                if tvgente:
                    for codigo in tvgente:
                        tvgenteref=int(tvgenteref + 1)
                        if len(tvgente)==1: tvgente2=str('')
                        else: tvgente2=' #' + str(tvgenteref)
                        titles.append('TV Gente' + tvgente2)
                        ligacao.append(codigo)
            except: pass

        ########################################TVTUGA############################
        if selfAddon.getSetting("fontes-tvtuga") == "true":
            try:
                tvtugaref=int(0)
                tvtugalink=comuns.openfile('tvtuga')
                
                nometvtuga=nome.replace('RTP 1-','rtp-1').replace('RTP 2-','rtp-2').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('SIC-','sic').replace('AXN Black-','axnblack').replace('AXN White-','axn-white').replace('FOX Life-','fox-life').replace('FOX Crime-','fox-crime').replace('FOX Movies-','fox-movies').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('SPORTTV 4-','sporttvlive').replace('SPORTTV LIVE-','sporttvlive').replace('Canal Panda-','canal-panda').replace('Hollywood-','canal-hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('Porto Canal-','portocanal').replace('SIC Noticias-','sic-noticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvi-ficcao').replace('Syfy-','syfy').replace('Benfica TV 1-','benfica-tv').replace('Benfica TV 2-','benfica-tv').replace('CM TV-','cm-tv').replace('RTP Africa-','rtp-africa').replace('RTP Informação-','rtp-informacao').replace('Fashion TV-','fashiontv').replace('ESPN-','espn').replace('A Bola TV-','abola-tv').replace('Casa dos Segredos 4-','secret-story-4-casa-dos-segredos').replace('RTP Açores-','rtp-acores').replace('RTP Internacional-','rtp-internacional').replace('RTP Madeira-','rtp-madeira').replace('RTP Memória-','rtp-memoria').replace('TVI24-','tvi-24').replace('Panda Biggs-','panda-biggs').replace('Económico TV-','economico-tv').replace('Eurosport 2-','eurosport-2')

                tvtuga=re.compile('value="http://www.tvtuga.com/'+nometvtuga+'(.+?)">').findall(tvtugalink)
                if tvtuga:
                    for codigo in tvtuga:
                        tvtugaref=int(tvtugaref + 1)
                        if len(tvtuga)==1: tvtuga2=str('')
                        else: tvtuga2=' #' + str(tvtugaref)
                        titles.append('TVTuga' + tvtuga2)
                        ligacao.append(TVTugaURL + '/' + nometvtuga + codigo)
            except: pass

                
        ########################################TVDEZ############################
        if selfAddon.getSetting("fontes-tvdez") == "true":
            try:
                tvdezref=int(0)
                tvdezlink=comuns.openfile('tvdez')
                tvdezlink=tvdezlink.replace('+ TVI','Mais TVI')
                nometvdez=nome.replace('RTP 1-','RTP').replace('RTP 2-','RTP 2').replace('FOX-','FOX').replace('AXN-','AXN').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX Movies').replace('SPORTTV 3-','Sport TV 3').replace('SPORTTV 4-','Sport TV 4').replace('SPORTTV 5-','Sport TV 5').replace('SPORTTV LIVE-','Sporttv Live').replace('Canal Panda-','Canal Panda').replace('Hollywood-','Hollywood').replace('Eurosport-','Eurosport').replace('MOV-','Canal MOV').replace('VH1-','VH1 Hits').replace('Porto Canal-','Porto Canal').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC K-','SIC K').replace('TVI Ficção-','TVI Fic&ccedil;&atilde;o').replace('Discovery Channel-','Discovery Channel').replace('TVI24-','TVI 24').replace('Mais TVI-','Mais TVI').replace('Syfy-','Syfy').replace('Odisseia-','Odisseia').replace('História-','Hist&oacute;ria').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV').replace('CM TV-','Correio da Manh&atilde; TV').replace('RTP Açores-','RTP A&ccedil;ores').replace('RTP Informação-','RTP Informa&ccedil;&atilde;o').replace('RTP Madeira-','RTP Madeira').replace('RTP Memória-','RTP Mem&oacute;ria').replace('Disney Channel-','Disney Channel').replace('Fashion TV-','Fashion TV').replace('Disney Junior-','Disney Junior').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','Motors TV').replace('ESPN-','ESPN Brasil').replace('ESPN America-','ESPN').replace('A Bola TV-','A Bola TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP Internacional').replace('RTP Memória-','RTP Mem&oacute;ria').replace('RTP Açores-','RTP A&ccedil;ores').replace('Casa dos Segredos 4-','Casa dos segredos 4').replace('Panda Biggs-','Panda Biggs').replace('Económico TV-','Econ&oacute;mico TV').replace('Chelsea TV-','Chelsea TV').replace('Disney Junior-','Disney Junior').replace('TV Globo-','TV Globo').replace('TV Record-','Rede Record').replace('Eurosport 2-','Eurosport 2')
                tvdez=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                if not tvdez:
                    nometvdez=nome.replace('SPORTTV 1-','Sport TV 1').replace('SPORTTV 2-','Sport TV 2').replace('SIC-','SIC').replace('TVI-','TVI').replace('SIC Noticias-','SIC Not&iacute;cias').replace('Big Brother VIP-','Big Brother VIP 2013').replace('Benfica TV 1-','Benfica TV').replace('Benfica TV 2-','Benfica TV').replace('Casa dos Segredos 4-','Casa dos segredos 4')
                    tvdez=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                    nometvdez=nome.replace('SPORTTV 1-','Sporttv em Directo').replace('SPORTTV 2-','Sporttv 2').replace('SIC-','SIC Online - Stream 2').replace('TVI-','TVI Online - Stream 2').replace('SIC Noticias-','SIC Not&iacute;cias Online').replace('Big Brother VIP-','Big Brother Portugal').replace('Benfica TV 1-','Benfica-TV').replace('Benfica TV 2-','Benfica-TV')
                    tvdez+=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                    nometvdez=nome.replace('SPORTTV 1-','Sporttv HD')
                    tvdez+=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                if tvdez:
                    for codigo in tvdez:
                        tvdezref=int(tvdezref + 1)
                        if len(tvdez)==1: tvdez2=str('')
                        else: tvdez2=' #' + str(tvdezref)
                        titles.append('TVDez' + tvdez2)
                        ligacao.append(TVDezURL + codigo)
            except: pass


        ########################################TVZUNE############################
        if selfAddon.getSetting("fontes-tvzune2") == "true" and activado==False:
            try:
                tvzuneref=int(0)
                #tvzunelink=comuns.openfile('tvzune')
                tvzunelink=comuns.openfile('tvzune2')

                nometvzune=nome.replace('RTP 1-','RTP 1').replace('RTP 2-','RTP 2').replace('SIC-','SIC').replace('SPORTTV 1-','SPORT TV 1').replace('SPORTTV 2-','SPORT TV 2').replace('SPORTTV 3-','SPORT TV 3').replace('TVI-','TVI').replace('FOX-','FOX').replace('AXN-','AXN').replace('Discovery Channel-','discovery').replace('AXN Black','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('TVI24-','tvi24').replace('SIC Noticias-','sicnoticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao')
                tvzune=re.compile("channel.php\?ch=(.+?)'.+?<span>" + nometvzune + "</span>").findall(tvzunelink)

                nometvzune=nome.replace('RTP 1-','checkrtp1').replace('RTP 2-','checkrtp2').replace('FOX-','checkfox').replace('AXN-','checkaxn').replace('AXN Black-','checkaxnblack').replace('AXN White-','checkaxnwhite').replace('FOX Life-','checkfoxlife').replace('FOX Crime-','checkfoxcrime').replace('FOX Movies-','checkfoxmovies').replace('SPORTTV 3-','checksporttv3').replace('SPORTTV 4-','checksporttv4').replace('SPORTTV 5-','checksporttv5premium').replace('SPORTTV LIVE-','checksporttv4').replace('Canal Panda-','checkpanda').replace('Hollywood-','checkhollywood').replace('MOV-','checkmov').replace('Porto Canal-','checkporto').replace('SIC Radical-','checksicradical').replace('SIC Mulher-','checksicmulher').replace('TVI Ficção-','checktvific').replace('Benfica TV 1-','checkbenficatv').replace('Benfica TV 2-','checkbenficatv').replace('Discovery Channel-','checkdiscovery').replace('TVI24-','checktvi24').replace('Mais TVI-','checktvimais').replace('Syfy-','checksyfy').replace('Odisseia-','checkodisseia').replace('História-','checkhistoria').replace('National Geographic Channel-','checknational').replace('MTV-','checkmtv').replace('RTP Açores-','checkrtpa').replace('RTP Informação-','checkrtpi').replace('Disney Channel-','checkdisney').replace('Motors TV-','checkmotors').replace('A Bola TV-','checkbolatv').replace('SPORTTV 1-','checksporttv1').replace('SPORTTV 2-','checksporttv2').replace('SIC-','checksic').replace('TVI-','checktvi').replace('SIC Noticias-','checksicnoticias').replace('Económico TV-','checkeconomico')
                tvzuneextra=comuns.openfile('tvzune2')
                if tvzuneextra and re.search('check',nometvzune):
                    tvzuneref=int(tvzuneref + 1)
                    if len(tvzune)==0: tvzune2=str('')
                    else: tvzune2=' #' + str(tvzuneref)
                    nometvzune=nometvzune.replace('check','')
                    titles.append('TVZune' + tvzune2)
                    ligacao.append(TVZune2URL + 'new/canais/' + nometvzune + '.txt')
                
                if tvzune:
                    for resto in tvzune:
                        tvzuneref=int(tvzuneref + 1)
                        if len(tvzune)==1 and len(titles)==0: tvzune2=str('')
                        else: tvzune2=' #' + str(tvzuneref)
                        titles.append('TVZune' + tvzune2)
                        ligacao.append(TVZuneURL + 'iframe/channel.php?ch=' + resto)
                
            except: pass  

        ######################################TVPORTUGALHD.ORG########################
        #if selfAddon.getSetting("fontes-tvpthdorg") == "true":
        #    try:
        #        nometvpthdorg=nome.replace('RTP 1-','RTP').replace('RTP 2-','RTP 2').replace('SIC-','SIC').replace('SPORTTV 1-','SPORTTV 1').replace('SPORTTV 2-','SPORTTV 2').replace('SPORTTV 3-','SPORTTV 3').replace('SPORTTV LIVE-','SPORTTV Live').replace('SIC-','SIC').replace('TVI-','TVI').replace('FOX-','FOX').replace('AXN-','AXN').replace('Discovery Channel-','Discovery Channel').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX Movies').replace('Canal Panda-','Canal Panda').replace('Hollywood-','Hollywood').replace('Eurosport-','Eurosport').replace('MOV-','MOV').replace('VH1-','VH1').replace('Benfica TV 1-','Benfica TV').replace('Benfica TV 2-','Benfica TV').replace('Porto Canal-','Porto Canal').replace('TVI24-','TVI24').replace('SIC Noticias-','SIC Noticias').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC K-','SIC K').replace('Big Brother VIP-','Big Brother Vip1').replace('TVI Ficção-','TVI Ficção').replace('Syfy-','Syfy').replace('Odisseia-','Odisseia').replace('História-','Historia').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV').replace('RTP Africa-','RTP Africa').replace('RTP Informação-','RTP Informação').replace('RTP Madeira-','RTP Madeira').replace('Disney Channel-','Disney Channel').replace('Panda Biggs-','Panda Biggs').replace('A Bola TV-','A Bola TV').replace('RTP Açores-','RTP Açores').replace('RTP Informação-','RTP Informa&ccedil;&atilde;o').replace('RTP Madeira-','RTP Madeira').replace('Disney Channel-','Disney Channel').replace('Fashion TV-','Fashion TV').replace('Disney Junior-','Disney Junior').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','Motors TV').replace('ESPN-','ESPN').replace('ESPN America-','ESPN America').replace('A Bola TV-','A Bola TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP Internacional').replace('RTP Memória-','RTP Memoria').replace('Casa dos Segredos 4-','Secret Story 4').replace('CM TV-','CMTV').replace('Panda Biggs-','Panda Biggs').replace('Económico TV-','Diario Económico').replace('Chelsea TV-','Chelsea TV').replace('Eurosport 2-','Eurosport 2')
        #        tvpthdorglink=comuns.openfile('tvportugalhd')
        #        tvpthdorgref=int(0)
        #        nometvpthdorg=urllib.quote(nometvpthdorg)
        #        tvpthdorg=re.compile("<a dir='ltr' href='http://www.tvportugalhd.eu/search/label/" + nometvpthdorg + "'>.+?</a>").findall(tvpthdorglink)
        #        reftvpth=1
        #        if not tvpthdorg:
        #            tvpthdorg=re.compile("<a dir='ltr' href='http://www.tvportugalhd.eu/search/label/" + nometvpthdorg + "(.+?)>.+?</a>").findall(tvpthdorglink)
        #            reftvpth=0
        #        if tvpthdorg:
        #            for codigotv in tvpthdorg:
        #                tvpthdorgref=int(tvpthdorgref + 1)
        #                if len(tvpthdorg)==1: tvpthdorg2=str('')
        #                else:
        #                    if tvpthdorgref==1: tvpthdorg2=' #' + str(tvpthdorgref)
        #                    else: tvpthdorg2=' #' + str(tvpthdorgref)# + '[COLOR red] (indisponivel)[/COLOR]'
        #                codigotv=codigotv.replace("'",'')
        #                titles.append('TVPortugal HD.org' + tvpthdorg2)
        #                if reftvpth==1: ligacao.append('http://www.tvportugalhd.eu/search/label/' + nometvpthdorg)
        #                else: ligacao.append('http://www.tvportugalhd.eu/search/label/' + nometvpthdorg + codigotv)
        #    except: pass
        

        #######################

        if len(ligacao)==1: index=0
        elif activado==True: index=0
        elif len(ligacao)==0: ok=mensagemok('TV Portuguesa', 'Nenhum stream disponivel.'); return     
        else: index = xbmcgui.Dialog().select('Escolha o servidor', titles)
        if index > -1:
            if activado==False:
                mensagemprogresso.create('TV Portuguesa', 'A carregar stream. (' + titles[index] + ')','Por favor aguarde...')
                mensagemprogresso.update(0)
                if mensagemprogresso.iscanceled(): mensagemprogresso.close()
                pre_resolvers(titles,ligacao,index,nome)
            else:
                index=-1
                
                for linkescolha in ligacao:
                    index=index+1
                    pre_resolvers(titles,ligacao,index,nome,tamanho=tamanho)
                    
                activadoextra2=set(activadoextra)
                thumb=nome.replace('Mais TVI-','maistvi-ver2.png').replace('AXN-','axn-ver2.png').replace('FOX-','fox-ver2.png').replace('RTP 1-','rtp1-ver2.png').replace('RTP 2-','rtp2-ver2.png').replace('SIC-','sic-ver3.png').replace('SPORTTV 1-','sptv1-ver2.png').replace('SPORTTV 1 HD-','sptv1-ver2.png').replace('SPORTTV 2-','sptv2-ver2.png').replace('SPORTTV 3-','sptv3-ver2.png').replace('SPORTTV 4-','sptv4-ver2.png').replace('SPORTTV LIVE-','sptvlive-ver1.png').replace('TVI-','tvi-ver2.png').replace('Discovery Channel-','disc-ver2.png').replace('AXN Black-','axnb-ver2.png').replace('AXN White-','axnw-ver2.png').replace('FOX Crime-','foxc-ver2.png').replace('FOX Life-','foxl-ver3.png').replace('FOX Movies-','foxm-ver2.png').replace('Eurosport-','eusp-ver2.png').replace('Hollywood-','hwd-ver2.png').replace('MOV-','mov-ver2.png').replace('Canal Panda-','panda-ver2.png').replace('VH1-','vh1-ver2.png').replace('Benfica TV 1-','btv1-ver1.png').replace('Benfica TV 2-','btv2-ver1.png').replace('Porto Canal-','pcanal-ver2.png').replace('Big Brother VIP-','bbvip-ver2.png').replace('SIC K-','sick-ver2.png').replace('SIC Mulher-','sicm-ver3.png').replace('SIC Noticias-','sicn-ver2.png').replace('SIC Radical-','sicrad-ver2.png').replace('TVI24-','tvi24-ver2.png').replace('TVI Ficção-','tvif-ver2.png').replace('Syfy-','syfy-ver1.png').replace('Odisseia-','odisseia-ver1.png').replace('História-','historia-ver1.png').replace('National Geographic Channel-','natgeo-ver1.png').replace('MTV-','mtv-ver1.png').replace('CM TV-','cmtv-ver1.png').replace('RTP Informação-','rtpi-ver1.png').replace('Disney Channel-','disney-ver1.png').replace('Motors TV-','motors-ver1.png').replace('ESPN America-','espna-ver1.png').replace('Fashion TV-','fash-ver1.png').replace('A Bola TV-','abola-ver1.png').replace('Casa dos Segredos 4-','casadseg-ver1.png').replace('RTP Açores-','rtpac-ver1.png').replace('RTP Internacional-','rtpint-ver1.png').replace('RTP Madeira-','rtpmad-ver1.png').replace('RTP Memória-','rtpmem-ver1.png').replace('RTP Africa-','rtpaf-ver1.png').replace('Panda Biggs-','pbiggs-ver1.png').replace('TV Record-','record-v1.png').replace('TV Globo-','globo-v1.png').replace('Eurosport 2-','eusp2-ver1.png').replace('Discovery Turbo-','discturbo-v1.png').replace('Toros TV-','toros-v1.png').replace('Chelsea TV-','chel-v1.png').replace('Disney Junior-','djun-ver1.png').replace('Económico TV-','econ-v1.png').replace('Caça e Pesca-','cacapesca-v1.png')
                
                nome=nome.replace('-','')
                SIM='</link>\n<link>'.join(activadoextra2)
                if SIM=='':
                    return ''
                else:
                    SIM='<link>%s</link>' % (SIM)
                    if thumb=='tvif-ver2.png':nome='TVI Ficcao'
                    elif thumb=='historia-ver1.png': nome='Historia'
                    elif thumb=='rtpac-ver1.png': nome='RTP Acores'
                    elif thumb=='rtpi-ver1.png': nome='RTP Informacao'
                    elif thumb=='rtpmem-ver1.png': nome='RTP Memoria'
                    elif thumb=='econ-v1.png': nome='Economico TV'
                    elif thumb=='cacapesca-v1.png': nome='Caca e Pesca'
                    CONTEUDO='<item>\n<title>%s</title>\n%s\n<thumbnail>%s</thumbnail>\n</item>' % (nome,SIM,thumb)
                return CONTEUDO
                    

                
def todosact(parametro):
    LOLI=['<item>\n<title>Actualizado: ' + comuns.horaportuguesa().replace('%20',' ') + '</title>\n<link>nada</link>\n<thumbnail>nada</thumbnail>\n</item>']
    dialog = xbmcgui.Dialog()
    mensagemprogresso.create('TV Portuguesa', 'A criar lista.','Por favor aguarde...')
    if re.search('Lista Completa',parametro):
        canaison=comuns.openfile(('canaison'))
        canaison=canaison.replace('[','')
        lista=re.compile('B](.+?)/B]').findall(canaison)
        tamanhototal=int(len(lista))
        tamanho=int(-1)
        for nomes in lista:
            tamanho=tamanho+1
            tamanhoenviado=(tamanho*100)/tamanhototal
            print "Lista completa: Canal " + nomes
            global activadoextra
            activadoextra=[]
            SIM=request_servidores('ignore','[B]' + nomes + '[/B]',tamanho=tamanhoenviado)
            LOLI.append(SIM)
            AGORA='\n\n'.join(LOLI)
    else:
        SIM=request_servidores('ignore',parametro)
        LOLI.append(SIM)
        AGORA='\n\n'.join(LOLI)
    
    mensagemprogresso.close()

    debugfinal='\n'.join(debug)
    comuns.savefile('problema',debugfinal)
    
    keyb = xbmc.Keyboard('', 'Nome do ficheiro da lista')
    keyb.doModal()
    if (keyb.isConfirmed()):
        nomelista = keyb.getText()
        if nomelista=='': nomelista='lista'
    else: nomelista='lista'
    pastafinal = dialog.browse(int(0), "Local para guardar xml/m3u", 'myprograms')
    if not pastafinal: sys.exit(0)
    comuns.savefile(nomelista + '.xml',AGORA,pastafinal=pastafinal)
    m3uprep=['#EXTM3U#EXTM3U']
    openfile=comuns.clean(AGORA)
    ya=re.compile('<item>(.+?)</item>').findall(openfile)
    for lol in ya:
        chname=re.compile('<title>(.+?)</title>').findall(lol)[0]
        allstreams=False
        if allstreams==True:
            streams=re.compile('<link>(.+?)</link>').findall(lol)
            for umporum in streams:
                m3uprep.append('\n#EXTINF:-1,%s\n%s' % (chname,umporum))
        else:
            streams=re.compile('<link>(.+?)</link>').findall(lol)[0]
            m3uprep.append('\n#EXTINF:-1,%s\n%s' % (chname,streams))
    m3uprep='\n'.join(m3uprep)
    comuns.savefile(nomelista + '.m3u',m3uprep,pastafinal=pastafinal)
    xbmc.executebuiltin("XBMC.Notification(TV Portuguesa, Lista xml/m3u gravada,'100000'," + tvporpath + art + "icon32-ver1.png)")

def pre_resolvers(titles,ligacao,index,nome,tamanho=0):
    #import buggalo
    #buggalo.SUBMIT_URL = 'http://fightnight.pusku.com/exceptions/submit.php'
    try:
        sys.argv[2]=sys.argv[2]+ titles[index]
        if activado==True: mensagemprogresso.update(tamanho,'A criar lista. ' + nome+ ' ' + titles[index],'Por favor aguarde...')
        
        nomeserver=nome.replace('ç','c').replace('ã','a').replace('ó','o') + ' ' + titles[index]
        linkescolha=ligacao[index]
        if linkescolha:
            if re.search('estadiofutebol',linkescolha):
                print "Pre-catcher: tvdez"
                link=comuns.abrir_url_cookie(linkescolha)
                if re.search('televisaofutebol',link):
                    codigo=re.compile('<iframe src="http://www.televisaofutebol.com/([^"]+?)"').findall(link)[0]
                    embed='http://www.televisaofutebol.com/' + codigo
                    ref_data = {'Referer': 'http://www.estadiofutebol.com','User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(embed,ref_data)
                    descobrirresolver(embed,nome,html,False,nomeserver)
                else:descobrirresolver(linkescolha, nome,False,False,nomeserver)

            elif re.search('altas-emocoes',linkescolha):
                print "Pre-catcher: altas emocoes /sporting"
                link=comuns.abrir_url(linkescolha)
                frame=re.compile('<a href="/([^"]+?)" target="_blank">SPORTING TV.+?</td>').findall(link)[0]
                ref_data = {'Referer': linkescolha,'User-Agent':user_agent}
                frame1=AltasEmocoesURL + frame
                link= comuns.abrir_url_tommy(frame1,ref_data)
                frame2='http://www.livesportshd.eu/' + re.compile('src="http://www.livesportshd.eu/([^"]+?)"').findall(link)[0]
                ref_data = {'Referer': frame1,'User-Agent':user_agent}
                
                link= comuns.abrir_url_tommy(frame2,ref_data)
                #frame=re.compile("src='(.+?)'").findall(link)[0]
                #ref_data = {'Referer': frame2,'User-Agent':user_agent}
                #link= comuns.abrir_url_tommy(frame,ref_data)
                descobrirresolver(frame2, nome,link,False,nomeserver)

            elif re.search('verlatelegratis',linkescolha):
                print "Pre-catcher: verlatelegratis"
                temporary=''
                link=comuns.abrir_url(linkescolha)
                listacanais=re.compile('<center><iframe.+?src="(.+?)"').findall(link)[0]
                link=comuns.abrir_url(listacanais)
                canais=re.compile("javascript:popUp\('(.+?)'").findall(link)
                for temp in canais:
                    if re.search('toro',temp) and re.search('Toros TV',nome):temporary=temp
                    if re.search('pesca',temp) and re.search('Caça e Pesca',nome) :temporary=temp
                if temporary!='':
                    if re.search('http://',temporary): baseurl=temporary
                    else:baseurl='/'.join(listacanais.split('/')[:-1]) + temporary
                    ref_data = {'Referer': listacanais,'User-Agent':user_agent}
                    link= comuns.abrir_url_tommy(baseurl,ref_data)
                    urlfinal=re.compile('<iframe.+?src="(.+?)"').findall(link)[0]
                    ref_data = {'Referer': baseurl,'User-Agent':user_agent}
                    link= comuns.abrir_url_tommy(urlfinal,ref_data)
                    descobrirresolver(urlfinal, nome,link,False,nomeserver)

            elif re.search('meocanaltv',linkescolha):
                print "Pre-catcher: meocanaltv"
                embed=linkescolha.replace('canais.php?stream=','embed/') + '.php?width=600&height=450'
                ref_data = {'Referer': linkescolha,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                descobrirresolver(embed,nome,html,False,nomeserver)
                
            elif re.search('tvfree',linkescolha):
                print "Pre-catcher: tv a cores"
                link=comuns.abrir_url(linkescolha)
                if re.search('antena.tvfree',link) or re.search('iframe id="player"',link):
                    print "Pre-catcher: tv a cores - antena"
                    try:frame=re.compile('<iframe id="player"[^>]+?src="([^"]+?)"').findall(link)[0]
                    except:frame=re.compile('<iframe src="([^"]+?)" id="innerIframe"').findall(link)[0]
                    if not re.search('antena.tvfree',frame): frame= TVCoresURL + frame
                    ref_data = {'Referer': linkescolha,'User-Agent':user_agent}
                    link= comuns.abrir_url_tommy(frame,ref_data)
                    descobrirresolver(frame, nome,link,False,nomeserver)

                elif re.search('src="/meocanal.php',link):
                    print "Pre-catcher: tv a cores - meocanal"
                    tempId=re.compile('<iframe src="/meocanal.php\?id=([^"]+?)"').findall(link)[0]
                    frame = "http://www.meocanaltv.com/embed/"+tempId+".php";
                    ref_data = {'Referer': linkescolha,'User-Agent':user_agent}
                    link= comuns.abrir_url_tommy(frame,ref_data)
                    descobrirresolver(frame, nome,link,False,nomeserver)

                else: descobrirresolver(linkescolha, nome,False,False,nomeserver)
                

            elif re.search('gosporttv',linkescolha):
                print "Pre-catcher: thesporttv.eu"
                link=comuns.clean(comuns.abrir_url(linkescolha))
                try:
                    linkcod=re.compile("id='(.+?)'.+?</script><script type='text/javascript' src='"+SptveuURL +"/teste/").findall(link)[0]
                    descobrirresolver(SptveuURL+ '/teste/c0d3r.php?id=' + linkcod,nome,'hdm1.tv',False,nomeserver)
                except:
                    frame=re.compile('</p>[^<]*<iframe allowtransparency="true" frameborder="0" scrolling="[^"]+?" src="([^"]+?)"').findall(link)[0]
                    frame=frame.replace('sporttvhdmi.com','gosporttv.com')
                    link=comuns.clean(comuns.abrir_url(frame))
                    if re.search('var urls = new Array',link):
                        framedupla=re.compile('new Array.+?"(.+?)".+?"(.+?)"').findall(link)[0]
                        if framedupla[0]==framedupla[1]: frame=framedupla[0]
                        else:
                            if activado==True: opcao=True
                            else:opcao= xbmcgui.Dialog().yesno("TV Portuguesa", "Escolha um stream da lista dos disponiveis.", "", "","Stream Extra", 'Stream Principal')
                            if opcao: frame=framedupla[0]
                            else: frame=framedupla[1]
              
                    descobrirresolver(frame, nome,False,False,nomeserver)
            elif re.search('lvshd',linkescolha):
                print "Pre-catcher: livesoccerhd"
                link=comuns.abrir_url(linkescolha)
                linkfinal=comuns.limparcomentarioshtml(link,linkescolha)
                endereco=re.compile('<iframe.+?src="(.+?)".+?</iframe></div>').findall(link)[0]
                descobrirresolver(endereco, nome,False,False,nomeserver)

            elif re.search('redweb',linkescolha):
                print "Pre-catcher: redweb"
                c=re.compile('c=(.+?)&').findall(linkescolha)[0]
                s=re.compile('s=(.+?)&').findall(linkescolha)[0]
                i=re.compile('i=(.+?)&').findall(linkescolha)[0]
                form_data = {'c':c,'s':s,'i':i}
                ref_data = {'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(RedwebURL + '/monitor.php',ref_data,form_data=form_data)
                print html
                descobrirresolver(linkescolha, nome,html,False,nomeserver)

            elif re.search('tvtuga',linkescolha):
                ref_data = {'Referer': TVTugaURL,'User-Agent':user_agent}
                link= comuns.abrir_url_tommy(linkescolha,ref_data)
                p = re.compile('<meta.*?>')
                link=p.sub('', link)
                descobrirresolver(linkescolha, nome,link,False,nomeserver)

            elif re.search('tvzune',linkescolha):
                print "Pre-catcher: tvzune"
                if re.search('soft',linkescolha):
                    ref_data = {'User-Agent':''}
                    html= comuns.abrir_url_tommy(linkescolha,ref_data).replace('jw-play','')
                    descobrirresolver(linkescolha, nome,html,False,nomeserver)
                else:                    
                    ref_data = {'Referer': 'http://www.tvzune.tv','User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(linkescolha,ref_data)
                    descobrirresolver(linkescolha, nome,html,False,nomeserver)
            else: descobrirresolver(linkescolha, nome,False,False,nomeserver)
    except Exception:
        if activado==False:
            mensagemprogresso.close()
            mensagemok('TV Portuguesa','Servidor não suportado.')
            (etype, value, traceback) = sys.exc_info()
            print etype
            print value
            print traceback
            #buggalo.onExceptionRaised()
        else:
            try:debug.append(nomeserver)
            except: pass
        

    

def _descobrirresolver(url_frame,nomecanal,linkrecebido,zapping,nomeserver):
    mensagemprogresso.create('TV Portuguesa', 'A carregar stream. (' + nomeserver + ')','Por favor aguarde...')
    descobrirresolver(url_frame,nomecanal,linkrecebido,zapping,nomeserver)

def descobrirresolver(url_frame,nomecanal,linkrecebido,zapping,nomeserver):
    if zapping==False and activado==False: mensagemprogresso.update(50)
    try:
        #import buggalo
        #buggalo.SUBMIT_URL = 'http://fightnight.pusku.com/exceptions/submit.php'
        yoyo265='type:"flash".+?"'
        yoyo115='file:'

        if linkrecebido==False:
            print "Resolver: O url da frame e " + url_frame
            url_frame=url_frame.replace(' ','%20')
            link=comuns.abrir_url_cookie(url_frame)
            try:link=comuns.limparcomentarioshtml(link,url_frame)
            except: pass
            link=comuns.clean(link)
            
            link=link.replace('cdn.zuuk.net\/boi.php','').replace('cdn.zuuk.net\/stats.php','').replace('cdn.zuuk.net/boi.php','').replace('cdn.zuuk.net/stats.php','').replace('<p><script language="JavaScript"> setTimeout','<p><script language="JavaScript">setTimeout').replace('micast_ads','')
        else:
            print "Resolver: O produto final no descobrirresolver"
            link=comuns.limparcomentarioshtml(linkrecebido,url_frame)
            link=link.replace('<title>Zuuk.net</title>','').replace('http://s.zuuk.net/300x250.html','').replace('www.zuuk.net\/test.php?ch=','').replace('cdn.zuuk.net\/boi.php','').replace('cdn.zuuk.net\/stats.php','').replace('cdn.zuuk.net/boi.php','').replace('cdn.zuuk.net/stats.php','').replace('<p><script language="JavaScript"> setTimeout','<p><script language="JavaScript">setTimeout').replace('micast_ads','')

        link=urllib.unquote(link)
        #print url_frame
        #print link
        if re.search("<iframe src='http://www.zuuk.pw",link):
            name=re.compile("<iframe src='http://www.zuuk.pw(.+?)'").findall(link)[0]
            descobrirresolver('http://www.zuuk.pw' + name,nomecanal,False,zapping,nomeserver)
        
        elif re.search("zuuk.net",link):
            try:
                print "Catcher: zuuk"
                l
#                try:chname=re.compile("file='(.+?)'.+?</script>").findall(link)[0]
#                except:chname=False
#                if not chname:
#                    chname=re.compile('src=.+?http://www.zuuk.net/el.php.+?ch=(.+?)&').findall(link)[0]
#                    link=comuns.abrir_url_cookie('http://www.zuuk.net/el.php?ch='+chname)
#                streamurl='rtmp://198.7.58.79/edge playPath='+ chname +' swfUrl=http://cdn.zuuk.net/ply.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.zuuk.net/'
#                comecarvideo(streamurl,nomecanal,True,zapping)
            except:
                print "Catcher: zuuk outro"
                
                print link
                if re.search('<script type="text/javascript">//var urls = new Array',link): url_final=re.compile('new Array.+?"(.+?)",').findall(link)[0]
                
                ##derbie##
                else:
                    #try:name=re.compile('<iframe.+?src="http://.+?zuuk.net/(.+?)"').findall(link)[0]
                    try:name=re.compile('<iframe.+?src="http://.+?zuuk.net/([^"]*\.php[^"]*)"').findall(link)[0]
                    except:name=re.compile("<iframe.+?src='http://.+?zuuk.net/(.+?)'").findall(link)[0]
                    url_final="http://cdn.zuuk.net/" + name
                
                link=comuns.abrir_url_cookie(url_final)
                link=comuns.limparcomentarioshtml(link,url_frame)
                try:
                    info=re.compile("<div id='mediaspace'>"+'<script language="javascript".+?' + "document.write.+?unescape.+?'(.+?)'").findall(link)[0]
                    if info=="' ) );</script> <script type=": info=False
                except:info=False
                if info: infotratada=urllib.unquote(info)
                else: infotratada=link
                descobrirresolver(url_final,nomecanal,infotratada,zapping,nomeserver)

        elif re.search('<p><script language="JavaScript">setTimeout', link):
            print "Catcher: tvtuga zuuk"
            ptcanal=comuns.redirect(re.compile('setTimeout.+?"window.open.+?' + "'(.+?)',").findall(link)[0])
            if re.search('.f4m',ptcanal):
                ptcanal=ptcanal + '&'
                descobrirresolver(ptcanal,nomecanal,ptcanal,zapping,nomeserver)
            elif re.search('rtmp://live.2caster.com',ptcanal):
                descobrirresolver(ptcanal,nomecanal,ptcanal,zapping,nomeserver)           
            else:
                html=urllib.unquote(comuns.abrir_url(ptcanal))
                descobrirresolver(ptcanal,nomecanal,html,zapping,nomeserver)
        elif re.search('<p><iframe src="http://bit.ly/1lrVcOr"',link):
            descobrirresolver('http://bit.ly/1lrVcOr',nomecanal,False,zapping,nomeserver)

        elif re.search('id="innerIframe"',link):
            print "Catcher: id=innerIframe"
            link=comuns.clean(link)
            #embed=re.compile('<br/><iframe.+?src="(.+?)" id="innerIframe"').findall(link)[0]
            embed=re.compile('<iframe[^<]+?src="([^"]+?)" id="innerIframe"').findall(link)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html = comuns.abrir_url_tommy(TVCoresURL + embed,ref_data)
            descobrirresolver(TVCoresURL +embed,nomecanal,html,zapping,nomeserver)
            

        #### ALIVE REMOVER DEPOIS ####

        #elif re.search('file=myStream.sdp',link) or re.search('ec21.rtp.pt',link):
        #    print "Catcher: RTP Proprio"
        #    #link=comuns.abrir_url_cookie(url_frame)
            #urlalive=re.compile('<iframe src="(.+?)".+?></iframe>').findall(link)[0]
            #import cookielib
            #cookie = cookielib.CookieJar()
            #opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
            #opener.addheaders = [('Host','www.rtp.pt'), ('User-Agent', user_agent), ('Referer',url_frame)]
            #linkfinal = opener.open(urlalive).read()
        #    rtmpendereco=re.compile('streamer=(.+?)&').findall(link)[0]
        #    filepath=re.compile('file=(.+?)&').findall(link)[0]
        #    filepath=filepath.replace('.flv','')
        #    swf="http://player.longtailvideo.com/player.swf"
        #    streamurl=rtmpendereco + ' playPath=' + filepath + ' swfUrl=' + swf + ' live=1 timeout=15 pageUrl=' + url_frame
        #    comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('04stream',link):
            print "Catcher: 04stream"
            try:rtmp=re.compile('file=(.+?)"').findall(link)[0]
            except: rtmp=re.compile('file=(.+?)&amp;').findall(link)[0]
            try:swf=re.compile('type="application/x-shockwave-flash" class=".+?" src="(.+?)"').findall(link)[0]
            except:swf=re.compile('src="([^"]+?)" class=".+?" type="application/x-shockwave-flash"').findall(link)[0]
            
            streamurl=rtmp + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=http://www.04stream.com'
            comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search('720Cast',link) or re.search('ilive',link):
            print "Catcher: ilive"
            setecast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            
            if not setecast: setecast=re.compile('file: ".+?/app/(.+?)/.+?",').findall(link)
            if not setecast: setecast=re.compile('flashvars="file=(.+?)&').findall(link)
            if not setecast: setecast=re.compile('src="/ilive.tv.php.+?id=(.+?)" id="innerIframe"').findall(link)
            if not setecast: setecast=re.compile('http://www.ilive.to/embed/(.+?)&').findall(link)
            if not setecast: setecast=re.compile('http://www.ilive.to/embedplayer.php.+?&channel=(.+?)&').findall(link)
            for chname in setecast:
                embed='http://www.ilive.to/embedplayer.php?width=640&height=400&channel=' + chname + '&autoplay=true'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                tempomili=str(comuns.millis())
                urltoken=re.compile(""".*getJSON\("([^'"]+)".*""").findall(html)[0] + '&_='+ tempomili
                urltoken2= comuns.abrir_url_tommy(urltoken,ref_data)
                token=re.compile('"token":"(.+?)"').findall(urltoken2)[0]
                rtmp=re.compile('streamer: "(.+?)",').findall(html)[0].replace('\\','')
                filelocation=re.compile('file: "(.+?).flv",').findall(html)[0]
                swf=re.compile("type: 'flash', src: '(.+?)'").findall(html)[0]
                app=re.compile('rtmp://[\.\w:]*/([^\s]+)').findall(rtmp)[0]
                streamurl=rtmp + ' app=' + app+' playPath=' + filelocation + ' swfUrl=' + swf + ' token='+ token +' swfVfy=1 live=1 timeout=15 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('2caster',link) or re.search('4caster',link):
            print "Catcher: 2caster"
            try:
                rtmp=re.compile('streamer=(.+?)&').findall(url_frame)[0]
                filep=re.compile('file=(.+?)&').findall(url_frame)[0]
            except:
                rtmp=re.compile('streamer=(.+?)&').findall(link)[0]
                filep=re.compile('file=(.+?)&').findall(link)[0]
            streamurl=rtmp + ' playPath=' + filep + ' live=true timeout=15 swfUrl=http://player.longtailvideo.com/player.swf pageUrl=' + url_frame
                #streamurl='http://live.2caster.com:1935/live/' + filep + '/playplist.m3u8'
            #else:
            #    swf=re.compile('<param name="src" value="(.+?)\?').findall(link)[0]
            #    streamurl=filep.replace('rtmp://live.2caster.com/live/','http://live.2caster.com:1935/live/') + '/playplist.m3u8'
        
            
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('aliez',link):
            print "Catcher: aliez"
            aliez=re.compile('src="http://emb.aliez.tv/player/live.php.+?id=(.+?)&').findall(link)
            for chid in aliez:
                embed='http://emb.aliez.tv/player/live.php?id=' + chid + '&w=700&h=420'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile('swfobject.embedSWF\("([^"]+)"').findall(html)[0]
                rtmp=urllib.unquote(re.compile('"file":\s."([^"]+)"').findall(html)[0])
                streamurl=rtmp + ' live=true swfVfy=1 swfUrl=' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('castalba', link):
            print "Catcher: castalba"
            castalba=re.compile('<script type="text/javascript"> id="(.+?)";.+?></script>').findall(link)
            for chname in castalba:
                embed='http://castalba.tv/embed.php?cid=' + chname + '&wh=640&ht=385&r=cdn.thesporttv.eu'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)[0]
                filelocation=re.compile("'file': '(.+?)',").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + '?id=' + ' swfUrl=http://www.udemy.com/static/flash/player5.9.swf live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('cast247',link):
            print "Catcher: cast247"
            castamp=re.compile('fid="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://www.cast247.tv/embed.php?channel='+chname+'&width=650&height=500&domain='+url_frame
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('Channel does not exist',html):
                    if activado==False: mensagemok('TV Portuguesa','Stream está offline.')
                    return
                token=re.compile('var sURL = "(.+?)";').findall(html)[0]
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                tokeninfo= comuns.abrir_url_tommy('http://www.cast247.tv/' + token,ref_data)
                swf=re.compile('flashplayer: "(.+?)",').findall(html)[0]
                filelocation=re.compile('file: "(.+?)",').findall(html)[0]
                rtmpendereco=re.compile('streamer: "(.+?)"').findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + ' swfUrl=http://www.cast247.tv/' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search('castamp',link):
            print "Catcher: castamp"
            castamp=re.compile('channel="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://castamp.com/embed.php?c='+chname
                ref_data = {'Referer': 'http://www.zuuk.net','User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)[0]
                filelocation=re.compile("'file': '(.+?)',").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)
                
        elif re.search('cast3d', link): ##nao esta
            print "Catcher: cast3d"
            cast3d=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in cast3d:
                embed='http://www.cast3d.tv/embed.php?channel=' + '&vw=640&vh=385&domain=lsh.lshunter.tv'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)
                filelocation=re.compile("'file': '(.+?)',").findall(html)
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + '?id=' + ' swfUrl=' + swf[0] + ' live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('castto.me',link):
            print "Catcher: castto.me"
            castamp=re.compile('fid="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://static.castto.me/embed.php?channel='+chname+'&vw=650&vh=500&domain='+url_frame
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('Channel does not exist',html):
                    if activado==False: mensagemok('TV Portuguesa','Stream está offline.')
                    return
                swf=re.compile("SWFObject.+?'(.+?)'").findall(html)[0]
                filelocation=re.compile("so.addVariable.+?file.+?'(.+?)'").findall(html)[0]
                rtmpendereco=re.compile("so.addVariable.+?streamer.+?'(.+?)'").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 token=#ed%h0#w@1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ChelTV',link) or re.search('visionip',link):
            print "Catcher: cheltv"
            chelsea=re.compile("file=(.+?).flv&streamer=(.+?)&").findall(link)
            try:swf=re.compile('flashvars=.+?src="(.+?)" type="application/x-shockwave-flash">').findall(link)[0]
            except:swf=re.compile("src='(.+?)' allowfullscreen=").findall(link)[0]
            streamurl=chelsea[0][1] + ' playPath=' + chelsea[0][0] + ' swfUrl=' + swf + ' live=true pageUrl=http://www.casadossegredos.tv'
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('www.dcast.tv',link):
            print "Catcher: dcast"
            dcastfid=re.compile('<script type="text/javascript">fid="([^"]+)";').findall(link)[0]
            embed ="http://www.dcast.tv/embed.php?u="+dcastfid+"&vw=600&vh=450"
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html= comuns.abrir_url_tommy(embed,ref_data)
            streamurl='rtmpe://strm.dcast.tv/redirect playPath=' + dcastfid + ' swfUrl=http://www.dcast.tv/player/player.swf live=true timeout=15 pageUrl=http://www.dcast.tv/embed.php'
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ezcast', link):
            print "Catcher: ezcast"
            ezcast=re.compile("channel='(.+?)',.+?</script>").findall(link)
            if not ezcast: ezcast=re.compile('src="/ezcast.tv.php.+?id=(.+?)" id="innerIframe"').findall(link)
            if not ezcast: ezcast=re.compile('channel="(.+?)",.+?</script>').findall(link)
            for chname in ezcast:
                embed='http://www.ezcast.tv/embedded/' + chname + '/1/555/435'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                link=comuns.abrir_url('http://www.ezcast.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                idnum=re.compile("'FlashVars'.+?id=(.+?)&s=.+?&").findall(html)[0]
                chnum=re.compile("'FlashVars'.+?id=.+?&s=(.+?)&").findall(html)[0]
                streamurl='rtmp://' + rtmpendereco + '/live playPath=' + chnum + '?id=' + idnum + ' swfUrl=http://www.ezcast.tv/static/scripts/eplayer.swf live=true conn=S:OK swfVfy=1 timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('.f4m&', link):
            print "Catcher f4m file"
            streamurl='http://' + comuns.clean(re.compile('src=http://(.+?).f4m&').findall(link)[0]) + '.f4m' #rtp1
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('fcast', link):
            print "Catcher: fcast"
            fcast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            if not fcast: fcast=re.compile("e-fcast.tv.php.+?fid=(.+?).flv").findall(link)
            for chname in fcast:
                embed='http://www.fcast.tv/embed.php?live=' + chname + '&vw=600&vh=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("SWFObject.+?'(.+?)'").findall(html)
                filelocation=re.compile("so.addVariable.+?file.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?streamer.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf[0] + ' live=true timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('flashi', link):
            print "Catcher: flashi"
            flashi=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in flashi:
                embed='http://www.flashi.tv/embed.php?v=' + chname +'&vw=640&vh=490&typeplayer=0&domain=f1-tv.info'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('This Channel is not Existed !',html):
                    if activado==False: mensagemok('TV Portuguesa','Stream indisponivel')
                    return
                swf=re.compile("new SWFObject.+?'(.+?)'").findall(html)[0]
                filename=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                #rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(link)
                streamurl='rtmp://flashi.tv:1935/lb' + ' playPath=' + filename[0] + ' swfUrl=http://www.flashi.tv/' + swf + ' live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('flashstreaming.mobi',link):
            print "Catcher: flashstreaming.mobi"
            flex=re.compile("channel='(.+?)',.+?></script>").findall(link)
            for chid in flex:
                js=re.compile('http://flashstreaming.mobi/(.+?).js').findall(link)[0]
                temp=comuns.abrir_url('http://flashstreaming.mobi/%s.js' % js)
                embed=re.compile("src=(.+?)'").findall(temp)[0]+chid+'&w=600&h=400'
                #embed='http://flashstreaming.mobi/embed/embed.php?channel='+chid+'&w=600&h=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                print html
                try:swf=re.compile("new SWFObject\('(.+?)'").findall(html)[0]
                except:swf=re.compile("src='(.+?)'").findall(html)[0]
                try:playp=re.compile('file=(.+?)&').findall(html)[0]
                except:playp=re.compile("'file', '(.+?)'").findall(html)[0]
                try:rtmp=re.compile('streamer=(.+?)&').findall(html)[0]
                except:rtmp=re.compile("'streamer', '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + playp + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)
            

        elif re.search('flexstream', link):
            print "Catcher: flexstream"
            flex=re.compile("file='(.+?)';.+?></script>").findall(link)
            for chid in flex:
                embed='http://flexstream.net/embed.php?file='+chid+'&width=650&height=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                rtmp=re.compile("file: '(.+?)'").findall(html)[0].replace(chid,'')
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl=http://p.jwpcdn.com/6/8/jwplayer.flash.swf live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('freelivetv.tv', link):
            print "Catcher: freelivetv.tv"
            flive=re.compile("channel='(.+?)',.+?></script>").findall(link)
            for chid in flive:
                embed='http://freelivetv.tv/embed/embed.php?channel='+chid+'&w=650&h=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("src='(.+?)'").findall(html)[0]
                playp=re.compile('file=(.+?)&').findall(html)[0]
                rtmp=re.compile('streamer=(.+?)&').findall(html)[0]
                streamurl=rtmp + ' playPath=' + playp + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('freetvcast', link):
            print "Catcher: freetvcast"
            cenas=re.compile('freetvcast.pw/(.+?)"').findall(link)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            framesite='http://freetvcast.pw/' + cenas
            html= comuns.abrir_url_tommy(framesite,ref_data)
            embed=re.compile("var url = '(.+?)'").findall(html)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html= comuns.abrir_url_tommy(embed,ref_data)
            swf=re.compile("SWFObject\('(.+?)'").findall(html)[0].replace('../','')
            rtmp=re.compile("'streamer', '(.+?)'").findall(html)[0].replace('redirect','live')
            filep=re.compile("'file', '(.+?)'").findall(html)[0]
            streamurl=streamurl=rtmp + ' playPath=' + filep + ' swfUrl=http://freetvcast.pw/' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
            comecarvideo(streamurl,nomecanal,True,zapping)
        

        elif re.search('hdcast.tv',link):
            print "Catcher: hdcast.tv"
            chid=re.compile('fid=(.+?)"').findall(link)[0]
            chid=chid.replace('.flv','')
            streamurl='rtmp://origin.hdcast.tv:1935/redirect/ playPath='+chid+' swfUrl=http://www.udemy.com/static/flash/player5.9.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.hdcast.tv'
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('hdcaster.net', link):
            print "Catcher: hdcaster"
            hdcaster=re.compile("<script type='text/javascript'>id='(.+?)'").findall(link)
            for chid in hdcaster:
                urltemp='rtmp://188.138.121.99/hdcaster playPath=' + chid + ' swfUrl=http://hdcaster.net/player.swf pageUrl=http://hdcaster.net/player.php?channel_id=101634&width=600&height=430'
                token = '%Xr8e(nKa@#.'
                streamurl=urltemp + ' token=' + token
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('hqstream.tv', link):
            print "Catcher: hqstream.tv"
            hqst=re.compile("hqstream.tv.+?streampage=(.+?)&").findall(link)
            for chid in hqst:
                embed='http://hqstream.tv/player.php?streampage=' + chid
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                fp=int(re.compile('var f =\s*([^;]+)').findall(html)[0])
                ap=int(re.compile('var a =\s*([^;]+)').findall(html)[0])/fp
                bp=int(re.compile('var b =\s*([^;]+)').findall(html)[0])/fp
                cp=int(re.compile('var c =\s*([^;]+)').findall(html)[0])/fp
                dp=int(re.compile('var d =\s*([^;]+)').findall(html)[0])/fp
                vp=re.compile("var v_part =\s*'([^']+).*").findall(html)[0]

                streamurl='rtmp://%s.%s.%s.%s%s swfUrl=http://filo.hqstream.tv/jwp6/jwplayer.flash.swf live=1 timeout=15 swfVfy=1 pageUrl=%s' % (ap,bp,cp,dp,vp,embed)
                comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search('icasthd', link):
            print "Catcher: icastHD"
            icast=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in icast:
                embed='http://www.icasthd.tv/embed.php?v='+chname+'&vw=575&vh=390&domain=www.ihdsports.com'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('This Channel is not Existed !',html):
                    if activado==False: mensagemok('TV Portuguesa','Stream indisponivel')
                    return
                swf=re.compile("'flashplayer': 'http://www.icasthd.tv//(.+?)'").findall(html)[0]
                filename=re.compile("'file': '(.+?)'").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)redirect3").findall(html)[0]
                app=re.compile("Ticket=(.+?)'").findall(html)[0]
                streamurl=rtmpendereco+ 'live app=live?f=' + app + ' playPath=' + filename + ' swfUrl=http://www.icasthd.tv/' + swf + ' live=1 timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('janjua',link):
            print "Catcher: janjua"
            janj=re.compile("channel='(.+?)',.+?</script>").findall(link)
            if not janj: janj=re.compile('channel="(.+?)",.+?</script>').findall(link)
            for chname in janj:
                embed='http://www.janjua.tv/embedplayer/'+chname+'/1/650/500'
                ref_data = {'Connection': 'keep-alive','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('Channel is domain protected.',html):
                    url_frame='http://www.janjua.tv/' + chname
                    ref_data = {'Connection': 'keep-alive','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Referer': url_frame,'User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                link=comuns.abrir_url('http://www.janjua.tv:1935/loadbalancer')
                embed='http://www.janjua.tv/embedplayer/'+chname+'/1/650/500'
                ref_data = {'Connection': 'keep-alive','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Referer': url_frame,'User-Agent':user_agent}
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)
                streamurl='rtmp://' + rtmpendereco[0] + '/live/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.janjua.tv' + swf[0] + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('longtail', link):
            print "Catcher: longtail"
            longtail=re.compile("src='http://player.longtailvideo.com/player.swf' flashvars='file=(.+?)&streamer=(.+?)&").findall(link)
            if not longtail: longtail=re.compile('flashvars="file=(.+?)&streamer=(.+?)&').findall(link)
            if not longtail: longtail=re.compile('flashvars="file=(.+?)&.+?streamer=(.+?)&').findall(link)
            for chname,rtmp in longtail:
                chname=chname.replace('.flv','')
                streamurl=rtmp + ' playPath=' + chname + ' live=true swfUrl=http://player.longtailvideo.com/player.swf pageUrl=http://longtailvideo.com/'
                comecarvideo(streamurl,nomecanal,True,zapping)
            if not longtail:
                streamurl=re.compile('file: "(.+?)"').findall(link)[0]
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('hdm1.tv',link):
            print "Catcher: hdm1.tv"
            hdmi=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in hdmi:
                embed='http://hdm1.tv/embed.php?live='+ chid +'&vw=600&vh=470'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("new SWFObject.+?'(.+?)'").findall(html)[0]
                filelocation=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)
            if not hdmi:
                hdmi=re.compile("src='(.+?).swf.+?file=(.+?)&streamer=(.+?)&autostart=true").findall(link)
                for swf,chid,rtmp in hdmi:
                    embed='http://hdm1.tv/embed.php?live='+ chid +'&vw=600&vh=470'
                    streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                    comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('jimey',link):
            print "Catcher: jimey"
            chname=re.compile("file='(.+?)';.+?</script>").findall(link)[0]
            embed= 'http://jimey.tv/player/embedplayer.php?channel=' + chname + '&width=640&height=490'
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html= comuns.abrir_url_tommy(embed,ref_data)
            rtmp=re.compile('&streamer=(.+?)/redirect').findall(html)[0]
            streamurl= rtmp + ' playPath='+chname + " token=zyklPSak>3';CyUt%)'ONp" + ' swfUrl=http://jimey.tv/player/fresh.swf live=true timeout=15 swfVfy=1 pageUrl=' + embed
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('jw-player.html?cid=',url_frame):
            print "Catcher: jwplay tvfree"
            streamurl=url_frame.replace('http://tvfree.me/jw-player.html?cid=','')
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('jwlive',link) or re.search('jw-play',link):
            print "Catcher: jwlive"
            endereco=TVCoresURL + re.compile('<br/><iframe src="(.+?)" id="innerIframe"').findall(link)[0]
            if re.search('tvfree.me/jw-player.html',endereco):
                streamurl=endereco.replace('http://tvfree.me/jw-player.html?cid=','')
            else:
                link=comuns.abrir_url(endereco)
                streamurl=re.compile('file: "(.+?)"').findall(link)[0]
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('liveflash', link):
            print "Catcher: liveflash"
            flashtv=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not flashtv: flashtv=re.compile('channel="(.+?)".+?</script>').findall(link)
            if not flashtv: flashtv=re.compile('iframe src="/cc-liveflash.php.+?channel=(.+?)"').findall(link)
            if not flashtv: flashtv=re.compile("window.open.+?'/e-liveflash.tv.php.+?channel=(.+?)'").findall(link)
            if not flashtv: flashtv=re.compile("http://tvph.googlecode.com/svn/players/liveflash.html.+?ver=(.+?)'").findall(link)
            if not flashtv: flashtv=re.compile("pop-liveflash.php.+?get=(.+?)'").findall(link)

            for chname in flashtv:
                embed='http://www.liveflash.tv/embedplayer/' + chname + '/1/640/460'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('Channel is domain protected.',html):
                    url_frame='http://www.liveflash.tv/' + chname
                    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                link=comuns.abrir_url('http://www.liveflash.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)
                print "A IR PRO PLAYER"
                streamurl='rtmp://' + rtmpendereco[0] + '/stream/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.liveflash.tv' + swf[0] + ' pageUrl=' + embed
                #print streamurl
                comecarvideo(streamurl,nomecanal,True,zapping)

        #elif re.search('livestream', link):
        #    print "Catcher: livestream"
        #    livestream=re.compile("videoborda.+?channel=(.+?)&").findall(link)
        #    for chname in livestream:
        #        streamurl='rtmp://extondemand.livestream.com/ondemand playPath=trans/dv04/mogulus-user-files/ch'+chname+'/2009/07/21/1beb397f-f555-4380-a8ce-c68189008b89 live=true swfVfy=1 swfUrl=http://cdn.livestream.com/chromelessPlayer/v21/playerapi.swf pageUrl=http://cdn.livestream.com/embed/' + chname + '?layout=4&amp;autoplay=true'
        #        comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('master_tv', link):
            print "Catcher: master_tv"
            mastertv=re.compile('src=".+?fid=(.+?)" name="frame"').findall(link)[0].replace('animax','disneyjr')
            descobrirresolver('http://tv-msn.com/' + mastertv + '.html', nomecanal,False,False,nomeserver)

        elif re.search('megatvhd',url_frame):
            print "Catcher: megatvhd.tv"
            chid=re.compile('liveedge/(.+?)"').findall(link)[0]
            embed='http://megatvhd.tv/ch.php?id='+chid
            link=comuns.abrir_url(embed)
            rtmp=re.compile('file: "(.+?)"').findall(link)[0]
            rtmp=rtmp.replace('/'+chid,'')
            streamurl=rtmp + ' playPath='+chid + ' live=true swfUrl=http://player.longtailvideo.com/player.swf pageUrl='+embed
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('megom', link):
            print "Catcher: megom.tv"
            megom=re.compile('HEIGHT=432 SRC="http://distro.megom.tv/player-inside.php.+?id=(.+?)&width=768&height=432"></IFRAME>').findall(link)
            for chname in megom:
                embed='http://distro.megom.tv/player-inside.php?id='+chname+'&width=768&height=432'
                link=comuns.abrir_url(embed)
                swf=re.compile(".*'flashplayer':\s*'([^']+)'.*").findall(link)[0]
                streamer=re.compile("'streamer': '(.+?)',").findall(link)[0]
                streamer=streamer.replace('live.megom.tv','37.221.172.85')
                streamurl=streamer + ' playPath=' + chname + ' swfVfy=1 swfUrl=' + swf + ' live=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('micast', link):
            print "Catcher: micast"
            baseurl='http://micast.tv/chn.php?ch='
            micast=re.compile('micast.tv:1935/live/(.+?)/').findall(link)
            if not micast: micast=re.compile('ca="(.+?)".+?></script>').findall(link)
            if not micast: micast=re.compile('setTimeout.+?"window.open.+?' + "'http://micast.tv/gen.php.+?ch=(.+?)',").findall(link)
            if not micast: micast=re.compile('src="http://micast.tv/gen5.php.+?ch=(.+?)&amp;"').findall(link)
            if not micast: micast=re.compile('src="http://micast.tv/chn.php.+?ch=(.+?)"').findall(link)
            if not micast:
                if re.search('http://micast.tv/gens2.php',url_frame):
                    micast=[]
                    micast.append(url_frame.replace('http://micast.tv/gens2.php?ch=',''))
                    baseurl='http://micast.tv/gens2.php?ch='
                
            for chname in micast:
                #embed=comuns.redirect(baseurl+chname)
                embed=comuns.redirect('http://micast.tv/gens2.php?ch=cocoeranheta')
                link=comuns.abrir_url(embed)
                if re.search('refresh',link):
                    chname=re.compile('refresh" content="0; url=http://micast.tv/gen.php.+?ch=(.+?)"').findall(link)[0]                
                    link=comuns.abrir_url('http://micast.tv/gen5.php?ch='+chname)
                try:
                    final=re.compile('file=(.+?)&amp;streamer=(.+?)&amp').findall(link)[0]
                    streamurl=final[1] + ' playPath=' + final[0] + ' swfUrl=http://files.mica.st/player.swf live=true timeout=15 swfVfy=1 pageUrl=http://micast.tv/gen.php?ch='+final[0]
                except:
                    rtmp=re.compile('file: "(.+?),').findall(link)[0]
                    rtmp=rtmp.split('/')
                    rtmp[2]=rtmp[2] + ':443'
                    rtmp='/'.join(rtmp)
                    chid=re.compile('/liveedge/(.+?)"').findall(rtmp)[0]
                    chidplay=chid.replace('.flv','')
                    rtmp=rtmp.replace(chid+'"','')
                    streamurl=rtmp + ' playPath=' + chname + ' swfUrl=http://micast.tv/jwplayer/jwplayer.flash.swf live=true timeout=15 swfVfy=1 pageUrl=' + embed

                comecarvideo(streamurl,nomecanal,True,zapping)
            if not micast:
                try:
                    micast=re.compile('<iframe src="(.+?)" id="innerIframe"').findall(link)[0]
                    link=comuns.abrir_url(TVCoresURL + micast)
                    if re.search('privatecdn',link):
                        descobrirresolver(url_frame,nomecanal,link,zapping,nomeserver)
                    else:
                        micast=re.compile('//(.+?).micast.tv/').findall(link)[0]
                        linkfinal='http://' + micast+  '.micast.tv'
                        link=comuns.abrir_url(linkfinal)
                        final=re.compile('file=(.+?)&amp;streamer=(.+?)&amp').findall(link)[0]
                        #if not final: final=re.compile("file=(.+?)&streamer=(.+?)'").findall(link)[0]
                        streamurl=final[1] + ' playPath=' + final[0] + ' swfUrl=http://files.mica.st/player.swf live=true timeout=15 swfVfy=1 pageUrl=http://micast.tv/gen.php?ch='+final[0]
                        comecarvideo(streamurl,nomecanal,True,zapping)
                except: pass
                
        elif re.search('mips', link):
            print "Catcher: mips"
            mips=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not mips: mips=re.compile('channel="(.+?)",.+?></script>').findall(link)
            if not mips: mips=re.compile('<iframe src="/mips.tv.php.+?fid=(.+?)" id="innerIframe"').findall(link)
            if not mips: mips=re.compile("pop-mips.php\?get=(.+?)'").findall(link)
            for chname in mips:
                embed='http://www.mips.tv/embedplayer/' + chname + '/1/500/400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search("The requested channel can't embedded on this domain name.",html):
                    source='http://www.mips.tv/' + chname
                    ref_data = {'Referer': source,'User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)[0]
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&e=").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                link=comuns.abrir_url('http://www.mips.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                streamurl='rtmp://' + rtmpendereco + '/live/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 live=true timeout=15 conn=S:OK swfUrl=http://www.mips.tv' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('privatecdn',link):
            print "Catcher: privatecdn"
            privatecdn=re.compile('<script type="text/javascript">id="(.+?)"').findall(link)
            for chid in privatecdn:
                embed='http://privatecdn.tv/ch.php?id='+chid
                link=comuns.abrir_url(embed)
                rtmp=re.compile('file: "(.+?)"').findall(link)[0]
                rtmp=rtmp.replace('/'+chid,'')
                streamurl=rtmp + ' playPath='+chid + ' live=true swfUrl=http://player.longtailvideo.com/player.swf pageUrl='+embed
                comecarvideo(streamurl,nomecanal,True,zapping)
                
        elif re.search('putlive', link):
            print "Catcher: putlive"
            putlivein=re.compile("<iframe.+?src='.+?.swf.+?file=(.+?)&.+?'.+?></iframe>").findall(link)
            if not putlivein: putlivein=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not putlivein: putlivein=re.compile('src="http://www.putlive.in/e/(.+?)"></iframe>').findall(link)
            for chname in putlivein:
                streamurl='rtmpe://199.195.199.172:443/liveedge2/ playPath=' + chname + ' swfUrl=http://www.megacast.io/player59.swf live=true timeout=15 swfVfy=1 pageUrl=http://putlive.in/'
                comecarvideo(streamurl,nomecanal,True,zapping)

        ##livesoccerhd
        elif re.search('src="http://cdn.gosporttv.com',link):
            print "Catcher: livesoccerhd stolen sptvhd"
            ups=re.compile('<iframe.+?src="(.+?)"').findall(link)[0]
            descobrirresolver(ups,nomecanal,False,zapping,nomeserver)
        
        elif re.search('ptcanal', link):
            print "Catcher: ptcanal"
            ptcanal=re.compile('<p><a href="(.+?)" onclick="window.open').findall(link)[0]
            descobrirresolver(ptcanal,nomecanal,False,zapping,nomeserver)

        elif re.search('RTP Play - RTP</title>',link):
            print "Catcher: RTP Play"
            match=re.compile('\"file\": \"(.+?)\",\"application\": \"(.+?)\",\"streamer\": \"(.+?)\"').findall(link)
            temp = ['rtmp://' + match[0][2] +'/' + match[0][1] + '/' + match[0][0] + ' swfUrl=' + RTPURL + '/play/player.swf live=true timeout=15']
            temp.append(re.compile('\"smil\":\"(.+?)\"').findall(link)[0])
            if activado==True: opcao=True
            else:opcao= xbmcgui.Dialog().yesno("TV Portuguesa", "Escolha um stream da lista dos disponiveis.", "", "","Stream Extra", 'Stream Principal')
            if opcao: streamurl=temp[0]
            else: streamurl=comuns.redirect(temp[1])
            comecarvideo(streamurl, nomecanal,True,zapping)

        elif re.search('rtps',link):
            print "Catcher: rtps"
            ficheiro=re.compile("file='(.+?).flv'.+?</script>").findall(link)[0]
            streamurl='rtmp://ec21.rtp.pt/livetv/ playPath=' + ficheiro + ' swfUrl=http://museu.rtp.pt/app/templates/templates/swf/pluginplayer.swf live=true timeout=15 pageUrl=http://www.rtp.pt/'
            comecarvideo(streamurl, nomecanal,True,zapping)

        elif re.search('h2e.rtp.pt',link) or re.search('h2g2.rtp.pt',link) or re.search('.rtp.pt',link) or re.search('provider=adaptiveProvider.swf',link) or re.search('file=rtp1',link):
            print "Catcher: rtp.pt"
            link=link.replace('\\','').replace('">',"'>")
            if re.search('<strong><u>Clique para ver a ',link):
                urlredirect=re.compile("popup\('(.+?)'\)").findall(link)[0]
                descobrirresolver(urlredirect,nomecanal,False,zapping,nomeserver)
                return
            try:streamurl=re.compile("cid=(.+?).m3u8").findall(link)[0] + '.m3u8'
            except:
                try:
                    streamurl=re.compile("file=(.+?).m3u8(.+?)&").findall(link)[0]
                    streamurl='.m3u8'.join(streamurl)
                    streamurl=streamurl.replace('&abouttext=TV ZUNE PLAYER 2013','')
                except:
                    try:streamurl=re.compile("file=(.+?).m3u8").findall(link)[0] + '.m3u8'
                    except:
                        try:
                            rtmp=re.compile('streamer=(.+?)&').findall(link)[0]
                            filep=re.compile('file=(.+?)&').findall(link)[0]
                            try:swf=re.compile(" data='(.+?).swf\?").findall(link)[0] + '.swf'
                            except:swf=re.compile('src="(.+?)"').findall(link)[0]
                            
                            streamurl=rtmp + ' playPath=' + filep + ' swfUrl=' + swf + ' swfVfy=1 live=1 pageUrl=http://tvzune.tv/'
                        except:
                            #embed=re.compile('<iframe src="/flashmedia.php\?channel=(.+?)" id="innerIframe"').findall(link)[0]
                            #ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                            #embed=TVCoresURL + '/flashmedia.php?channel=' + embed
                            
                            #html= urllib.unquote(comuns.abrir_url_tommy(embed,ref_data)).replace('//-->','.rtp.pt')
                            #descobrirresolver(embed,nomecanal,html,zapping,nomeserver)
                            streamurl=url_frame.replace('http://tvfree.me/jw-player.html?cid=','')
                            #comecarvideo(streamurl,nomecanal,True,zapping)
                            #return
            #streamurl='rtmp://ec21.rtp.pt/livetv/ playPath=' + ficheiro + ' swfUrl=http://museu.rtp.pt/app/templates/templates/swf/pluginplayer.swf live=true timeout=15 pageUrl=http://www.rtp.pt/'            
            comecarvideo(streamurl , nomecanal,True,zapping)

        elif re.search('meocanaltv.com/embed',link):
            print "Catcher: stolen meocanaltv from tvgente"
            meotv='http://www.meocanaltv.com/embed/' + re.compile('src="http://www.meocanaltv.com/embed/(.+?).php').findall(link)[0] + '.php'
            descobrirresolver(meotv,nomecanal,False,zapping,nomeserver)

        elif re.search('=myStream.sdp',link): 
            print "Catcher: other rtp"
            try:
                rtmpendereco=re.compile('streamer=(.+?)&').findall(link)[0]
                filepath=re.compile('file=(.+?)&').findall(link)[0]
                filepath=filepath.replace('.flv','')
            except:
                rtmpendereco=re.compile('file=(.+?)&').findall(link)[0]
                filepath=re.compile(';id=(.+?)&').findall(link)[0]
            
            swf="http://player.longtailvideo.com/player.swf"
            streamurl=rtmpendereco + ' playPath=' + filepath + ' swfUrl=' + swf + ' live=1 timeout=15 pageUrl=' + url_frame
            comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search('resharetv',link): #reshare tv
            print "Catcher: resharetv"
            ref_data = {'Referer': 'http://resharetv.com','User-Agent':user_agent}
            html= comuns.abrir_url_tommy(url_frame,ref_data)
            html=comuns.clean(html)
            try:
                try: streamurl=re.compile(',  file: "(.+?)"').findall(html)[0]
                except: streamurl=re.compile('file: "(.+?)"').findall(html)[0]
            except:
                try:
                    swf=re.compile('<param name="movie" value="/(.+?)"></param>').findall(html)[0]
                    rtmp=re.compile('<param name="flashvars" value="src=http%3A%2F%2F(.+?)%2F_definst_%2F.+?%2Fmanifest.f4m&loop=true.+?">').findall(html)[0]
                    play=re.compile('_definst_%2F(.+?)%2Fmanifest.f4m&loop=true.+?">').findall(html)[0]
                except:
                    try:
                        swf=re.compile('src="(.+?)" type="application/x-shockwave-flash"').findall(html)[0]
                        rtmp=re.compile('streamer=(.+?)&amp').findall(html)[0]
                        play=re.compile('flashvars="file=(.+?).flv&').findall(html)[0]
                        streamurl='rtmp://' + urllib.unquote(rtmp) + ' playPath=' + play + ' live=true timeout=15 swfVfy=1 swfUrl=' + ResharetvURL + swf + ' pageUrl=' + ResharetvURL
                    except:
                        try:
                            frame=re.compile('<iframe.+?src="(.+?)">').findall(html)[0]
                            descobrirresolver(frame,nomecanal,False,zapping,nomeserver)
                            return
                        except:
                            if activado==False: mensagemok('TV Portuguesa','Não e possível carregar stream.')
                            return
            comecarvideo(streamurl, nomecanal,True,zapping)
            
        elif re.search('sharecast',link):
            print "Catcher: sharecast"
            share=re.compile('src="http://sharecast.to/embed/(.+?)"></iframe>').findall(link)
            if not share: share=re.compile('src="http://sharecast.to/embed.php.+?ch=(.+?)"').findall(link)
            for chname in share:
                embed= 'http://sharecast.to/embed/' + chname
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('Channel not found',html):
                    if activado==False: mensagemok('TV Portuguesa','Stream offline.')
                    return
                try:
                    playpath= re.compile('file: "(.+?)",').findall(html)[0]
                    rtmp= re.compile('streamer: "(.+?)",').findall(html)[0]
                    conteudo=rtmp + ' playPath=' + playpath
                except:
                    rtmp= re.compile('file: "(.+?)",').findall(html)[0]
                    conteudo=rtmp
                
                streamurl= conteudo + ' live=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('surfline',link):
            print "Catcher: surfline"
            idcam=re.compile('spotid = (.+?),').findall(link)[0]            
            streaminfo=comuns.abrir_url('http://api.surfline.com/v1/syndication/cam/'+idcam).replace('\\','')
            if re.search('"camStatus":"down"',streaminfo):
                if activado==False: mensagemok('TV Portuguesa','Stream está offline.')
                return
            streamurl=re.compile('"file":"(.+?)"').findall(streaminfo)[0]
            comecarvideo(streamurl,nomecanal,True,zapping)

        #elif re.search('p,a,c,k,e,r',link):
        #    print "Catcher: zuuk ruu.php"
        #    link=link.replace('|','')
        #    tuga=re.compile('ruuphpnr(.+?)style').findall(link)[0]
        #    descobrirresolver("http://www.zuuk.net/ruu.php?nr=" + tuga,nomecanal,False,zapping,nomeserver)

        elif re.search('http://portalzuca.net',link):
            print "Catcher: portalzuca"
            tuga='http://portalzuca.net/' + re.compile('src="http://portalzuca.net/(.+?)"').findall(link)[0]
            descobrirresolver(tuga,nomecanal,False,zapping,nomeserver)

        elif re.search('pontucanal.net/iframe',link):
            print "Catcher: pontucanal iframe"
            embed='http://pontucanal.tv/iframe/' + re.compile('src="http://pontucanal.net/iframe/(.+?)\?W=').findall(link)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html= comuns.abrir_url_tommy(embed,ref_data)
            descobrirresolver(embed,nomecanal,html,zapping,nomeserver)

        elif re.search('sawlive', link):
            print "Catcher: sawlive"
            saw=re.compile('src="http://sawlive.tv/embed/(.+?)">').findall(link)
            for chid in saw:
                embed='http://sawlive.tv/embed/'+chid
                link=comuns.abrir_url(embed)
                cont=re.compile('embed\|view\|(.+?)\|write').findall(link)[0]
                cont=cont.decode('string-escape').replace('|','/')
                html=comuns.abrir_url('http://sawlive.tv/embed/watch/' + cont)
                swf=re.compile("SWFObject\('(.+?)',").findall(html)[0]
                filep=re.compile("'file', '(.+?)'").findall(html)[0]
                rtmp=re.compile("'streamer', '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + filep + ' swfUrl='+swf+' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('streamcasttv', link):
            print "Catcher: streamcasttv"
            scast=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not scast: scast=re.compile('<iframe src="/streamcasttv.php\?file=(.+?)" id="innerIframe"').findall(link)
            for chid in scast:
                embed='http://www.streamcasttv.biz/embed.php?file='+chid+'&width=650&height=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data).encode('ascii','ignore').decode('utf-8')
                swf='http://www.streamcasttv.biz/jwplayer/jwplayer.flash.swf'
                if re.search("src='http://streamcasttv.biz/embed/",html):
                    extra=True
                    chid=re.compile("file='(.+?)';.+?</script>").findall(html)[0]
                    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                    embed='http://www.streamcasttv.biz/embed/21r.php?file='+chid+'&width=650&height=400'
                    html= comuns.abrir_url_tommy(embed,ref_data).encode('ascii','ignore').decode('utf-8')
                    swf='http://www.streamcasttv.biz/embed/jwplayer/jwplayer.flash.swf'
                else: extra=False
                
                rtmp=re.compile("file: '(.+?)'").findall(html)[0]
                if extra==True: chid=''.join((rtmp.split('/'))[-1:]).replace('.smil','')
                rtmp='/'.join((rtmp.split('/'))[:-1]) + '/'
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl='+swf+' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('streamify', link):
            print "Catcher: streamify"
            flive=re.compile('channel="(.+?)",.+?></script>').findall(link)
            for chid in flive:
                embed='http://www.streamify.tv/embedplayer/'+chid+'/1/650/400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                if re.search('Channel is domain protected.',html):
                    url_frame='http://www.streamify.tv/' + chname
                    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                link=comuns.abrir_url('http://www.streamify.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                streamurl='rtmp://' + rtmpendereco + '/live/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.streamify.tv' + swf[0] + ' pageUrl=' + embed
                #lib
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('sapo.pt',link):
            print "Catcher: sapo.pt"
            #lista=re.compile('file=(.+?)&').findall(link)[0]
            #streams=comuns.abrir_url(lista + '?all=1').replace('\\','')
            #streamurl=re.compile('"hls":"(.+?)"').findall(streams)[0]
            '''            
            link=link.replace('" frameborder="0" scrolling="no"','&')#ugly
            try:
                swf='http://js.sapo.pt/Projects/Video/140708R1/flash/videojs.swf'
                try:
                    print "Method 1"
                    chname=re.compile('live/(.+?)&').findall(link)[0]
                    filepath=re.compile('file=(.+?)&').findall(link)[0]
                except:
                    print "Method 2"
                    chname=re.compile('http://videos.sapo.pt/(.+?)"').findall(link)[0]
                    info=comuns.abrir_url('http://videos.sapo.pt/'+chname)
                    filepath=re.compile('/live/(.+?)",').findall(info)[0]
                host=comuns.abrir_url('http://videos.sapo.pt/hosts_stream.html')
                hostip=re.compile('<host>(.+?)</host>').findall(host)[0]
                if re.search('playersrc="',link):
                    jslink=re.compile('playersrc="(.+?)"').findall(link)[0]
                    jslink=jslink.split('.js')
                    swf=jslink[0]
                    swf=swf.replace('Video','flash/videojs.swf')
                #else:
                
                streamurl='rtmp://' + hostip + '/live' + ' playPath=' + chname  + ' swfUrl='+swf+' live=true pageUrl=http://videos.sapo.pt/'+chname
            except:
            '''
            print "Method 3"
            swf='http://js.sapo.pt/Projects/Video/140708R1/flash/videojs.swf'
            try:
                print "Method 1"
                chname=re.compile('live/(.+?)&amp;').findall(link)[0]
                filepath=re.compile('file=(.+?)&').findall(link)[0]
                host=comuns.abrir_url('http://videos.sapo.pt/hosts_stream.html')
                hostip=re.compile('<host>(.+?)</host>').findall(host)[0]
                streamurl='rtmp://' + hostip + '/live' + ' playPath=' + chname  + ' swfUrl='+swf+' live=true pageUrl=http://videos.sapo.pt/'+chname
            except:
                lista=re.compile('file=(.+?)&').findall(link)[0]
                streams=comuns.abrir_url(lista + '?all=1').replace('\\','')
                try:
                    #rtmp
                    rtmp=re.compile('"rtmp":"(.+?)"').findall(streams)[0]
                    chname=rtmp.split('/')[-1:][0]
                    streamurl=rtmp + ' playPath=' + chname  + ' swfUrl='+swf+' live=true pageUrl=http://videos.sapo.pt/'+chname
                except:
                    #m3u8
                    streamurl=re.compile('"hls":"(.+?)"').findall(streams)[0]
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('surftotal',link):
            print "Catcher: surftotal"
            idcam=re.compile("<iframe.+?src='(.+?)'").findall(link)[0]            
            streaminfo=comuns.abrir_url(idcam)
            try:
                rtmp=re.compile("streamer:'(.+?)'").findall(streaminfo)[0]
                playpath=re.compile('file: "(.+?)"').findall(streaminfo)[0]
                swf='http://www2.surftotal.com/CAMS/player.swf'
                streamurl=rtmp + ' playPath=' + playpath  + ' swfUrl='+swf+' live=true pageUrl='+idcam
                comecarvideo(streamurl,nomecanal,True,zapping)
            except:                
                if activado==False: mensagemok('TV Portuguesa','Stream está offline.')
                return
            

        elif re.search('telewizja',link) or re.search('sapo.tv.php',link):
            print "Catcher: telewizja or sapo.tv"
            codigo=re.compile('<br/><iframe src="(.+?)" id="innerIframe"').findall(link)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            embed=TVCoresURL + codigo
            html= comuns.abrir_url_tommy(embed,ref_data)
            descobrirresolver(embed,nomecanal,html,zapping,nomeserver)

        elif re.search('televisaofutebol',link):
            print "Catcher: televisaofutebol"
            link=link.replace('\\','')
            tuga=re.compile('src="http://www.televisaofutebol.com/(.+?)".+?/iframe>').findall(link)[0]
            embed='http://www.televisaofutebol.com/' + tuga
            ref_data = {'Referer': 'http://www.estadiofutebol.com','User-Agent':user_agent}
            html= comuns.abrir_url_tommy(embed,ref_data)
            descobrirresolver(embed,nomecanal,html,zapping,nomeserver)

        elif re.search('tugastream',link):
            print "Catcher: tugastream"
            tuga=re.compile('src=".+?tugastream.com/(.+?)".+?/iframe>').findall(link)[0]
            descobrirresolver('http://www.tugastream.com/' + tuga,nomecanal,False,zapping,nomeserver)

        elif re.search('secretstory4_s.php',link):
            print "Catcher: SS4"
            descobrirresolver('http://cdn.zuuk.net/secretstory4_s.php',nomecanal,False,zapping,nomeserver)

        elif re.search('streamago',link):
            print "Catcher: streamago"
            flive=re.compile('<iframe src="http://www.streamago.tv/iframe/(.+?)/"').findall(link)
            if not flive:
                if re.search('streamago.php?id=',url_frame):
                    flive=url_frame('http://tvfree.me/streamago.php?id=','')
            for chid in flive:
                embed=comuns.redirect('http://www.streamago.tv/iframe/'+chid)
                html=comuns.abrir_url(embed)
                if re.search('the page you requested cannot be found.',html):
                    if activado==False: mensagemok('TV Portuguesa','Stream está offline.')
                    return
                swf=re.compile('swfobject.embedSWF\("(.+?)",').findall(html)[0]
                fvars=re.compile('flashvars.xml = "(.+?)"').findall(html)[0]
                dados=comuns.abrir_url(fvars)
                print dados
                playpath=re.compile('<titolo id="(.+?)">').findall(dados)[0]
                rtmp=re.compile('<path><\!\[CDATA\[(.+?)\]\]></path>').findall(dados)[0]
                streamurl=rtmp + ' playPath=' + playpath + ' swfVfy=1 live=true swfUrl=http://www.streamago.tv' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)
                
        elif re.search('tv-msn',link):
            print "Catcher: tv-msn"
            if re.search('cdnbr.biz',link):
                url_frame=re.compile('src="(.+?)"').findall(link)[0]
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                link= comuns.abrir_url_tommy(url_frame,ref_data)
                swf='http://www.cdnbr.biz/' + re.compile("src='../(.+?)'").findall(link)[0]
            else:
                swf=re.compile("src='(.+?)'").findall(link)[0]

            variaveis=re.compile("file=(.+?).flv&streamer=(.+?)&").findall(link)[0]
            streamurl=variaveis[1] + ' playPath=' + variaveis[0]  + ' swfUrl='+swf+' live=true timeout=15 swfVfy=1 pageUrl='+url_frame
            
            comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search("<iframe style='position:relative; overflow:hidden; width:508px; height:408px; top:-8px; left:-8px;' src='http://tvzune.tv",link):
            print "Catcher: tvzune em tvpthd"
            streamurl=re.compile("<iframe.+?src='(.+?)'").findall(link)[0]
            descobrirresolver(streamurl,nomecanal,False,zapping,nomeserver)

        elif re.search('sicnoticias_sp.php',link):
            print "Catcher: sicnoticias"
            descobrirresolver('http://www.tugastream.com/sicnoticias_sp.php',nomecanal,False,zapping,nomeserver)
        
        elif re.search('tvph.googlecode.com',link):
            print "Catcher: tvph google code"
            if re.search('playeer.html',link):
                info=re.compile("cid=file=(.+?)&streamer=(.+?)'").findall(link)[0]
                rtmp=info[1]
                streamurl=rtmp + ' playPath='+info[0]+' swfUrl=http://www.tvzune.tv/jwplayer/jwplayer.flash.swf live=true pageUrl=' + url_frame
            else:
                streamurl=re.compile("cid=(.+?)'").findall(link)[0]
            comecarvideo(streamurl,nomecanal,True,zapping)
            

        elif re.search('TV ZUNE PLAYER 201',link):
            print "Catcher: player tvzune soft"
            rtmp=re.compile('streamer=(.+?)&').findall(link)[0]
            filep=re.compile('file=(.+?)&').findall(link)[0]
            ref_data = {'User-Agent':''}
            url_frame=url_frame.replace('canais','privado')
            html= comuns.abrir_url_tommy(url_frame,ref_data)

            ref_data = {'Accept': '*/*','User-Agent':'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/7.0; .NET4.0E; .NET4.0C; InfoPath.3; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729)','Cookie': 'jm3x_unique_user=1','Host': 'www.tvzune.tv','Connection': 'Keep-Alive'}
            nada= re.compile('<iframe.+?src="(.+?)"').findall(comuns.limparcomentarioshtml(comuns.abrir_url_tommy(html,ref_data),html))[0]

            ref_data = {'Accept': 'image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*','User-Agent':'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/7.0; .NET4.0E; .NET4.0C; InfoPath.3; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729)','Host': 'fire.tvzune.org','Connection': 'Keep-Alive'}
            nada= comuns.abrir_url_tommy(nada,ref_data)
            
            swf=re.compile('src="(.+?)"').findall(link)[0]
            streamurl=rtmp + ' playPath=' + filep + ' swfUrl=' + swf + ' swfVfy=1 live=1 pageUrl=' + html
            comecarvideo(streamurl,nomecanal,True,zapping)
            
        elif re.search('player_tvzune',link):
            print "Catcher: player tvzune"
            yoyo412=re.compile(yoyo115 + ' "(.+?)"').findall(link)[0]
            yoyo721='/'.join((yoyo412.split('/'))[:-1])
            yoyo428=re.compile('src="(.+?)"').findall(link)[0]
            yoyo683=re.compile(yoyo265 + '(.+?)"').findall(comuns.abrir_url(yoyo428))[0]
            yoyo378='/'.join((yoyo428.split('/'))[:-1]) + '/' + yoyo683
            streamurl=yoyo721 + ' playPath=' + yoyo412.split('/')[-1] + ' swfUrl=' +yoyo378 +' live=true pageUrl=' + url_frame
            comecarvideo(streamurl,nomecanal,True,zapping)
            

        elif re.search('stream4u', link):
            print "Catcher: stream4u"
            stream4u=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chid in stream4u:
                embed='http://www.stream4u.eu/embed.php?v='+chid+'&vw=650&vh=400&domain='+url_frame
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("'flashplayer': '(.+?)'").findall(html)[0]
                rtmp=re.compile("'streamer': '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ukcast.co', link):
            print "Catcher: ukcast.co"
            stream4u=re.compile('ukcast.co/.+?u=(.+?)&').findall(link)
            for chid in stream4u:
                embed='http://ukcast.co/embed.php?u='+chid+'&vw=100%&vh=100%'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                rtmp=re.compile('var str = "(.+?)";').findall(html)[0].replace('cdn','strm')
                swf=re.compile('new SWFObject\("(.+?)"').findall(html)[0]
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('valeucara', link):
            print "Catcher: valeucara"
            valeu=re.compile('<script type="text/javascript"> id="(.+?)";.+?></script>').findall(link)
            for chid in valeu:
                embed='http://www.valeucara.com/'+chid+'_s.php?width=650&height=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.limparcomentarioshtml(comuns.abrir_url_tommy(embed,ref_data),embed)
                if re.search('file: "',html):
                    streamurl=re.compile('file: "(.+?)"').findall(html)[0]
                    comecarvideo(streamurl,nomecanal,True,zapping)
                else: descobrirresolver(embed,nomecanal,html,zapping,nomeserver)


        elif re.search('veecast',link):
            print "Catcher: veecast"
            valeu=re.compile('src="http://www.veecast.net/e/(.+?)">').findall(link)
            for chid in valeu:
                embed='http://www.veecast.net/e/'+chid + '?width=640&height=480'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= urllib.unquote(comuns.abrir_url_tommy(embed,ref_data))
                rtmp=re.compile('streamer=(.+?)&').findall(html)[0]
                filep=re.compile('file=(.+?)&').findall(html)[0]
                swf=re.compile('src="(.+?)" type="application/x-shockwave-flash"').findall(html)[0]
                streamurl=rtmp + ' playPath=' + filep + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + url_frame
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('vercosasgratis', link):
            print "Catcher: vercosasgratis"
            cenas=re.compile('vercosasgratis.com/(.+?)"').findall(link)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            framesite='http://vercosasgratis.com/' + cenas
            html= comuns.abrir_url_tommy(framesite,ref_data)
            embed=re.compile("var url = '(.+?)'").findall(html)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html= comuns.abrir_url_tommy(embed,ref_data)
            swf=re.compile("SWFObject\('(.+?)'").findall(html)[0].replace('../','')
            rtmp=re.compile("'streamer', '(.+?)'").findall(html)[0]
            filep=re.compile("'file', '(.+?)'").findall(html)[0]
            streamurl=streamurl=rtmp + ' playPath=' + filep + ' swfUrl=http://vercosasgratis.com/' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
            comecarvideo(streamurl,nomecanal,True,zapping)
            
        elif re.search('veetle',url_frame) or re.search("src='http://veetle",link) or re.search('src="http://veetle',link):
            print "Catcher: veetle"
            if activado==False:
                if selfAddon.getSetting("verif-veetle3") == "false":
                    ok = mensagemok('TV Portuguesa','Necessita de instalar o addon veetle.','Este irá ser instalado já de seguida.')
                    import extract
                    urlfusion='http://fightnight-xbmc.googlecode.com/svn/addons/fightnight/plugin.video.veetle/plugin.video.veetle-0.3.1.zip' #v2.3
                    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
                    lib=os.path.join(path, 'plugin.video.veetle.zip')
                    comuns.downloader(urlfusion,lib)
                    addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
                    xbmc.sleep(2000)
                    dp = xbmcgui.DialogProgress()
                    #if dp.iscanceled(): dp.close()
                    dp.create("TV Portuguesa", "A instalar...")
                    try:
                        extract.all(lib,addonfolder,dp)
                        ok = mensagemok('TV Portuguesa','Veetle instalado / actualizado.','Necessita de reiniciar o XBMC.')
                        selfAddon.setSetting('verif-veetle3',value='true')
                    except:
                        ok = mensagemok('TV Portuguesa','Sem acesso para instalar Veetle. Instale o veetle','do repositório fightnight.','De seguida, active o Veetle nas definições do addon.')
                else:
                    ## PATCH SPTHD IN LSHD
                    if re.search('var urls = new Array',link):
                            framedupla=re.compile('new Array.+?"(.+?)".+?"(.+?)"').findall(link)[0]
                            if framedupla[0]==framedupla[1]: frame=framedupla[0]
                            else:
                                if activado==True: opcao=True
                                else:opcao= xbmcgui.Dialog().yesno("TV Portuguesa", "Escolha um stream da lista dos disponiveis.", "", "","Stream Extra", 'Stream Principal')
                                if opcao: frame=framedupla[0]
                                else: frame=framedupla[1]
                            descobrirresolver(frame, nomecanal,False,False,nomeserver)
                            return
                    
                    try:idembed=re.compile('/index.php/widget/index/(.+?)/').findall(link)[0]
                    except: idembed=re.compile('/index.php/widget#(.+?)/true/16:').findall(link)[0]
                    print "ID embed: " + idembed
                    try:
                        chname=comuns.abrir_url('http://fightnightaddons2.96.lt/tools/veet.php?id=' + idembed)
                        chname=chname.replace(' ','')
                        if re.search('DOCTYPE HTML PUBLIC',chname):
                            if activado==False: mensagemok('TV Portuguesa','Erro a obter link do stream. Tenta novamente.')
                            return
                        print "ID final obtido pelo TvM."
                    except:
                        chname=comuns.abrir_url('http://fightnight-xbmc.googlecode.com/svn/veetle/sporttvhdid.txt')
                        print "ID final obtido pelo txt."
                    print "ID final: " + chname
                    link=comuns.abrir_url('http://veetle.com/index.php/channel/ajaxStreamLocation/'+chname+'/flash')
                    if re.search('"success":false',link):
                        if activado==False: mensagemok('TV Portuguesa','O stream está offline.')
                    else:
                        streamfile='plugin://plugin.video.veetle/?channel=' + chname
                        comecarvideo(streamfile,nomecanal,True,zapping)

        elif re.search('veemi', link):
            print "Catcher: veemi"
            veemi=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chid in veemi:
                embed='http://www.veemi.com/embed.php?v='+chid+'&vw=650&vh=400&domain='+url_frame
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf=re.compile("SWFObject\('(.+?)'").findall(html)[0]
                rtmp=re.compile("'streamer', '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl=http://www.veemi.com/' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search('www.wcast', link):
            print "Catcher: wcast"
            wcast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in wcast:
                embed='http://www.wcast.tv/embed.php?u=' + chid+ '&vw=600&vh=470'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                swf='http://www.wcast.tv/player/player.swf'
                filelocation=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ucaster', link):
            print "Catcher: ucaster"
            ucaster=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?&s=(.+?)&g=1&a=1&l=').findall(link)
            if not ucaster: ucaster=re.compile('src="/ucaster.eu.php.+?fid=(.+?)" id="innerIframe"').findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?&amp;s=(.+?)&amp;g=1').findall(link)
            if not ucaster: ucaster=re.compile("flashvars='id=.+?&s=(.+?)&").findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?id=.+?&amp;s=(.+?)&amp;g=1').findall(link)
            if not ucaster: ucaster=re.compile('channel="(.+?)".+?g="1"').findall(link)
            #if not ucaster:
                #mensagemok('TV Portuguesa','Stream não é o do site responsável','logo não é possível visualizar.')
            for chname in ucaster:
                embed='http://www.ucaster.eu/embedded/' + chname + '/1/600/430'
                try:
                    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                    html= comuns.abrir_url_tommy(embed,ref_data)
                    swf=re.compile('SWFObject.+?"(.+?)",').findall(html)[0]
                    flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                    flashvars=flashvars.replace("')","&nada").split('l=&')
                    if flashvars[1]=='nada':
                        nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                        chid=re.compile("id=(.+?)&s=").findall(html)[0]
                    else:
                        nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                        chid=re.compile("id=(.+?)&s=").findall(html)[1]
                    nocanal=nocanal.replace('&','')
                except:
                    nocanal=chname
                    chid=re.compile("flashvars='id=(.+?)&s").findall(link)[0]
                    swf=re.compile("true' src='http://www.ucaster.eu(.+?)'").findall(link)[0]
                link=comuns.abrir_url('http://www.ucaster.eu:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                streamurl='rtmp://' + rtmpendereco + '/live playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.ucaster.eu' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('xuuby',link): ##proteccao tvdez
            print "Catcher: xuuby"
            xuuby=re.compile('chname="(.+?)".+?</script>').findall(link)
            if not xuuby: xuuby=re.compile('chname=(.+?)&').findall(link)
            for chname in xuuby:
                embed='http://www.xuuby.com/show2.php?chname='+chname+'&width=555&height=555&a=1'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                html=urllib.unquote(html)
                streamurl=re.compile('file: "(.+?)"').findall(html)[0]
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('youtube.com/v',link):
            print "Catcher: youtube"
            idvideo=re.compile('type="application/x-shockwave-flash" src="http://www.youtube.com/v/(.+?)&.+?"></object>').findall(link)[0]
            sources=[]
            import urlresolver
            embedvideo='http://www.youtube.com/watch?v=' + idvideo
            hosted_media = urlresolver.HostedMediaFile(url=embedvideo)
            sources.append(hosted_media)
            source = urlresolver.choose_source(sources)
            if source:
                streamurl=source.resolve()
                comecarvideo(streamurl,nomecanal,True,zapping)
                    
        elif re.search('yocast', link):
            print "Catcher: yocast"
            stream4u=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in stream4u:
                embed='http://www.yocast.tv/embed.php?s='+chid+'&width=650&height=400&domain='+url_frame
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                print html
                swf=re.compile("'flashplayer': '(.+?)'").findall(html)[0]
                rtmp=re.compile("'streamer': '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)



        elif re.search('yukons', link):
            print "Catcher: yukons"
            yukons=re.compile('kuyo&file=(.+?)&').findall(link)
            if not yukons: yukons=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not yukons: yukons=re.compile('channel="(.+?)".+?</script>').findall(link)
            if not yukons: yukons=re.compile('file=(.+?)&').findall(link)
            for chname in yukons:
                idnumb='37333730364637323734373333313632'
                ref_data = {'Host': 'yukons.net','Connection': 'keep-alive','Accept': '*/*','Referer': url_frame,'User-Agent':user_agent,'Cache-Control': 'max-age=0','Accept-Encoding': 'gzip,deflate,sdch'}
                link= comuns.abrir_url_tommy('http://yukons.net/yaem/' + idnumb,ref_data)
                idfinal=re.compile("return '(.+?)'").findall(link)[0]
                embed='http://yukons.net/embed/'+idnumb+'/'+idfinal+'/600/450'
                ref_data = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Referer': url_frame,'User-Agent':user_agent,'Host': 'yukons.net','Cache-Control': 'max-age=0','Accept-Encoding': 'gzip,deflate,sdch','Connection': 'keep-alive'}
                html= comuns.abrir_url_tommy(embed,ref_data)
                idrtmp=re.compile('FlashVars\|id\|(.+?)\|').findall(html)[0]
                pidrtmp=re.compile('\|pid\|\|(.+?)\|').findall(html)[0]
                swfrtmp=re.compile('SWFObject\|.+?\|\|\|(.+?)\|swf\|eplayer').findall(html)[0]
                #'Referer': 'http://yukons.net/' + swfrtmp + '.swf'
                ref_data = {'Referer': embed,'User-Agent':user_agent,'Host': 'yukons.net','Connection': 'keep-alive','Accept':'*/*','Accept-Encoding': 'gzip,deflate,sdch'}
                servertmp= comuns.abrir_url_tommy('http://yukons.net/srvload/'+ idrtmp,ref_data).replace('srv=','')

                streamurl='rtmp://' + servertmp + ':443/kuyo playPath=' + chname + '?id=' + idrtmp + '&pid=' + pidrtmp + ' swfUrl=http://yukons.net/'+swfrtmp + '.swf live=true conn=S:OK timeout=14 swfVfy=true pageUrl=' + embed
                #swf = 'http://yukons.net/'+swfrtmp + '.swf?streamer=rtmp://' + servertmp + ':443/kuyo&file='+chname+'&autostart=true&g=1&a=1&l='
                #streamurl='rtmp://' + servertmp + ':443/kuyo playPath=' + chname  + '?id=' + idrtmp + '&pid=' + pidrtmp + ' swfUrl=' + swf + ' live=true conn=S:OK timeout=14 swfVfy=true pageUrl=' + swf
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('wowcast.tv', link):
            print "Catcher: wowcast"
            stream4u=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chid in stream4u:
                embed='http://www.wowcast.tv/embed.php?stream='+chid+'&vw=650&vh=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                
                swf=re.compile('SWFObject\("(.+?)"').findall(html)[0]
                rtmp=re.compile('"streamer", "(.+?)"').findall(html)[0]
                streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('yycast', link): ##requires librtmp 14-9-2013
            print "Catcher: yycast"
            if activado==False:
                mensagemok("TV Portuguesa","Servidor incompativel.")
                gg
            #yycast=re.compile('fid="(.+?)";.+?</script><script type="text/javascript" src="http://www.yycast.com/javascript/embedPlayer.js"></script>').findall(link)
            #if not yycast: yycast=re.compile("file='(.+?).flv'.+?</script>").findall(link)
            #if not yycast: yycast=re.compile('fid="(.+?)".+?</script>').findall(link)
            #if not yycast: yycast=re.compile('channel="(.+?)".+?</script>').findall(link)
            #for chname in yycast:
            #    embed='http://yycast.com/embedded/'+ chname + '/1/555/435'
            #    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            #    html= comuns.abrir_url_tommy(embed,ref_data)
            #    #print html
            #    link=comuns.abrir_url('http://yycast.com:1935/loadbalancer')
            #    rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
            #    print rtmpendereco                
            #    #so.addParam('FlashVars', 'id=1516&s=sic880809&g=1&a=1&l=');
            #    swf=re.compile('SWFObject.+?"(.+?)"').findall(html)[0]
            #    idnum=re.compile("'FlashVars', 'id=(.+?)&s=.+?'").findall(html)[0]
            #    chnum=re.compile("'FlashVars', 'id=.+?&s=(.+?)&").findall(html)[0]
            #    #streamurl='rtmp://yycast.com:1935/live/_definst_/sicasdf. app=live playPath=' + chnum + '?id=' + idnum + ' swfVfy=1 timeout=15 conn=S:OK live=true swfUrl=http://yycast.com' + swf + ' pageUrl=' + embed
            #    streamurl='rtmp://' + rtmpendereco + '/live/ playPath=' + chnum + '?id=' + idnum + ' swfVfy=1 timeout=15 conn=S:OK live=true swfUrl=http://yycast.com' + swf + ' pageUrl=' + embed
            #    #print html
            #    #streamurl='rtmp://live.yycast.com/lb playPath=' + chname + ' live=true timeout=15 swfUrl=http://cdn.yycast.com/player/player.swf pageUrl=http://www.yycast.com/embed.php?fileid='+chname+'&vw=768&vh=432'
            #    comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('zcast.us', link):
            print "Catcher: zcast"
            zcast=re.compile('channel="(.+?)";.+?></script>').findall(link)
            for chname in zcast:
                embed='http://zcast.us/gen.php?ch=' + chname + '&width=700&height=480'
                streamurl='rtmp://gabon.zcast.us/liveedge' + ' playPath=' + url_frame + ' live=true timeout=15 swfVfy=1 swfUrl=http://player.zcast.us/player58.swf pageUrl=http://www.xuuby.com/'
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('zenex', link):
            print "Catcher: zenex"
            zenex=re.compile("channel='(.+?)',.+?</script>").findall(link)
            for chname in zenex:
                embed='http://www.zenex.tv/embedplayer/' + chname + '/1/555/435'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html= comuns.abrir_url_tommy(embed,ref_data)
                link=comuns.abrir_url('http://www.zenex.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                idnum=re.compile("'FlashVars'.+?id=(.+?)&s=.+?&").findall(html)[0]
                chnum=re.compile("'FlashVars'.+?id=.+?&s=(.+?)&").findall(html)[0]
                swf=re.compile('new SWFObject\("(.+?)"').findall(html)[0]
                streamurl='rtmp://' + rtmpendereco + '/zenex playPath=' + chnum + '?id=' + idnum + ' swfUrl=http://www.zenex.tv' + swf+ ' live=true conn=S:OK swfVfy=1 timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)


        elif re.search('src="http://www.dailymotion.com/embed',link):
            print "Catcher: dailymotion"
            idvideo=re.compile('<iframe.+?src="http://www.dailymotion.com/embed(.+?)"').findall(link)[0]
            sources=[]
            import urlresolver
            embedvideo='http://www.dailymotion.com/embed' + idvideo
            hosted_media = urlresolver.HostedMediaFile(url=embedvideo)
            sources.append(hosted_media)
            source = urlresolver.choose_source(sources)
            if source:
                streamurl=source.resolve()
                comecarvideo(streamurl,nomecanal,True,zapping)


        else:
            print "Catcher: noserver" 
            if activado==False:
                mensagemok('TV Portuguesa','Servidor não suportado')
                mensagemprogresso.close()
            else:
                try:debug.append(nomeserver)
                except: pass
    except Exception:
        if activado==False:
            mensagemprogresso.close()
            mensagemok('TV Portuguesa','Servidor não suportado.')
            (etype, value, traceback) = sys.exc_info()
            print etype
            print value
            print traceback
        else:
            try:debug.append(nomeserver)
            except: pass
        #buggalo.onExceptionRaised()

def iniciagravador(finalurl,siglacanal,name,directo):
    if downloadPath=='':
        xbmcgui.Dialog().ok('TV Portuguesa','Necessitas de introduzir a pasta onde vão ficar','as gravações. Escolhe uma pasta com algum espaço','livre disponível.')
        dialog = xbmcgui.Dialog()
        pastafinal = dialog.browse(int(3), "Escolha pasta para as gravações", 'files')
        selfAddon.setSetting('pastagravador',value=pastafinal)
        return
    if directo==True:
        if re.search('rtmp://',finalurl):
            finalurl=finalurl.replace('playPath=','-y ').replace('swfVfy=1','').replace('conn=','-C ').replace('live=true','-v').replace('swfUrl=','-W ').replace('pageUrl=','-p ').replace('token=','-T ').replace('app=','-a ').replace('  ',' ')
            import gravador
            gravador.verifica_so('-r ' + finalurl,name,siglacanal,directo)
        else: xbmc.executebuiltin("XBMC.Notification(TV Portuguesa, Stream não gravável. Escolha outro.,'100000'," + tvporpath + art + "icon32-ver1.png)")

def libalternativo(finalurl):
    if xbmc.getCondVisibility('system.platform.windows'):
        import newrtmp
        finalurl,spsc=newrtmp.start_stream(rtmp=finalurl)
    else: spsc=''
    return finalurl,spsc

def comecarvideo(finalurl,name,directo,zapping,thumb=''):
    if activado==True: activadoextra.append(finalurl)
    else: comecarvideo2(finalurl,name,directo,zapping,thumb='')

def comecarvideo2(finalurl,name,directo,zapping,thumb=''):
    listacanaison=selfAddon.getSetting("listacanais")
    siglacanal=''
    namega=name.replace('-','')
    comuns.GA("player",namega)
    if directo==True:
        thumb=name.replace('Mais TVI-','maistvi-ver2.png').replace('AXN-','axn-ver2.png').replace('FOX-','fox-ver2.png').replace('RTP 1-','rtp1-ver2.png').replace('RTP 2-','rtp2-ver2.png').replace('SIC-','sic-ver3.png').replace('SPORTTV 1-','sptv1-ver2.png').replace('SPORTTV 1 HD-','sptv1-ver2.png').replace('SPORTTV 2-','sptv2-ver2.png').replace('SPORTTV 3-','sptv3-ver2.png').replace('SPORTTV 4-','sptv4-ver2.png').replace('SPORTTV 5-','sptv5-ver2.png').replace('SPORTTV LIVE-','sptvlive-ver1.png').replace('TVI-','tvi-ver2.png').replace('Discovery Channel-','disc-ver2.png').replace('AXN Black-','axnb-ver2.png').replace('AXN White-','axnw-ver2.png').replace('FOX Crime-','foxc-ver2.png').replace('FOX Life-','foxl-ver3.png').replace('FOX Movies-','foxm-ver2.png').replace('Eurosport-','eusp-ver2.png').replace('Hollywood-','hwd-ver2.png').replace('MOV-','mov-ver2.png').replace('Canal Panda-','panda-ver2.png').replace('VH1-','vh1-ver2.png').replace('Benfica TV 1-','btv1-ver1.png').replace('Benfica TV 2-','btv2-ver1.png').replace('Porto Canal-','pcanal-ver2.png').replace('Big Brother VIP-','bbvip-ver2.png').replace('SIC K-','sick-ver2.png').replace('SIC Mulher-','sicm-ver3.png').replace('SIC Noticias-','sicn-ver2.png').replace('SIC Radical-','sicrad-ver2.png').replace('TVI24-','tvi24-ver2.png').replace('TVI Ficção-','tvif-ver2.png').replace('Syfy-','syfy-ver1.png').replace('Odisseia-','odisseia-ver1.png').replace('História-','historia-ver1.png').replace('National Geographic Channel-','natgeo-ver1.png').replace('MTV-','mtv-ver1.png').replace('CM TV-','cmtv-ver1.png').replace('RTP Informação-','rtpi-ver1.png').replace('Disney Channel-','disney-ver1.png').replace('Motors TV-','motors-ver1.png').replace('ESPN-','espn-ver1.png').replace('Fashion TV-','fash-ver1.png').replace('A Bola TV-','abola-ver1.png').replace('Casa dos Segredos 4-','casadseg-ver1.png').replace('RTP Açores-','rtpac-ver1.png').replace('RTP Internacional-','rtpint-ver1.png').replace('RTP Madeira-','rtpmad-ver1.png').replace('RTP Memória-','rtpmem-ver1.png').replace('RTP Africa-','rtpaf-ver1.png').replace('Panda Biggs-','pbiggs-ver1.png').replace('TV Record-','record-v1.png').replace('TV Globo-','globo-v1.png').replace('Eurosport 2-','eusp2-ver1.png').replace('Discovery Turbo-','discturbo-v1.png').replace('Toros TV-','toros-v1.png').replace('Chelsea TV-','chel-v1.png').replace('Disney Junior-','djun-ver1.png').replace('Económico TV-','econ-v1.png').replace('Caça e Pesca-','cacapesca-v1.png').replace('Sporting TV-','scptv-ver1.png')
        name=name.replace('-','')
        progname=name

        siglacanal=name.replace('SPORTTV 1','SPTV1').replace('SPORTTV 2','SPTV2').replace('SPORTTV 3','SPTV3').replace('SPORTTV 4','SPTV4').replace('SPORTTV 5','SPTV5').replace('SPORTTV LIVE','SPTVL').replace('Discovery Channel','DISCV').replace('AXN Black','AXNBL').replace('AXN White','AXNWH').replace('FOX Crime','FOXCR').replace('FOX Life','FLIFE').replace('FOX Movies','FOXM').replace('Eurosport','EURSP').replace('Hollywood','HOLLW').replace('Canal Panda','PANDA').replace('Benfica TV 1','SLB').replace('Benfica TV 2','SLB2').replace('Porto Canal','PORTO').replace('SIC K','SICK').replace('SIC Mulher','SICM').replace('SIC Noticias','SICN').replace('SIC Radical','SICR').replace('TVI24','TVI24').replace('TVI Ficção','TVIFIC').replace('Mais TVI','SEM').replace('Syfy','SYFY').replace('Odisseia','ODISS').replace('História','HIST').replace('National Geographic Channel','NGC').replace('MTV','MTV').replace('CM TV','CMTV').replace('RTP Informação','RTPIN').replace('Disney Channel','DISNY').replace('Motors TV','MOTOR').replace('ESPN America','SEM').replace('Fashion TV','FASH').replace('MOV','SEM').replace('A Bola TV','ABOLA').replace('Panda Biggs','BIGGS').replace('RTP 1','RTP1').replace('RTP 2','RTP2').replace('RTP Açores','RTPAC').replace('RTP Madeira','RTPMD').replace('RTP Memória','RTPM').replace('Disney Junior','DISNYJ').replace('RTP Africa','RTPA').replace('Económico TV','ETVHD').replace('Chelsea TV','CHELS').replace('TV Globo','GLOBO').replace('TV Record','TVREC').replace('Eurosport 2','EURS2').replace('Discovery Turbo','DISCT').replace('Toros TV','TOROTV').replace('Caça e Pesca','CAÇAP')
        #if selfAddon.getSetting("prog-player3") == "true":
        #    try:
        #        
        #        progname=p_umcanal(p_todos(),siglacanal,'nomeprog')
        #        if progname=='':pass
        #        else: name=name + ' ' + progname
        #    except: pass
        listitem = xbmcgui.ListItem(progname, iconImage="DefaultVideo.png", thumbnailImage=tvporpath + art + thumb)
    else: listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumb)
    if zapping==True:
        conteudoficheiro=comuns.openfile(('zapping'))
        comuns.savefile(('zapping', conteudoficheiro + '_comeca_' + name + '_nomecanal_' + finalurl + '_thumb_' + thumb + '_acaba_'))
    else:

        #finalurl,spscpid=libalternativo(finalurl)
        spscpid='nada'
        if re.search('.f4m',finalurl):
            from proxyf4m import f4mProxyHelper
            helper=f4mProxyHelper()
            finalurl,spscpid = helper.start_proxy(finalurl, name)
        
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('IsPlayable', 'true')
        playlist.add(finalurl, listitem)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]),True,listitem)
        mensagemprogresso.close()
        dialogWait = xbmcgui.DialogProgress()
        dialogWait.create('TV Portuguesa', 'A carregar...')
        dialogWait.close()
        del dialogWait
        
        player = Player(finalurl=finalurl,name=name,siglacanal=siglacanal,directo=directo,spscpid=spscpid)
        if "RunPlugin" in finalurl:
            xbmc.executebuiltin(finalurl)
        else:

            player.play(playlist)
            lat123 = menulateral("menulateral.xml" , tvporpath, "Default",finalurl=finalurl,name=name,siglacanal=siglacanal,directo=directo)
        
            while player.is_active:
                if listacanaison == "true":
                    if xbmc.getCondVisibility('Window.IsActive(videoosd)') and directo==True:
                        xbmc.executebuiltin('XBMC.Control.Move(videoosd,9999)')
                        lat123.doModal()
                        while xbmc.getCondVisibility('Window.IsActive(videoosd)'): pass
                player.sleep(1000)
            
            #if not player.is_active:
            #    print "Parou. Saiu do ciclo."
            #    sys.exit(0)
                
                #player.sleep(10000)
            #print "ERRO"

class Player(xbmc.Player):
      def __init__(self,finalurl,name,siglacanal,directo,spscpid):
            if selfAddon.getSetting("playertype") == "0": player = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
            elif selfAddon.getSetting("playertype") == "1": player = xbmc.Player(xbmc.PLAYER_CORE_MPLAYER)
            elif selfAddon.getSetting("playertype") == "2": player = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
            elif selfAddon.getSetting("playertype") == "3": player = xbmc.Player(xbmc.PLAYER_CORE_PAPLAYER)
            else: player = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
            self.is_active = True
            self._refInfo = True
            self._totalTime = 999999
            self._finalurl=finalurl
            self._name=name
            self._siglacanal=siglacanal
            self._directo=directo
            self._spscpid=spscpid
            print "Criou o player"
            #player.stop()

      def onPlayBackStarted(self):
            print "Comecou o player"
                              
      def onPlayBackStopped(self):
            print "Parou o player"
            self.is_active = False
            if re.search('.f4m',self._finalurl): self._spscpid.set()
            #import newrtmp
            #newrtmp.stop_stream(self._spscpid)
            #opcao= xbmcgui.Dialog().yesno("TV Portuguesa", "Este stream funciona? ", "(exemplificação / ainda não funciona)", "",'Sim', 'Não')
            ###### PERGUNTAR SE O STREAM E BOM #####            

      def onPlayBackEnded(self):              
            self.onPlayBackStopped()
            print 'Chegou ao fim. Playback terminou.'


      def sleep(self, s): xbmc.sleep(s) 

class PlaybackFailed(Exception):
      '''XBMC falhou a carregar o stream'''

MODE_EPG = 'EPG'
MODE_TV = 'TV'
MODE_OSD = 'OSD'

ACTION_LEFT = 1
ACTION_RIGHT = 2
ACTION_UP = 3
ACTION_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_SHOW_INFO = 11
ACTION_NEXT_ITEM = 14
ACTION_PREV_ITEM = 15

ACTION_MOUSE_WHEEL_UP = 104
ACTION_MOUSE_WHEEL_DOWN = 105
ACTION_MOUSE_MOVE = 107

KEY_NAV_BACK = 92
KEY_CONTEXT_MENU = 117
KEY_HOME = 159
C_CHANNELS_LIST=6000

##################################MENU LATERAL######################
class menulateral(xbmcgui.WindowXMLDialog):

    def __init__( self, *args, **kwargs ):
            xbmcgui.WindowXML.__init__(self)
            self.finalurl = kwargs[ "finalurl" ]
            self.siglacanal = kwargs[ "siglacanal" ]
            self.name = kwargs[ "name" ]
            self.directo = kwargs[ "directo" ]

    def onInit(self):
        self.updateChannelList()

    def onAction(self, action):
        if action.getId() in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, KEY_CONTEXT_MENU]:
            self.close()
            return

    def onClick(self, controlId):
        if controlId == 4001:
            self.close()
            request_servidores('','[B]%s[/B]' %(self.name))

        elif controlId == 40010:
            self.close()
            iniciagravador(self.finalurl,self.siglacanal,self.name,self.directo)

        elif controlId == 203:
            #xbmc.executebuiltin("XBMC.PlayerControl(stop)")
            self.close()

        elif controlId == 6000:
            listControl = self.getControl(C_CHANNELS_LIST)
            item = listControl.getSelectedItem()
            nomecanal=item.getProperty('chname')
            self.close()
            request_servidores('',nomecanal)

        
        #else:
        #    self.buttonClicked = controlId
        #    self.close()

    def onFocus(self, controlId):
        pass

    def updateChannelList(self):
        idx=-1
        listControl = self.getControl(C_CHANNELS_LIST)
        listControl.reset()
        canaison=comuns.openfile(('canaison'))
        canaison=canaison.replace('[','')
        lista=re.compile('B](.+?)/B]').findall(canaison)
        for nomecanal in lista:
            idx=int(idx+1)
            if idx==0: idxaux=' '
            else:
                idxaux='%4s.' % (idx)
                item = xbmcgui.ListItem(idxaux + ' %s' % (nomecanal), iconImage = '')
                item.setProperty('idx', str(idx))
                item.setProperty('chname', '[B]' + nomecanal + '[/B]')
                listControl.addItem(item)
        
    def updateListItem(self, idx, item):
        channel = self.channelList[idx]
        item.setLabel('%3d. %s' % (idx+1, channel.title))
        item.setProperty('idx', str(idx))

    def swapChannels(self, fromIdx, toIdx):
        if self.swapInProgress: return
        self.swapInProgress = True

        c = self.channelList[fromIdx]
        self.channelList[fromIdx] = self.channelList[toIdx]
        self.channelList[toIdx] = c

        # recalculate weight
        for idx, channel in enumerate(self.channelList):
            channel.weight = idx

        listControl = self.getControl(C_CHANNELS_LIST)
        self.updateListItem(fromIdx, listControl.getListItem(fromIdx))
        self.updateListItem(toIdx, listControl.getListItem(toIdx))

        listControl.selectItem(toIdx)
        xbmc.sleep(50)
        self.swapInProgress = False
