import xbmc,xbmcaddon,subprocess,os,re,urllib

selfAddon = xbmcaddon.Addon(id='plugin.video.tvpor')
addonPath= selfAddon.getAddonInfo("path")
if xbmc.getCondVisibility('system.platform.windows'):
    libpath=os.path.join(addonPath,'resources','emulador','windows.exe')
if xbmc.getCondVisibility('system.platform.linux'):
    if os.uname()[4] == "armv6l": libpath=os.path.join(addonPath,'resources','emulador','raspberry')

print libpath

def start_stream(rtmp=''):
    if rtmp=='':
        print "EMPTY RTMP"
        return
    if re.search('rtmp://',rtmp) or re.search('rtmpe://',rtmp) or re.search('rtmpt://',rtmp):
        args=rtmp.replace('playPath=','-y ').replace('swfVfy=1','').replace('conn=','-C ').replace('live=true','-v').replace('swfUrl=','-W ').replace('pageUrl=','-p ').replace('token=','-T ').replace('app=','-a ').replace('  ',' ') + ' -D 127.0.0.1 -g 9000'
        print args
        #cmd = [libpath, '-D', '127.0.0.1', '-g','9000']
        #spsc = subprocess.Popen(cmd, shell=True, stdin=None, stdout=None, stderr=None)
        #spsc = subprocess.Popen(libpath, args)
        spsc = subprocess.Popen(args, executable=libpath, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        #rtmp=urllib.quote(rtmp,safe='').replace('%3D','=')
        #temp=rtmp.replace('playPath=','&y=').replace('swfVfy=1','').replace('conn=','&C=').replace('live=true','').replace('swfUrl=','&W=').replace('pageUrl=','&p=').replace('token=','&T=').replace('app=','&a=').replace('timeout=','&m=').replace(' ','')
        #final='http://127.0.0.1:9000/?r=%s' % (temp)
        final='http://127.0.0.1:9000'
        return final,spsc
    else:
        return rtmp,''

def stop_stream(spsc):
    if xbmc.getCondVisibility('system.platform.windows'):
        #subprocess.Popen('taskkill /F /IM windows.exe /T',shell=True)
        subprocess.Popen('taskkill /F /IM windows.exe /T')
    else:
        try:spsc.kill()
        except:pass
        xbmc.sleep(100)
        try:spsc.wait()
        except:pass
        xbmc.sleep(100)         
