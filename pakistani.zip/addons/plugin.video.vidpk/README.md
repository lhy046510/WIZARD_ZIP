This is an XBMC Video Plugin for streaming content from vidpk.com:
Pakistan's premier video sharing and entertainment website
