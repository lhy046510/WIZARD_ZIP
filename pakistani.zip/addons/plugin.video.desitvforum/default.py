import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import urllib, urllib2
import re, string
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
net = Net()
import unicodedata
import traceback
import os.path
import urlresolver
import sys
import HTMLParser
html_parser = HTMLParser.HTMLParser()

# Urls
Base_Url = 'http://tv.desitvforum.net/'
BollywoodMovies_Url = Base_Url + 'index.php?option=com_content&task=category&sectionid=61&id=892&Itemid=86&filter=watch+online&limit=100'
TellyVideos_Urls = {}
TellyVideos_Urls['Latest Videos'] = Base_Url + 'index.php?option=com_content&task=view&id=5993&Itemid=105'
TellyVideos_Urls['Star World Premiere HD'] = Base_Url + 'index.php?option=com_content&task=section&id=109&Itemid=225'
TellyVideos_Urls['WWE'] = Base_Url + 'index.php?option=com_content&task=section&id=92&Itemid=205'
TellyVideos_Urls['Big Magic'] = Base_Url + 'index.php?option=com_content&task=section&id=102&Itemid=215'
TellyVideos_Urls['Utv Stars'] = Base_Url + 'index.php?option=com_content&task=section&id=98&Itemid=211'
TellyVideos_Urls['Zee Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=22&Itemid=156'
TellyVideos_Urls['Star Plus Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=20&Itemid=157'
TellyVideos_Urls['Life Ok'] = Base_Url + 'index.php?option=com_content&task=section&id=99&Itemid=212'
TellyVideos_Urls['Star One'] = Base_Url + 'index.php?option=com_content&task=section&id=21&Itemid=161'
TellyVideos_Urls['Colors Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=67&Itemid=158'
TellyVideos_Urls['Sony Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=18&Itemid=159'
TellyVideos_Urls['Sab Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=23&Itemid=164'
TellyVideos_Urls['Sahara One'] = Base_Url + 'index.php?option=com_content&task=section&id=19&Itemid=160'
TellyVideos_Urls['KIDs'] = Base_Url + 'index.php?option=com_content&task=section&id=85&Itemid=191'
TellyVideos_Urls['Channel [V]'] = Base_Url + 'index.php?option=com_content&task=section&id=90&Itemid=197'
TellyVideos_Urls['MTV'] = Base_Url + 'index.php?option=com_content&task=section&id=59&Itemid=166'
TellyVideos_Urls['Zoom Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=60&Itemid=167'
TellyVideos_Urls['Star World'] = Base_Url + 'index.php?option=com_content&task=section&id=93&Itemid=200'
TellyVideos_Urls['DD National'] = Base_Url + 'index.php?option=com_content&task=section&id=87&Itemid=193'
TellyVideos_Urls['Mahuaa Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=91&Itemid=199'
TellyVideos_Urls['Star Jalsha'] = Base_Url + 'index.php?option=com_content&task=section&id=95&Itemid=202'
TellyVideos_Urls['Zee Marathi'] = Base_Url + 'index.php?option=com_content&task=section&id=97&Itemid=204'
TellyVideos_Urls['Star Parvah'] = Base_Url + 'index.php?option=com_content&task=section&id=96&Itemid=203'
TellyVideos_Urls['Zee Bangla'] = Base_Url + 'index.php?option=com_content&task=section&id=100&Itemid=213'
TellyVideos_Urls['BIG Thrill'] = Base_Url + 'index.php?option=com_content&task=section&id=103&Itemid=216'
TellyVideos_Urls['Discovery KIDs'] = Base_Url + 'index.php?option=com_content&task=section&id=104&Itemid=220'
TellyVideos_Urls['TLC'] = Base_Url + 'index.php?option=com_content&task=section&id=105&Itemid=221'
TellyVideos_Urls['AXN'] = Base_Url + 'index.php?option=com_content&task=section&id=106&Itemid=222'
TellyVideos_Urls['Etv Bangla'] = Base_Url + 'index.php?option=com_content&task=section&id=107&Itemid=223'
TellyVideos_Urls['NDTV Imagine'] = Base_Url + 'index.php?option=com_content&task=section&id=57&Itemid=163'
TellyVideos_Urls['Mastii'] = Base_Url + 'index.php?option=com_content&task=section&id=108&Itemid=224'
TellyVideos_Urls['Star Utsav'] = Base_Url + 'index.php?option=com_content&task=section&id=65&Itemid=165'
TellyVideos_Urls['9X INX Media'] = Base_Url + 'index.php?option=com_content&task=section&id=58&Itemid=162'
TellyVideos_Urls['Real Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=83&Itemid=186'
TellyVideos_Urls['Other Tv Shows'] = Base_Url + 'index.php?option=com_content&task=section&id=86&Itemid=192'
TellyVideos_Urls['Shows & Concerts'] = Base_Url + 'index.php?option=com_content&task=section&id=15&Itemid=169'
PakTv_Urls = {}
PakTv_Urls['ARY Digital Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=73&Itemid=180'
PakTv_Urls['Geo Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=74&Itemid=181'
PakTv_Urls['Hum Tv'] = Base_Url + 'index.php?option=com_content&task=section&id=75&Itemid=182'
PakTv_Urls['Pakistani Shows & Concerts'] = Base_Url + 'index.php?option=com_content&task=section&id=82&Itemid=177'
PakTv_Urls['Pakistani Stage Shows'] = Base_Url + 'index.php?option=com_content&task=section&id=81&Itemid=178'
CricketTv_Urls = {}
CricketTv_Urls['Cricket Videos'] = Base_Url + 'index.php?option=com_content&task=section&id=26&Itemid=60'


# Plugin 
pluginId = 'plugin.video.desitvforum'
addon = Addon(pluginId, sys.argv)
settings = xbmcaddon.Addon(id=pluginId)

__language__ = settings.getLocalizedString

##### Queries ##########
mode = addon.queries['mode']
url = addon.queries.get('url', None)
regex = addon.queries.get('regex', None)
limitStart = addon.queries.get('limitStart', None)
title = addon.queries.get('title', None)

# Ensure variable is defined
try:
    __pDialog__ 
except NameError:
    __pDialog__ = None

try:
    __pFileName__ 
except NameError:
    __pFileName__ = None

print 'Mode: ' + str(mode)
print 'URL: ' + str(url)
print 'LimitStart: ' + str(limitStart)

if limitStart is None:
    limitStart = '0'
else: 
    limitStartInt = int(limitStart) + 100
    limitStart = str(limitStartInt)

def MainMenu():  #homescreen
    print 'desitvforum home menu'
    addon.add_directory({'mode': 'GetMovieTitles', 'url': BollywoodMovies_Url, 'limitStart': limitStart}, {'title':  'Bollywood Movies - Latest & Exclusive'})
    addon.add_directory({'mode': 'TvChannelsMenu', 'url': 'TellyVideos'}, {'title':  'Telly Videos'})
    addon.add_directory({'mode': 'TvChannelsMenu', 'url': 'PakTv'}, {'title':  'Pak Tv'})
    addon.add_directory({'mode': 'TvChannelsMenu', 'url': 'CricketTv'}, {'title':  'Cricket Tv'})
    addon.add_directory({'mode': 'ResolverSettings'}, {'title':  'Resolver Settings'})
    addon.end_of_directory()

def TvChannelsMenu(url):  #homescreen
    print 'desitvforum tv channel menu'
    urlDict = {};
    if url == 'TellyVideos':
        urlDict = TellyVideos_Urls
    elif url == 'PakTv':
        urlDict = PakTv_Urls
    elif url == 'CricketTv':
        urlDict = CricketTv_Urls

    for name, link in urlDict.iteritems():
        addon.add_directory({'mode': 'GetTvTitles', 'url': link}, {'title':  name})
    addon.end_of_directory()

def GetMovieTitles(url): # Get Movie Titles
    url = UrlDecode(url)
    print 'desitvforum get Movie Titles Menu'
    print 'Url: ' + str(url)
    html = net.http_GET(url).content
    keyNext = 'Next&nbsp;&gt;</a>'
    findNext = html.find(keyNext)
    html = html[re.search('sectiontableheader', html).end():re.search('sectiontablefooter', html).end()]
    match = re.compile('<a href="(.+?)">.+?([\w][,.?!*&\'@\w\s\(\)\]\[-]+) Watch', re.MULTILINE | re.DOTALL).findall(html)
    for link, name in match:
        name = UrlDecode(name)
        print '**************************************'
        print 'Link:' + link
        print 'Name:' + name
        print '**************************************'
        link = UrlEncode(Base_Url + link)
        addon.add_directory({'mode': 'GetLinks', 'url': link, 'title': UrlEncode(name), 'limitStart': limitStart}, 
                            {'title':  name})
    if findNext > -1:
        nextUrl = BollywoodMovies_Url + '&limitstart='+limitStart
        addon.add_directory({'mode': 'GetMovieTitles', 'url': nextUrl, 'limitStart': limitStart}, 
                            {'title':  'Next Page >>'})
    addon.end_of_directory()

def GetTvTitles(url): # Get Movie Titles
    url = UrlDecode(url)
    print 'desitvforum get Tv Titles Menu'
    print 'Url: ' + str(url)
    html = net.http_GET(url).content
    match = re.compile('<a href="(.+?)" class="(?:category|latestnews)">\n+\t+(.+?)</a>',).findall(html)
    for link, name in match:
        print 'UndecodedName:' + str(name)
        name = UrlDecode(name)
        watchOnlineMatch = re.search("Video Watch Online", name)
        if watchOnlineMatch:
            name = name[:watchOnlineMatch.start()]
        print '**************************************'
        print 'Link:' + link
        print 'Name:' + name
        print '**************************************'
        link = UrlEncode(Base_Url + link + '&limit=10000')
        addon.add_directory({'mode': 'GetTvEpisodes', 'url': link}, 
                            {'title':  name})
    addon.end_of_directory()

def GetTvEpisodes(url): # Get Tv Titles 2
    url = UrlDecode(url)
    print 'desitvforum get Tv Titles 2 Menu'
    print 'Url: ' + str(url)
    html = net.http_GET(url).content
    keyNext = 'Next&nbsp;&gt;</a>'
    findNext = html.find(keyNext)
    match = re.compile('<tr class="sectiontableentry[0-9]" >.+?<a href="(.+?)">\n+\t+(.+?)\t+</a>',
                       re.DOTALL).findall(html)
    for link, name in match:
        name = UrlDecode(name)
        watchOnlineMatch = re.search("(Video Watch Online|Video|Watch Online)", name)
        if watchOnlineMatch:
            name = name[:watchOnlineMatch.start()]
        else:
            writtenUpdateMatch = re.search("(Written Update)", name)
            if writtenUpdateMatch:
                continue
        print '**************************************'
        print 'Link:' + link
        print 'Name:' + name
        print '**************************************'
        link = UrlEncode(Base_Url + link)
        addon.add_directory({'mode': 'GetLinks', 'url': link, 'title': UrlEncode(name)}, 
                            {'title':  name})
    if findNext > -1:
        addon.add_directory({'mode': 'GetTvEpisodes', 'url': UrlEncode(url)}, 
                            {'title':  'Next Page >>'})
    addon.end_of_directory()

def GetLinks(url,title): # Get Video Links
    url = UrlDecode(url)
    title = UrlDecode(title)
    print 'In GetLinks %s' % url
    html = net.http_GET(url).content
    match = re.search( 'contentpaneopen', html )
    html = html[match.end():]
    match = re.search( 'contentpaneopen', html )
    html = html[match.end():]
    match = re.compile('href="(.+?)" target="_blank">(.+?)<', 
                       re.MULTILINE | re.DOTALL).findall(html)
    sources = []
    if not match:
        match = re.compile("<script src='(http://cdn.playwire.com/(?:.+?)/embed/(?:.+?).js)'>").findall(html)
        if match:
            link = match[0]
            match = list()
            match.append((link,title))
            print 'CDN MAtch' +str(match)
    for link, name in match:
        name = UrlDecode(name)
        linkTitle = title
        print 'URL = ' + link + ' Name = ' + name
        partMatch = re.search('( Part| part| Pt| pt)', name)
        if partMatch:
            part = ' - Part ' + name[partMatch.end():]
            linkTitle = linkTitle + part
            name = GetDomain(link) + ' - ' + linkTitle 
        else:
            clickMatch = re.search('Click Here', name)
            if clickMatch is None:
                name = GetDomain(link) + ' - ' + name
            else:
                name = GetDomain(link) + ' - ' + linkTitle 
        
        hosted_media = urlresolver.HostedMediaFile(url=link, title=name)
        print 'HostedMedia = ' + str(hosted_media)
        if not hosted_media:
            continue
        link = UrlEncode(link)
        playAction = 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 'PlayVideo', 'url': link, 'title': UrlEncode(linkTitle)})
        downloadAction = 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 'DownloadVideo', 'url': link, 'title': UrlEncode(linkTitle)})
        contextMenuItems = [('Play Video', playAction),('Download Video', downloadAction)]
        addon.add_item({'mode': 'PlayVideo', 'url': link, 'title': UrlEncode(linkTitle)}, 
                       {'title': name}, 
                       contextMenuItems, True)
    addon.end_of_directory()
            
def PlayVideo(url,title,download=False):
    url = UrlDecode(url)
    title = UrlDecode(title)
    print 'In PlayVideo' 
    print 'URL: %s' % url
    print 'Title: %s' % title
    source = urlresolver.HostedMediaFile(url=url, title=title)
    if source:
        streamUrl = source.resolve()
        if streamUrl:
            if not download:
                addon.resolve_url(source.resolve())
            else:
                DownloadVideo(streamUrl,title)

def DownloadVideo(url, title):
    fileName = url.split('?')[0].strip()
    extension = os.path.splitext(fileName)[1][1:].strip() 
    #remove  invalid file characters
    title = title.replace("/","")
    title = title + "." + extension
    if settings.getSetting('download_path') == '':
        try:
            downloadPath = xbmcgui.Dialog().browse(3, language(30002),'files', '', False, False, '')
            if downloadPath == '':
                return None
            settings.setSetting(id='download_path', value=downloadPath)
            if not os.path.exists(downloadPath):
                os.mkdir(downloadPath)
        except:
            pass
    filePath = xbmc.makeLegalFilename(os.path.join(settings.getSetting('download_path'), title))
    if os.path.isfile(filePath):
        return None
    global __pDialog__
    global __pFileName__
    __pFileName__ = title
    __pDialog__ = xbmcgui.DialogProgress()
    __pDialog__.create('DesitvForum', __language__(30003), __language__(30004))
    try:
        print 'DownloadVideoURL:' + url
        print 'DownloadVideoFilePath:' + filePath
        urllib.urlretrieve(url, filePath, VideoReportHook)
        #urllib.urlretrieve(url, filePath)
        print 'DownloadedVideo'
        __pDialog__.close()
        return filePath
    except Exception, e:
        print "URLRetrieve Error: %s" % e
        pass
    __pDialog__.close()
    xbmc.sleep(500)
    if os.path.isfile(filePath):
        try:
            os.remove(filePath)
        except:
            pass
    return None

def VideoReportHook(count, blocksize, totalsize):
    percent = int(float(count * blocksize * 100) / totalsize)
    global __pDialog__
    global __pFileName__
    __pDialog__.update(percent, __language__(30003), __pFileName__, __language__(30004))
    if __pDialog__.iscanceled():
        raise Exception


def UrlEncode(value): 
    if isinstance(value, unicode): 
        return urllib.quote(value.encode("utf-8"))
    else: 
        return urllib.quote(value)

def UrlDecode(value):
    #return urllib.unquote(html_parser.unescape(value).encode("utf-8"))
    #return html_parser.unescape(urllib.unquote(value)).encode("utf-8")
    return html_parser.unescape(urllib.unquote(value.decode("utf-8","ignore")))

def GetDomain(url):
    tmp = re.compile('//(.+?)/').findall(url)
    domain = 'Unknown'
    if len(tmp) > 0 :
        domain = tmp[0].replace('www.', '')
        return domain

if mode == 'main': 
    MainMenu()
elif mode == 'TvChannelsMenu': 
    TvChannelsMenu(url)
elif mode == 'GetMovieTitles': 
    GetMovieTitles(url)
elif mode == 'GetTvTitles': 
    GetTvTitles(url)
elif mode == 'GetTvEpisodes': 
    GetTvEpisodes(url)
elif mode == 'GetLinks':
    GetLinks(url,title)
elif mode == 'PlayVideo': 
    PlayVideo(url,title)
elif mode == 'DownloadVideo': 
    PlayVideo(url,title,True)
elif mode == 'ResolverSettings':
    urlresolver.display_settings()

