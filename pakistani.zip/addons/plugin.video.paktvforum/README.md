This is an XBMC Video Plugin for streaming content from pakistani forums

Using [xbmcswift2 framework](http://www.xbmcswift.com/en/latest/)