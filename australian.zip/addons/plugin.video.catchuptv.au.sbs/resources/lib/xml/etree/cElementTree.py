# Wrapper module for _elementtree

from _elementtree import *
