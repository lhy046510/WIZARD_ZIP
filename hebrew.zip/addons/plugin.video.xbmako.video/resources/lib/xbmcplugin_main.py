# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin

from MediaWindow import MediaWindow, DirectoryItem

class Main:
    def __init__( self ):
        # get users preference
        self._get_settings()
        # sort methods
        sortmethods = ( xbmcplugin.SORT_METHOD_LABEL, )
        # helper functions
        self.MediaWindow = MediaWindow( int( sys.argv[ 1 ] ), category=self.PluginCategory, content="tvshows", sortmethods=sortmethods, fanart=( self.settings[ "fanart_image" ], self.Fanart, ) )
        # fetch videos
        #self.MediaWindow.end( self.get_mainlisting() )
        import xbmcplugin_mako as plugin
        self.MediaWindow.end( plugin.List(name, url) )

    def _get_settings( self ):
        self.settings = {}
        self.PluginCategory = 'VOD' 
        self.settings[ "fanart_image" ] = ''
        self.Fanart = ''

    def get_mainSource(self, title, link, icon):
        RESOURCES_PATH = xbmc.translatePath( os.path.join( os.getcwd(), 'resources', 'media' ) )
        dirItem = DirectoryItem()
        dirItem.totalItems = 25
        dirItem.url = link
        dirItem.title = title
        
        try:
            icon = xbmc.translatePath( os.path.join( RESOURCES_PATH, icon ) )
        except:
            icon = 'DefaultFolder.png'
        dirItem.listitem = xbmcgui.ListItem( title, iconImage=icon, thumbnailImage=icon )
        dirItem.listitem.setInfo( "tvshow", { "Title": title } )
        dirItem.isFolder = True
        return dirItem
               
    def get_mainlisting(self):
        import xbmcplugin_mako as plugin
        plugin.Main('MAKO.CO.IL', 'http://www.mako.co.il/mako-vod-keshet')        
        #self.MediaWindow.add(self.get_mainSource('MAKO.CO.IL','http://www.mako.co.il/mako-vod-keshet', 'mako.jpg'))
        #self.MediaWindow.add(self.get_mainSource('NANA10','http://10tv.nana10.co.il/Category/?CategoryID=400008', 'nana10.jpg'))
        #self.MediaWindow.add(self.get_mainSource('SPORT 5 LIVE','http://sport5.co.il/', 'sport5.gif'))

        return True
