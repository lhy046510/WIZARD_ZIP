THIS IS NOT PART OF XB-ISRAEL PROJECT AND I'M NOT THE AUTHOR OF THIS ADDON.
it's apdated version of xbmako from http://code.google.com/p/xbmako/.
it's fine for GPL projects and that version released under same license.