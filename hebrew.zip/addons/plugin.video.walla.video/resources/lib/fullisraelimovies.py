import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time,sys
import plugin_helper

class FullisraelimoviesManager:
  
  def __init__(self):
    self.MODES=plugin_helper.enum(GET_MOVIES_LIST=1,PLAY=2)
  
  def work(self,mode,url='',name=''):
    if(mode==self.MODES.GET_MOVIES_LIST):
      self.getMoviesList(url,name)
    elif(mode==self.MODES.PLAY):
      plugin_helper.playRtmpFromUrl(url)
      
  def getMoviesList(self,url,name):
    print ("I'm look for israeli movies...")
    matches = plugin_helper.getMatches("http://video.walla.co.il/?w=/2223",'<a class="block oflow bg8" style="font\-size:1" href="(.*?\?w=//\d+)"><img class="vmedia141x188 medhvr01" src="(.*?)" alt="(.*?)" />')
    for href,img,name in matches:
      if (not href.startswith("http")):
        href = "http://video.walla.co.il/"+href
      plugin_helper.addVideo('Fullisraelimovies',name,'',href,2,{ "Title": urllib.unquote(name)},img)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    