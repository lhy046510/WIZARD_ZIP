import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time,sys
import plugin_helper

class JuniorManager:
  seriesRegex = """<a id="opc_\d" class="opc" href="(/\?w=//\d+)" onmouseover="makeHovin\('\d'\);" onmouseout="makeHovout\('\d'\);">
							<span id="hov\d" class="nav_over"></span>
							<span id="hov_text\d" class="nav_text w3b">(.*?)</span>
							<img id="im\d" src="(.*?)" class="nav_image zoom1"  alt=".*?" title="" />""".replace("\n","").replace("\t","").replace("\r","")
  
  
  
  smallImgPat="""<img class="imgdiv141" src="(.*?)"  alt=".*?" /><span class="block relative zoom1"><img class="absolute" style="left:4px;bottom:4px;" src="http://iscWBE\.walla\.co\.il/w9/v/vod/play_btn_small\.gif"></span>
		  </a>
		</div>
			<div style="margin-top:8px;">

				<div class="title w3b"><a href="(\?w=//\d+)" >(.*?)</a></div>
				<div class="hsubtitle oflow w2"><a href="\?w=//\d+" >(.*?)</a></div>
""".replace("\n","").replace("\t","").replace("\r","")
  
  bigImgPat = '"imgdiv301 imgcls" .*? src="(.*?)".*?<div class="title w5b mt5"><a href="(.*?)" >(.*?)</a></div><div class="hsubtitle oflow w3 mb5">(.*?)</div>'
  
  def __init__(self):
    self.MODES=plugin_helper.enum(GET_SERIES_LIST=1,GET_EPISODES_LIST=2,PLAY=3)
  
  def work(self,mode,url='',name=''):
    if (mode==self.MODES.GET_SERIES_LIST):
      self.getSeriesList()
    elif(mode==self.MODES.GET_EPISODES_LIST):
      self.getEpisodeList(url,name)
    elif(mode==self.MODES.PLAY):
      plugin_helper.playRtmpFromUrl(url)
      
  def getSeriesList(self):
    matches = plugin_helper.getMatches("http://junior.walla.co.il/",self.seriesRegex,True)
    for url,name,img in matches:
      plugin_helper.addDir('Junior',name,url,2,{"Title": urllib.unquote(name)},img)
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    
  def getEpisodeList(self,url,name):
    
    url = "http://junior.walla.co.il" + url
      
    fullEpisodesUrl = plugin_helper.getMatches(url,'<a href="(\?w=//\d+)" class="in_blk channel " onclick="Evt\(this,\d,&quot;\xf4\xf8\xf7\xe9\xed \xee\xec\xe0\xe9\xed&quot;',True)
    if len(fullEpisodesUrl)>0 and not url.endswith(fullEpisodesUrl[0]):
      url = "http://junior.walla.co.il/"+fullEpisodesUrl[0]
          
    matches = self.getMoreFromAjax(url)
    
    for pic,href,title,subtitle in matches:
      plugin_helper.addVideo('Nickoldeon',name,subtitle,'http://nick.walla.co.il/'+href,3,{ "Title": urllib.unquote(title),"Tagline":urllib.unquote(subtitle)},pic)
      
    
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    
    for x in range(1,29):
      xbmcplugin.addSortMethod(int(sys.argv[1]),x)


  
  def getMoreFromAjax(self,url):
    match=[]
    length = 1
    i=1
    url = url + '&page='
    while (length>0 and i<=10):
      print(url+str(i))
      news = plugin_helper.getMatches(url+str(i),self.bigImgPat,True)
      news += plugin_helper.getMatches(url+str(i),self.smallImgPat,True)
      length=len(news)
      print(length)
      match+=news
      i+=1
    return match
    