import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time,sys
import plugin_helper

class YesdocuManager:
  
  def __init__(self):
    self.MODES=plugin_helper.enum(GET_MCATEGORIES_LIST=1,GET_SCATEGORIES_LIST=2)
  
  def work(self,mode,url='',name=''):
    if (mode==self.MODES.GET_MCATEGORIES_LIST):
      self.getCategories()
    elif (mode==self.MODES.GET_SCATEGORIES_LIST):
      self.getSCategories(url)
    elif(mode==3):
      self.getMoviesList(url)
    elif(mode==10):
      self.getEpisodesList(url)
    elif(mode==5):
      plugin_helper.playRtmpFromUrl(url)
      
  def getCategories(self):
    matches = plugin_helper.getMatches("http://yes.walla.co.il/?w=2/7800","text-decoration:none;display:block;padding-right:10px;font-size:15px;font-weight:bold;color:ffffff;width:153px;\" href=\"(http://yes\.walla\.co\.il/\?w=2/\d+)\" >(.*?)</a>")
    for url,name in matches:
      plugin_helper.addDir('Yesdocu',name,url,2,{"Title": urllib.unquote(name),"Genre":"Documentary"})
    
  def getSCategories(self,url):
    if "http://yes.walla.co.il/?w=2/7803"==url: #SERIES
      self.getSeriesList(url)
      return
    if "http://yes.walla.co.il/?w=2/8605"==url: #DOCU CHAL
      self.getDocuChalCats(url)
      return
    
    matches = plugin_helper.getMatches(url,"<div class=\"wp-0-bh-bg2 wp-0-bh w2b\"><a href=\"/\?w=2/(\d+)\">(.*?)</a></div>")
    if (len(matches)<2):
      self.getMoviesList(url)
      return
    for url,name in matches:
      plugin_helper.addDir('Yesdocu',name,"http://yes.walla.co.il/?w=2/"+url,3,{"Title": urllib.unquote(name),"Genre":"Documentary"})
    
  def getMoviesList(self,url):
    matches = plugin_helper.getMatches(url,"\"padding:8 0 7 6; \" valign=\"top\"><a href=\"(.*?)\" class=\"w2b\">(.*?)</a><br>(.*?)</td>\n<td valign=\"top\" style=\"padding:7 6 7 6; width:97px;\">  <table cellpadding=0 cellspacing=0 class=\"wtable wbgpos\" background=\"(.*?)")
    for url,name,tagline,img in matches:
      plugin_helper.addVideo('Yesdocu',name,tagline,"http://yes.walla.co.il/"+url,5,{"Title": urllib.unquote(name),"Genre":"Documentary","Tagline":tagline},img,img)
      

  def getSeriesList(self,url):
    matches = plugin_helper.getMatches(url,"\"padding:8 0 7 6; \" valign=\"top\"><a href=\"http://yes\.walla\.co\.il/\?w=2/(\d+)\" class=\"w2b\">(.*?)</a><br>(.*?)</td>\r\n<td valign=\"top\" style=\"padding:7 6 7 6; width:97px;\">  <table cellpadding=0 cellspacing=0 class=\"wtable wbgpos\" background=\"(.*?)")
    for url,name,tagline,img in matches:
      plugin_helper.addDir('Yesdocu',name,str(int(url)+1),10,{"Title": urllib.unquote(name),"Genre":"Documentary","Tagline":tagline},img)
    
    
  def getEpisodesList(self,url):
    url = 'http://yes.walla.co.il/?w=2/'+url
    
    matches  = plugin_helper.getMatches(url,"\"padding:8 0 7 6; \" valign=\"top\"><a href=\"(.*?)\" class=\"w2b\">(.*?)</a><br>(.*?)</td>\n<td valign=\"top\" style=\"padding:7 6 7 6; width:97px;\">  <table cellpadding=0 cellspacing=0 class=\"wtable wbgpos\" background=\"(.*?)")
    for href,name,plot,img in matches:
      plugin_helper.addVideo('Yesdocu',name,'',"http://yes.walla.co.il"+href,5,{"Title": urllib.unquote(name),"Genre":"Documentary","Plot":plot},img,img)
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    

  def getDocuChalCats(self,url):
    print(url)
    matches = plugin_helper.getMatches(url,'color:AAD841;width:153px;" href="(http://yes\.walla\.co\.il/\?w=2/\d+)" >(.*?)</a>')
    for url,name in matches:
      plugin_helper.addDir('Yesdocu',name,url,2,{"Title": urllib.unquote(name),"Genre":"Documentary"})