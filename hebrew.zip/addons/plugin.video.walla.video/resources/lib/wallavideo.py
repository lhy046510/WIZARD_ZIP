import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time,sys
import plugin_helper

class WallavideoManager:
  
  def __init__(self):
    self.MODES=plugin_helper.enum(GET_SERIES_LIST=1,GET_EPISODES_LIST=2,PLAY=3)
  
  def work(self,mode,url='',name=''):
    if (mode==self.MODES.GET_SERIES_LIST):
      self.getSeriesList()
    elif(mode==self.MODES.GET_EPISODES_LIST):
      self.getEpisodeList(url,name)
    elif(mode==self.MODES.PLAY):
      plugin_helper.playRtmpFromUrl(url)
      
  def getSeriesList(self):
    matches = plugin_helper.getMatches("http://video.walla.co.il/",'<a class="fclr2" href="(http://video.walla.co.il/.*?)">(.*?)</a>')
    for url,name in matches:
      imgPath = plugin_helper.getPath('cache','headers','wallavideo',name+".png")
      if not os.path.exists(imgPath):
        imgPath = "DefaultFolder.png"
      plugin_helper.addDir('Wallavideo',name,url,2,{"Title": urllib.unquote(name)},imgPath)
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    
  def getEpisodeList(self,url,name):
    imgPath = plugin_helper.getPath('cache','headers','wallavideo',name+".png")
    if (not os.path.exists(imgPath) or (time.time()-os.path.getmtime(imgPath))/60/60/24 > 7):
      headerPath = plugin_helper.getMatches(url,'<img class="vbox720x330" src="(.*?)"')[0]
      urllib.urlretrieve(headerPath,imgPath)
    matches = self.getFromAjax(url)
    for url,img,title in matches:
      plugin_helper.addVideo('Wallavideo',title,'','http://video.walla.co.il/?w=//'+url,3,{'Title':title},img)
  
  def getFromAjax(self,url):
    match=[]
    length = 1
    i=0
    url = url + '&page='
    while (length>0 and i<=10):
      pat='location\.href=&quot;\?w=//(\d+)&quot;"><span class="block relative zoom1"><img class="absolute zoomImg" style="top:30px;left:68px;" src="http://iscWBE.walla.co.il/w9/v/vod/PLAYBTN_white.gif" alt="" /></span><img class="vmedia141x78 medhvr01" src="(.*?)" alt="(.*?)" />'
      news = plugin_helper.getMatches(url+str(i),pat)
      length=len(news)
      match+=news
      i+=1
    return match
