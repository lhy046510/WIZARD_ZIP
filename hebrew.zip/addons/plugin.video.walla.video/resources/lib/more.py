import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time,sys
import plugin_helper

class MoreManager:
  
  def __init__(self):
    self.MODES=plugin_helper.enum(GET_CHANNELS_LIST=1,GET_SERIES_LIST=2,GET_EPISODES_LIST=3,PLAY=4)
  
  def work(self,mode,url='',name=''):
    if (mode==self.MODES.GET_CHANNELS_LIST):
      self.getChannelsList()
    elif (mode==self.MODES.GET_SERIES_LIST):
      self.getSeriesList(url)
    elif(mode==self.MODES.GET_EPISODES_LIST):
      self.getEpisodeList(url,name)
    elif(mode==self.MODES.PLAY):
      plugin_helper.playRtmpFromUrl(url)
  
  def getChannelsList(self):
    #channels = plugin_helper.getMatches('http://video.walla.co.il/','<div class="menuItemDiv itemsBottomBorder"><a href="(http://video\.walla\.co\.il/\?w=/\d+)" ><img src="(http://mscWBE\.walla\.co\.il/archive/\d+-35\.gif)"')
    channels = [('http://video.walla.co.il/?w=/2160', 'http://mscWBE.walla.co.il/archive/809399-35.gif','23'), ('http://video.walla.co.il/?w=/2161', 'http://mscWBE.walla.co.il/archive/819342-35.gif','ערוץ ההיסטוריה'), ('http://video.walla.co.il/?w=/2162', 'http://mscWBE.walla.co.il/archive/819333-35.gif','ערוץ הביוגרפיה'), ('http://video.walla.co.il/?w=/2164', 'http://mscWBE.walla.co.il/archive/819340-35.gif','ערוץ האוכל'), ('http://video.walla.co.il/?w=/2166', 'http://mscWBE.walla.co.il/archive/819344-35.gif','ערוץ הבריאות'), ('http://video.walla.co.il/?w=/2165', 'http://mscWBE.walla.co.il/archive/819664-35.gif','ערוץ הטיולים'),('http://video.walla.co.il/?w=/2164','http://mscwbe.walla.co.il/archive/819340-5.gif','ערוץ האוכל')]
    for url,img,name in channels:
      plugin_helper.addDir('More',name,url,2,{"Title": urllib.unquote(name)},img)
          
  def getSeriesList(self,url):
    series = plugin_helper.getMatches(url,'<a href="(http://video\.walla\.co\.il/\?w=//\d+)"><img src="(http://mscWBE\.walla\.co\.il/archive/\d+-\d+\.jpg)" alt="(.*?)" title=".*?" class="rightMenuItemImg" />')
    for url,img,name in series:
      plugin_helper.addDir('More',name,url,3,{"Title": urllib.unquote(name)},img)
    
    
  def getEpisodeList(self,url,name):
    series = plugin_helper.getMatches(url,'w=//(\d+)&quot;"><span class="block relative zoom1"><img class="absolute zoomImg" style="top:30px;left:68px;" src="http://iscWBE\.walla\.co\.il/w9/v/vod/PLAYBTN_white\.gif" alt="" /></span><img class="vmedia141x78 medhvr01" src="(.*?)" alt="(.*?)" />')
    for url,img,name in series:
      plugin_helper.addVideo('More',name,'','http://video.walla.co.il/?w=//'+url,4,{ "Title": urllib.unquote(name)},img)
