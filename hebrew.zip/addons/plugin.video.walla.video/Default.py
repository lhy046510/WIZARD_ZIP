# -*- coding: utf-8 -*-

import urllib,urllib2,re,xbmcplugin,xbmcgui,os

##General vars
__author__ = "Shmulik"

LIB_PATH = xbmc.translatePath( os.path.join( os.getcwd(), 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

from plugin_helper import *



manager=None

def getChannelsList():
  channelList=['Nickoldeon','Yes','Fullmovies','Yesdocu','Fullisraelimovies','Wallavideo','Viva','Kofiko','Junior','More']
  for channel in channelList:
    addDir('',channel,channel,1,{'Title':channel})
 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
if (mode==None):
  getChannelsList()
elif (mode==1):
  manager = getattr(__import__(name.lower()),name+'Manager')()
  manager.work(mode)
else:
  manager = getattr(__import__(module.lower()),module+'Manager')()
  manager.work(mode,url,name)
  
xbmcplugin.endOfDirectory(int(sys.argv[1]))