# -*- coding: utf-8 -*-

import urllib,urllib2,re,xbmcplugin,xbmcgui,os,xbmcaddon

##General vars
__plugin__ = "23TV"
__author__ = "Shmulik"
__credits__ = ""
__version__ = "0.0.1"
__XBMC_Revision__ = ""

__usecache__ = xbmcaddon.Addon( id=os.path.basename( os.getcwd() ) ).getSetting("usecache")

def getFromCache(url,type):
  if __usecache__!="true":
    return False;
  url = url.replace('.', ''). replace('/','').replace(':','').replace('?','').replace('-','')
  filePath = xbmc.translatePath( os.path.join( os.getcwd(), 'cache',type,url) )
  if (os.path.exists(filePath)):
    return  file(filePath,'r').read()
  return False;

def saveToCache(pre,final,type):
  if __usecache__!="true":
    return False;
  pre = pre.replace('.', ''). replace('/','').replace(':','').replace('?','').replace('-','')
  filePath = xbmc.translatePath( os.path.join( os.getcwd(), 'cache',type,pre) )
  fileCache = file(filePath,'w')
  fileCache.write(final)
  fileCache.close()
  return True;
    


def CATEGORIES():
  matches = getMatches('http://www.tvland.co.il/channel.asp?id=7','<a class=txt10Red href=\'cat.asp\?id=\d+\'>(.*?)</div>.*?<img src=(.*?) border=0 width=105 height=41></td></tr><tr><td align=center height=34></td></tr></table><a class=txtBlackBig href=\'(.*?)\'>(.*?)</a>')
  for genre,img,href,title in matches:
    addDir(title,"http://www.tvland.co.il/"+href,2,img,genre)
  xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

def getMatches(url,pattern):
  req = urllib2.Request(url)
  req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
  response = urllib2.urlopen(req)
  data=response.read()
  response.close()
  matches=re.compile(pattern).findall(data)
  return matches


def VIDEOLINKS(url,name):
  matches = getMatches(url,"EpisodeTitle href='(.*?)'>(.*?)</a><br>(.*?)</div>")
  for id,title,plot in matches:
    addLink(title,"http://www.tvland.co.il/"+id,plot)
  xbmcplugin.setContent(int(sys.argv[1]), 'episodes')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def getMmsAddress(url):
	print "DBG: getMmsAddress("+url+");"
	cache = getFromCache(url,'mms')
	if cache!=False:
		return cache;
	link = getMatches(url,'<a target="new" href="(.*?)"')[0]
	link =  getMatches(link,'<img src="(.*?)&th=1"')[0].replace("gmpl.aspx","gm.asp")+"&ak=null&cuud=&curettype=1&cucontentlinktype=1"
	req = urllib2.Request(link)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	data=response.read()
	response.close()
	saveToCache(url,data,'mms')
	return data



def addLink(name,url,plot):
        ok=True
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode=3&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":plot } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage,genre):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Genre":genre} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        INDEX(url)
        
elif mode==2:
        VIDEOLINKS(url,name)
elif mode==3:
        xbmc.Player().play(getMmsAddress(url))



xbmcplugin.endOfDirectory(int(sys.argv[1]))

