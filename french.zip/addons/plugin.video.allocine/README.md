plugin.video.allocine
====================

Plugin allociné pour XBMC.

Contenu :
- Émissions TV - Retrouver l'intégralité des émissions d'Allociné.
- Bandes Annonces - Bandes annonces des films en salle ou à venir.
- Séries - Bandes annonces et extraits d'épisode de série.
- Interviews - Interviews de star.
- Horaires en salles - Liste des séances de cinéma pour les films en salle.
