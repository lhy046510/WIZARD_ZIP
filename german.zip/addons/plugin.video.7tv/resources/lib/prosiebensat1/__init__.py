from client import Client
from provider import Provider, try_set_season_and_episode