gameone.de on XBMC
==================

Watch your favourite gaming show on XBMC.

Contributors
----------------

Thanks to everyone who contributed to this project:

membrane, fluse

...and everyone I forgot!
