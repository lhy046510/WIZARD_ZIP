============================

plugin.video.theanimehighway

============================


A Video Plugin made in Python for use with XBMC.


============================

What is This?: A 3rd Party Video-Plugin for the program XBMC.

Written Language: English

Code Language: Python

Main OS: Windows7 (x64)

Other OS: May work with XBMC on several other OS's, but I do not currently have a way to test on others.

Original Project Author: TheHighway (aka HIGHWAY99)

Current Project Crew: TheHighway (Project Leader)

Special thanks and credit given to:

                              o9r1sh (plugin.video.gogoanime) - who's source helped me near the beginning.
                              voinage (xbmchub forum) - for helpful meantion, to prevent future problems.
                              Bstrdsmkr (plugin.video.1channel) - one of my favorite xbmc addons.
                              TwiztedZero (voiced user on IRC) - more people should join us on IRC Chat.
                              
                              
                              
                              
============================

This project is being done as a Learning Experience, to study and better my skills.

============================
