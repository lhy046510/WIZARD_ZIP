import os
import xbmc

try:
	from sqlite3 import dbapi2 as database
	print 'Loading sqlite3 as DB engine version: %s' % database.sqlite_version
except:
	from pysqlite2 import dbapi2 as database
	print 'pysqlite2 as DB engine'

class DB:

	def __init__(self):
		self.succes = False
		try:
			self.videocache = os.path.join(xbmc.translatePath("special://database"), '990dotrocache.db')
			self.dbcon = database.connect(self.videocache)
			self.dbcon.row_factory = database.Row
			self.dbcur = self.dbcon.cursor()
			self.create_tables()
			self.succes = True
		except: pass
	
	
	def create_tables(self):
		self.dbcon.execute('CREATE TABLE IF NOT EXISTS movies (title TEXT, overlay INTEGER, UNIQUE(title))')
		self.dbcon.execute('CREATE INDEX IF NOT EXISTS nameindex on movies (title)')
		self.dbcon.execute('CREATE TABLE IF NOT EXISTS tvshows (title TEXT, overlay INTEGER, UNIQUE(title))')
		self.dbcon.execute('CREATE INDEX IF NOT EXISTS nameindex on tvshows (title)')
		self.dbcon.execute('CREATE TABLE IF NOT EXISTS seasons (tvshow TEXT, season INTEGER, overlay INTEGER)')
		self.dbcon.execute('CREATE TABLE IF NOT EXISTS episodes (tvshow TEXT, season INTEGER, episode TEXT, overlay INTEGER)')		
		self.dbcon.execute('CREATE TABLE IF NOT EXISTS bookmarks (video_type, title, season, episode, bookmark)')
		self.dbcon.execute('CREATE UNIQUE INDEX IF NOT EXISTS unique_bmk ON bookmarks (video_type, title, season, episode)')
		self.dbcon.commit()
		
		print 'All tables have been successfully loaded.'
	
	
	def change_watched(self, video_type, title, season='', episode='', overlay=7):
		try:
			if video_type == 'tvshow':
			
				sql = 'INSERT OR REPLACE INTO tvshows (title, overlay) VALUES (?,?)'
				self.dbcur.execute(sql, (unicode(title, 'utf-8'), overlay))
			
				sql = 'INSERT OR REPLACE INTO seasons (tvshow, season, overlay) VALUES (?,?,?)'
				self.dbcur.execute(sql, (unicode(title, 'utf-8'), int(season), overlay))
			
				sql = 'INSERT OR REPLACE INTO episodes (tvshow, season, episode, overlay) VALUES (?,?,?,?)'
				self.dbcur.execute(sql, (unicode(title, 'utf-8'), int(season), episode, overlay))

				self.dbcon.commit()
				
			elif video_type == 'movie':
				sql = 'INSERT OR REPLACE INTO movies (title, overlay) VALUES (?,?)'
				self.dbcur.execute(sql, (unicode(title, 'utf-8'), overlay))
				self.dbcon.commit()

		except: pass
	
	
	def check_watched(self, table, title, season='', episode=''):
		try:
			matchrow = ''
			
			if table == 'episodes':
				sql = 'SELECT * FROM episodes WHERE tvshow=? AND season=? AND episode=?'
				self.dbcur.execute(sql, (unicode(title, 'utf-8'), int(season), episode))
				matchrow = self.dbcur.fetchone()
			
			elif table == 'seasons':
				sql = 'SELECT * FROM seasons WHERE tvshow=? AND season=?'
				self.dbcur.execute(sql, (unicode(title, 'utf-8'), int(season)))
				matchrow = self.dbcur.fetchone()
			
			else:
				sql = 'SELECT * FROM %s WHERE title=?' % table
				self.dbcur.execute(sql, (unicode(title, 'utf-8'),))
				matchrow = self.dbcur.fetchone()
			
			if matchrow: return dict(matchrow)
			else: return False
		
		except: return False
	
	
	def __del__(self):
		try:
			self.dbcur.close()
			self.dbcon.close()
		except: pass
		