script.module.requests2
=======================

Python requests library packed for XBMC.
Due to API changes between v1.x and v2.x, and to avoid problem with addons
already using script.module.requests, the module requests2 was created.

People using script.module.requests should upgrade to script.module.request2.

See https://github.com/kennethreitz/requests
