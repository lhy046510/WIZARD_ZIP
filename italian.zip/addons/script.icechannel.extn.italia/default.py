# default.py
addon_id="script.icechannel.extn.italia"
addon_name="xunitytalk extension for italia"
