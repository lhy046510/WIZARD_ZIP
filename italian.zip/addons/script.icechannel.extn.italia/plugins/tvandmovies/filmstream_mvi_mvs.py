'''
    filmstream  # thanks to to shani for the decrypter.py
    Copyright (C) 2013 Coolwave
'''

from entertainment.plugnplay.interfaces import MovieIndexer
from entertainment.plugnplay.interfaces import MovieSource
#from entertainment.plugnplay.interfaces import CustomSettings
from entertainment.plugnplay import Plugin
from entertainment import common
import os
from entertainment.xgoogle.search import GoogleSearch
import xbmc
import xbmcgui


class filmstream(MovieIndexer,MovieSource):
    implements = [MovieIndexer,MovieSource]
    
    name = "filmstream (Italia)"
    display_name = "Filmstream (Italia)"
    base_url = 'http://filmstream.info/'
    #img='https://raw.githubusercontent.com/Coolwavexunitytalk/images/92bed8a40419803f31f90e2268956db50d306997/flixanity.png'
    default_indexer_enabled = 'false'
    source_enabled_by_default = 'false'
    #cookie_file = os.path.join(common.cookies_path, 'NRlogin.cookie')
    icon = common.notify_icon
    
    '''
    def __init__(self):
        xml = '<settings>\n'
        xml += '<category label="Account">\n'
        xml += '<setting id="tv_user" type="text" label="Email" default="Enter your noobroom email" />\n'
        xml += '<setting id="tv_pwd" type="text" option="hidden" label="Password" default="xunity" />'
        xml += '<setting label="Premium account will allow for 1080 movies and the TV Shows section" type="lsep" />\n'
        xml += '<setting id="premium" type="bool" label="Enable Premium account" default="false" />\n'
        xml += '</category>\n' 
        xml += '</settings>\n'
        self.CreateSettings(self.name, self.display_name, xml)
    '''

    def ExtractContentAndAddtoList(self, indexer, section, url, type, list, page='', total_pages='', sort_by='', sort_order=''): 
        if section == 'al-cinema':
            new_url = url
            if page == '':
                page = '1'
            else:
                page = str( int(page) )
                new_url = new_url + 'page/' + page
                print new_url
            
            from entertainment.net import Net
            import re
            net = Net(cached=False)
            import urllib
            
            html = net.http_GET(new_url).content
            if total_pages == '':
                r= '<a class="last" href="http://filmstream.info/al-cinema/page/(.+?)/">'
                total_pages = re.compile(r).findall(html)[0]
                
            self.AddInfo(list, indexer, 'al-cinema', url, type, str(page), total_pages)

            for item in re.finditer(r'<h2> <a href="(.+?)">(.+?)</a> </h2>\s*<div class=".+?">.+?</div>\s*</div>\s*<a href=".+?" title="">\s*<img src="(.+?)" alt="(.+?)"',html,re.I):
                url=item.group(1)
                name=item.group(4)
                name=name.split('Stream')[0]
                image=item.group(3)
                name = self.CleanTextForSearch(name)
                self.AddContent(list,indexer,common.mode_File_Hosts,name,'',type, url=url, name=name, img=image, plot='')
                

          
        else:
            
            new_url = url
            if page == '':
                page = '1'
            else:
                page = str( int(page) )
                new_url = new_url + 'page/' + page
                print new_url
            
            from entertainment.net import Net
            import re
            net = Net(cached=False)
            import urllib
            
            html = net.http_GET(new_url).content
            if total_pages == '':
                r= '<a class="last" href="http://filmstream.info/.+?/page/(.+?)/">'
                total_pages = re.compile(r).findall(html)[0]
                
            self.AddInfo(list, indexer, 'al-cinema', url, type, str(page), total_pages)

            for item in re.finditer(r'<h2> <a href="(.+?)">(.+?)</a> </h2>\s*<div class=".+?">.+?</div>\s*</div>\s*<a href=".+?" title="">\s*<img src="(.+?)" alt="(.+?)"',html,re.I):
                url=item.group(1)
                name=item.group(4)
                name=name.split('Stream')[0]
                image=item.group(3)
                name = self.CleanTextForSearch(name)
                self.AddContent(list,indexer,common.mode_File_Hosts,name,'',type, url=url, name=name, img=image, plot='') 

                    
       
    
    def GetSection(self, indexer, section, url, type, list, page='', total_pages='', sort_by='', sort_order=''):
        
        from entertainment.net import Net
        import re
        
        net = Net()

        url_type = ''
        content_type = ''
        
        if indexer == common.indxr_Movies:#'[COLOR orange]'+year+'[/COLOR]'

            if section == 'main':
                self.AddSection(list, indexer,'al-cinema','Al-Cinema',self.base_url +'al-cinema/',indexer)
                self.AddSection(list, indexer,'piu-visti','Piu-Visti',self.base_url +'piu-visti/',indexer)
                self.AddSection(list, indexer,'sub-ita','Sub-Ita',self.base_url +'film/sub-ita/',indexer)
                self.AddSection(list, indexer,'anno','Anno','http://filmstream.info/news/',indexer)
                self.AddSection(list, indexer,'genre','Genere','http://filmstream.info/news/',indexer)
                #self.AddSection(list, indexer,'popular','Popular',self.base_url +'movies/favorites/',indexer)         
                           
            elif section == 'genre':
                r = re.findall(r'<li><a href="(http://filmstream.info/film/.+?)">(.+?)</a></li>', net.http_GET(url).content, re.I)
                for genres_url,genres in r[0:]:
                    genres_title = genres.upper()
                    self.AddSection(list, indexer, 'genres_title', genres_title, genres_url, indexer)

            elif section == 'anno':
                r = re.findall(r'<li><a href="(http://filminstreaming.eu/anno/.+?)">(.+?)</a></li>', net.http_GET(url).content, re.I)
                for anno_url,anno in r[0:]:
                    anno_title = anno.upper()
                    self.AddSection(list, indexer, 'anno_title', anno_title, anno_url, indexer)
                
                

            else:
                self.ExtractContentAndAddtoList(indexer, section, url, type, list, page, total_pages, sort_by, sort_order)

            
    
    def GetFileHosts(self, url, list, lock, message_queue):

        import re
        from entertainment.net import Net
        net = Net()
                  
        self.AddFileHost(list, 'NA', url)
        
        
        
                
    def GetFileHostsForContent(self, title, name, year, season, episode, type, list, lock, message_queue):                 
        
        from entertainment.net import Net
        import re
        net = Net(cached=False)
        name = self.CleanTextForSearch(name)
        import urllib
        name = name.lower()
        
        main_url='http://filmstream.info/index.php/?s=%s' %(name.replace(' ','+'))
        
        if type == 'movies':
            html = net.http_GET(main_url).content
            item_url=re.compile('<h2> <a href="(.+?)">.+?</a> </h2>').findall(html)[0]
            print item_url
            print '#item_url##########################################'
            self.GetFileHosts(item_url, list, lock, message_queue)
            
    def Search(self, indexer, keywords, type, list, lock, message_queue, page='', total_pages=''): 
        
        if page and len(page) > 0 and total_pages and len(total_pages) > 0 and int(page) > int(total_pages):
            return
        
        if page=='': page='1'
        
        from entertainment.net import Net
        net = Net()
        search_url ='%spage/%s/?s=%s' %(self.base_url, page, keywords.replace(' ','+'))
        print search_url
        import re
        
        html = net.http_GET(search_url).content
        if total_pages == '':
            r= '<a class="last" href="http://filmstream.info/page/(.+?)/'
            try:
                total_pages = re.compile(r).findall(html)[0]
            except:
                total_pages = '1'
            
                
        self.AddInfo(list, indexer, 'search', self.base_url, type, str(page), total_pages)

        for item in re.finditer(r'<h2> <a href="(.+?)">(.+?)</a> </h2>\s*<div class=".+?">.+?</div>\s*</div>\s*<a href=".+?" title="">\s*<img src="(.+?)" alt="(.+?)"',html,re.I):
            url=item.group(1)
            name=item.group(4)
            name=name.split('Stream')[0]
            image=item.group(3)
            name = self.CleanTextForSearch(name)
            self.AddContent(list,indexer,common.mode_File_Hosts,name,'',type, url=url, name=name, img=image, plot='') 
        

    def Resolve(self, url):
        
        import decrypter
        from entertainment.net import Net
        import re
        net = Net(cached=False)
        headers={'Host':'r20---googlevideo.com', 'Referer': url , 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36'}
        html = net.http_GET(url).content
        if '<div id="embedHolder" style="display:none;"><iframe src="' in html:
            print url
            item_url=re.compile('<div id="embedHolder" style="display:none;"><iframe src="(.+?)"').findall(html)[0]
            headers={'Host':'r20---googlevideo.com', 'Referer': url , 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36'}
            print item_url
            content = net.http_GET(item_url,headers).content
            print content
            new_url = re.search("[\"']{1}file[\"']{1}\:[\"']{1}(.+?)[\"']{1}", content)
            if new_url:
                new_url = new_url.group(1).replace("\/", "/")
                #print new_url
                headers.update({'Referer':item_url, 'Accept':'*/*', 'Accept-Encoding':'identity;q=1, *;q=0', 'Range':'bytes=0-'})
                import urllib2
                try:
                    new_content =  net.http_GET(new_url,headers,auto_read_response=False)
                    play_url = new_content.get_url()
                except urllib2.HTTPError, error:
                    play_url = error.geturl()
                
                return play_url        
            
        else:
            url = re.compile('FlashVars="config=http://filmstream.info/config.xml.+?proxy.link=filmstream\*(.+?)&.+?"').findall(html)[0]
            url = decrypter.decrypter(198,128).decrypt(url,'OdrtKapH2dNRpVHxhBtg','ECB').split('\0')[0]
            print url
        
            result = net.http_GET(url).content

            res_name = []
            res_url = []

            r = re.findall('\,(\d+\,\d+)\,\"(http://redirector.googlevideo.com/videoplayback?.*?)\"',result)
            #print result
            #print r
            #print movie_id
            for quality, url in r:
                if '1920' in quality:
                    quality = '1080P'
                elif '1280' in quality:
                    quality = '720P'
                elif '852' in quality:
                    quality = 'SD'
                else:
                    quality ='LOW QUALITY'
                res_name.append(quality)                
                res_url.append(url)

            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Stream Quality.',res_name)

            if ret == 0:
                return None

            elif ret >1:
                print res_url[ret]
                return res_url[ret].replace('\u003d','=').replace('\u0026','&')
            

            


        
