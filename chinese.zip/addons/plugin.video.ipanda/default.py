﻿# -*- coding: utf-8 -*-
from xbmcswift2 import Plugin, CLI_MODE, xbmcaddon,ListItem
import xbmcgui
import urllib2, urllib, re, string, sys, os, gzip, StringIO, json
from urlparse import parse_qsl

plugin = Plugin()
menu_items = []

SITE_LIST = [["精选直播","http://hdstime.cntv.chinacache.net:8000/live/flv/channel54"],
             ["成年园1","http://flv.cntv.wscdns.com/live/flv/channel89.flv"],
             ["成年园2","http://flv.cntv.wscdns.com/live/flv/channel90.flv"],
             ["幼年园1","http://flv.cntv.wscdns.com/live/flv/channel91.flv"],
             ["幼年园2","http://flv.cntv.wscdns.com/live/flv/channel92.flv"],
             ["幼儿园1","http://flv.cntv.wscdns.com/live/flv/channel93.flv"],
             ["幼儿园2","http://flv.cntv.wscdns.com/live/flv/channel94.flv"],
             ["母子园1","http://flv.cntv.wscdns.com/live/flv/channel95.flv"],
             ["母子园2","http://flv.cntv.wscdns.com/live/flv/channel96.flv"],
             ["1号别墅1","http://flv.cntv.wscdns.com/live/flv/channel97.flv"],
             ["1号别墅2","http://flv.cntv.wscdns.com/live/flv/channel98.flv"], 
             ]


@plugin.route('/')
def main_list():
    items = []
    for index in SITE_LIST:
        items.append({
        'label': index[0],
        'path': index[1],
        'is_playable': True,
    })
    return items
       
if __name__ == '__main__':
    plugin.run()