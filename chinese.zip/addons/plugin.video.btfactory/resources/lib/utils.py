#! /usr/bin/env python
# coding=utf-8
import urllib2
import json
from urllib import quote_plus, urlencode
from xbmcswift2 import xbmc
import gzip
try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO  # noqa
try:
    from ChineseKeyboard import Keyboard
except ImportError:
    Keyboard = xbmc.Keyboard  # noqa

PREV_PAGE_NAME = u'[COLOR FFFF0000]< 上一页[/COLOR]'
NEXT_PAGE_NAME = u'[COLOR FFFF0000]下一页 >[/COLOR]'

http_proxy = None


def fetch_url(url, data=None, headers={}, timeout=None, proxies=None):
    headers.setdefault(
        'User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.84 Safari/537.22')  # noqa
    headers.setdefault('Accept-Encoding', 'gzip,deflate')

    if data and isinstance(data, dict):
        data = urlencode(data)

    req = urllib2.Request(url, data, headers)

    if proxies or http_proxy:
        if not proxies:
            if isinstance(http_proxy, basestring):
                proxies = {'http': http_proxy, 'https': http_proxy}
            else:
                proxies = http_proxy
        proxy_handler = urllib2.ProxyHandler(proxies)
        opener = urllib2.build_opener(proxy_handler)
        r = opener.open(req, timeout=timeout)
    else:
        r = urllib2.urlopen(req, timeout=timeout)

    content = r.read()

    if r.headers.get('content-encoding') == 'gzip':
        content = gzip.GzipFile(fileobj=StringIO(
            content), mode='rb').read()

    return content


def create_playurl(pattern, **kwargs):
    name = kwargs.setdefault('name', '')
    if name:
        if isinstance(name, unicode):
            name = name.encode('utf-8')
        kwargs['name'] = quote_plus(name, '')

    return pattern.format(**kwargs)


def keyboard(default='', heading='', hidden=False):
    kb = Keyboard(default, heading)
    xbmc.sleep(1500)
    kb.doModal()
    if (kb.isConfirmed()):
        return kb.getText()


def get_btih_playurl(btih, name=''):  # noqa
    return create_playurl(
        'plugin://script.thunder.player/bt/{btih}/?name={name}',
        btih=btih, name=name)


def get_ed2k_playurl(ed2k_url, name=''):  # noqa
    return create_playurl(
        'plugin://script.thunder.player/ed2k/{ed2k_url}/?name={name}',
        ed2k_url=quote_plus(ed2k_url), name=name)


def run_plugin(plugin_url):
    xbmc.executebuiltin('RunPlugin(%s)' % plugin_url)


def refresh():
    xbmc.executebuiltin('Container.Refresh')


def get_bt_screenshot(btihlist):
    if isinstance(btihlist, str):
        btihlist = [btihlist]

    url = 'http://i.vod.xunlei.com/req_screenshot?req_list=' + \
        '/'.join(btihlist)
    print url
    html = fetch_url(url)
    print len(html)
    resp = json.loads(html)['resp']
    if not resp.get('ret') or not resp.get('screenshot_list'):
        return

    screenshots = {}
    for item in resp['screenshot_list']:
        btih = item.pop('gcid')
        if item:
            screenshots[btih] = item

    return screenshots
