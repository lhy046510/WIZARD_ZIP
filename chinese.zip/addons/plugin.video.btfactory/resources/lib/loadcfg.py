#! /usr/bin/env python
# coding=utf-8
'''
Required: LABEL, TOP_ENTRIES, HANDLERS
LABEL: 插件菜单显示名称
THUMBNAIL: 缩略图
CONSTANTS: dict，重复使用或者较长的字符串都可以放到这里，提供引用
TOP_ENTRIES: 顶层菜单项
HANDLERS: 所有handler，通过名称访问
FIRST_PAGE: 第一页索引值。默认为1。

entry: [dict, format] 菜单项，可以在yaml中定义，比如TOP_ENTRIES。可以在程序中
  根据handler生成。如果是字符串，则需要在 CONSTANTS中进行转义。
  label: [format，pop] 菜单项标题，不存在则使用name替代，返回结果列表
  name: [pop, list] 名称，可替代label。list则copy其他数据
  video_url: [playable] 可播放视频地址。basestring->直接播放，list->stack
  btih: [playable] get_btih_playurl(btih, label)
  handler: [dir] 没有video_url和btih的情况下必须提供。get_view_by_entry(entry)
      获取view。其余参数作为url参数传回（包括handler）。默认值default。

handler: [dict, list] 定义返回entries的动作。可以为dict和list。如果是list，则
    递归调用，然后合并entries。
  visible: E:exp 可计算表达式，判断是否计算该handler。默认为True。
      env中应包含firstpage。
  entries: [list, dict, format] 如果存在，则直接返回该值。如果是dict，则需先用
      list包起来；字符串需要在CONSTANTS中进行转义。
    inhert: [list, bool] 标明需要从当前env中继承的数据。如果是list，则表示需要
        集成的key。如果是True，则表示需要集成所有。默认为False。
  url: [dict, format] 表示需要访问的目标url地址。一般为字符串，需要
      进行format转换。如果是list则表示条件表达式。需要和regex配对使用。
    key: E:exp 可计算表达式，返回选择的key。
    map: [dict] 根据前面的key在map中选择字符串，需转义。
  default_args: [dict] 为env提供默认值。
  encoding: 指定网页编码。缺省则自动检测。
  regex: [list, format] 对网页结果进行正则抓取。list则分别匹配合并结果。默认值
      为C:default_regex。需要根据网页编码，事先encode（可考虑根据regex字符串
      和encoding做缓存）。通过groupdict返回抓取结果。
    NAME: 作为name返回。事先需要经过unescape和decode。
    BTIH: btih
  has_next: [format, bool] 判断是否有下一页。
      默认值 C:next_regex。不存在则为True。
  next_label: [format] 下一页的格式串->label。不存在则为NEXT_PAGE_NAME
  next_handler: [basestring]->handler 指向HANDLERS。
      下一页默认修改page+1，并传回原有所有参数
  more_entries: 与entries类似，但在网页加载完成后插入。
    insert_pos: [int, list] 插入位置，默认append。

  特殊handler:
    search: k参数不存在，则弹出搜索框，然后redirect。存在则执行search handler。
    choice: 弹出选择框，获取参数后redirect。
      重置page为firstpage
      heading: 选择框标题
      redirect: [handler, format]转到handler
      choices: [list, format] 选择项
      mapping: [dict, format] 参数回传方法。默认为choice
        根据mapping将必要参数回填env

Formatter(字符串格式):
    C: 在CONSTRANTS转义
    E: Python表达式
    R: raw string，不做任何转换（s[2:]）
    {} -> format
'''
import yaml
import re
import string
import os
import traceback
import chardet
from urllib import quote_plus
from xml.sax.saxutils import unescape
from xbmcswift2 import xbmc, xbmcgui, CLI_MODE
from bt import decode_btih
from utils import (fetch_url, get_btih_playurl, get_ed2k_playurl, run_plugin,
                   keyboard, NEXT_PAGE_NAME)


cfgs = {}
plugin = None


def load_cfgs(plug_in, site_name=None):
    global plugin
    plugin = plug_in
    register_handlers(plug_in)

    sites_path = os.path.join(os.path.dirname(__file__), '..', 'sites') \
        if CLI_MODE else \
        os.path.join(plugin.addon.getAddonInfo('path'), 'resources', 'sites')
    sites = find_files(sites_path)

    if CLI_MODE or plugin.get_setting('user_sites', bool):
        user_sites_path = xbmc.translatePath(
            'special://profile/addon_data/%s/sites/' % plugin.id)
        sites.update(find_files(user_sites_path))

    if site_name:
        sites = {site_name: sites[site_name]} if site_name in sites else {}

    for site, yamlfile in sites.iteritems():
        try:
            cfg = yaml.load(open(yamlfile))
            cfg['ID'] = site
            cfgs[site] = cfg
        except:
            plugin.log.debug(traceback.format_exc())
            continue

    return [{
        'label': cfg.get('LABEL'),
        'path': plug_in.url_for('handle_index', ID=ID),
        'thumbnail': cfg.get('THUMBNAIL')
    } for ID, cfg in cfgs.iteritems()]


def find_files(path, ext='.yaml'):
    if not os.path.isdir(path):
        return {}

    files = {}
    for d in os.listdir(path):
        if not d.endswith(ext):
            continue

        fullpath = os.path.join(path, d)
        if os.path.isfile(fullpath):
            files[d[:-len(ext)]] = fullpath

    return files


def register_handlers(plugin):
    plugin.add_url_rule('/<ID>/', handle_index, 'handle_index')
    plugin.add_url_rule('/<ID>/l/', handle_list, 'handle_list')
    plugin.add_url_rule('/<ID>/search/', handle_search, 'handle_search')
    plugin.add_url_rule('/<ID>/choice/', handle_choice, 'handle_choice')
    plugin.add_url_rule('/<ID>/p/', handle_play_html, 'handle_play_html')


def handle_index(ID):
    cfg = cfgs[ID]
    items = get_items_from_entries(ID, cfg['TOP_ENTRIES'])

    return items


def get_items_from_entries(ID, entries):
    cfg = cfgs[ID]
    items = []

    for entry in entries:
        name = entry.get('name')
        if name:
            name = expand_str(name, entry, cfg)
            entry['name'] = name
        if not isinstance(name, list):
            tmp_items = get_items_from_entry(ID, entry, cfg)
            tmp_items and items.extend(tmp_items)
        else:
            for n in name:
                new_entry = dict(entry, name=n)
                tmp_items = get_items_from_entry(ID, new_entry, cfg)
                tmp_items and items.extend(tmp_items)

    return items


def get_items_from_entry(ID, entry, cfg=None):
    cfg = cfg or cfgs[ID]
    env = entry.copy()

    name = entry.pop('name', '')
    if isinstance(name, basestring):
        label = entry.pop('label', '')
        label = label and expand_str(label, env, cfg) or name
    else:
        label = expand_str(entry['label'], env, cfg)
        name = label
    thumbnail = entry.pop('thumbnail', '')

    for url_key, items_producer in [
        ('video_url', get_items_by_videourl),
        ('btih', get_items_by_btih),
        ('ed2k_url', get_items_by_ed2kurl),
    ]:
        val = entry.pop(url_key, '')
        if val:
            return items_producer(val, label, thumbnail, name)

    entry = dict((k, expand_str(v, env, cfg)) for k, v in entry.iteritems())

    return [{
        'label': label,
        'path': plugin.url_for(get_view_by_entry(entry), ID=ID,
            name=name or label, **entry),
        'thumbnail': thumbnail,
        'is_playable': entry['handler'] == 'playhtml',
        'properties': {'isPlayable': ''},
    }]


def get_items_by_videourl(video_url, label=None, thumbnail=None, name=None):
    if isinstance(video_url, list):
        video_url = 'stack://' + ' , '.join(video_url)

    return [{
        'label': label,
        'path': video_url,
        'thumbnail': thumbnail,
        'is_playable': True,
    }]


def get_items_by_btih(btih, label=None, thumbnail=None, name=None):
    return [{
        'label': label,
        'path': get_btih_playurl(btih, name or label),
        'thumbnail': thumbnail,
        'is_playable': True,
        'properties': {'isPlayable': ''},
    }]


def get_items_by_ed2kurl(url, label=None, thumbnail=None, name=None):
    return [{
        'label': label,
        'path': get_ed2k_playurl(url, name or label),
        'thumbnail': thumbnail,
        'is_playable': True,
        'properties': {'isPlayable': ''},
    }]


def get_view_by_entry(entry):
    view = 'handle_list'
    handler = entry.get('handler')
    if handler == 'search':
        if 'k' not in entry:
            view = 'handle_search'
    elif handler == 'choice':
        view = 'handle_choice'
    elif handler == 'playhtml':
        view = 'handle_play_html'

    return view


def get_regex(exp, encoding=None):
    if encoding:
        exp = exp.encode(encoding, 'ignore')
    return re.compile(exp)


def expand_str(s, env, cfg, *extras):
    if not isinstance(s, basestring) or len(s) < 3:
        return s

    if s[1] == ':':
        prefix = s[0]
        if prefix == 'C':
            r = cfg['CONSTANTS'][s[2:]]
            if isinstance(r, basestring) and r[:2] in ('C:', 'E:', 'P:', 'R:'):
                return expand_str(r, env, cfg, *extras)

            return r
        elif prefix == 'E':
            return eval(s[2:], {}, env)
        elif prefix == 'R':
            return s[2:]
        elif prefix == 'P':
            s = s[2:]

    if '{' not in s:
        return s
    try:
        result = formatter.vformat(s, None, DictCombiner(env, cfg, *extras))
    except:
        plugin and plugin.log.info('format error: %s', s)
        raise

    return result


def handle_list(ID):
    cfg = cfgs[ID]
    params = dict((k, v[0]) for k, v in plugin.request.args.items())
    handler = cfg['HANDLERS'][params['handler']]
    entries = get_entries_by_handler(ID, handler, params, cfg)
    items = get_items_from_entries(ID, entries)

    return plugin.finish(items, view_mode='thumbnail'
                         if items and items[0].get('thumbnail') else '')


def get_entries_by_handler(ID, handler, env, cfg=None):
    cfg = cfg or cfgs[ID]

    if isinstance(handler, basestring):
        handler = cfg['HANDLERS'][handler]

    if isinstance(handler, list):
        entries = []
        for h in handler:
            entries.extend(get_entries_by_handler(ID, h, env, cfg))

        return entries

    entry_base = env

    default_args = handler.get('default_args')
    if default_args:
        env = dict(((k, expand_str(v, env, cfg))
                    for k, v in default_args.iteritems()), **env)
    else:
        env = env.copy()

    firstpage = int(env.get('firstpage', cfg.get('FIRST_PAGE', 1)))
    env['firstpage'] = firstpage
    env['page'] = int(env.get('page', firstpage))

    visible = expand_str(handler.get('visible', True), env, cfg)
    if not visible:
        return []

    entries = expand_str(handler.get('entries'), env, cfg)
    if entries:
        if not isinstance(entries, list):
            entries = [entries]

        entries_params = handler.get('entries_params')
        for entry in entries:
            if entries_params:
                for key, value in entries_params.iteritems():
                    entry.setdefault(key, value)

            inhert = entry.pop('inhert', False)
            if isinstance(inhert, list):
                for key in inhert:
                    if key in env:
                        entry.setdefault(key, env[key])
            elif inhert:
                for key, value in env.iteritems():
                    entry.setdefault(key, value)

        return entries

    url = handler['url']
    if isinstance(url, dict):
        cond = url['key']
        choices = url['map']
        url = choices[expand_str(cond, env, cfg)]
    url = expand_str(url, env, cfg)

    http_headers = expand_str(handler.get('http_headers', {}), env, cfg)

    html = fetch_url(url, headers=http_headers)
    encoding = handler.get('encoding') or chardet.detect(html)['encoding']

    constants = cfg.get('CONSTANTS', {})
    entries = []
    regex = handler.get('regex') or constants['default_regex']

    if regex == 'ignore':
        return []

    if regex.startswith('C:'):
        regex = constants[regex[2:]]
    if isinstance(regex, dict):
        transform = regex.get('transform')
        regex = regex['regex']
        if regex[:2] in ('C:', 'E:'):
            regex = expand_str(regex, env, cfg)
    else:
        transform = None
    regex = get_regex(regex, encoding)

    for m in regex.finditer(html):
        match_dict = m.groupdict()
        if transform:
            new_match_dict = {}
            for k, v in transform.iteritems():
                if isinstance(v, basestring):
                    new_match_dict[k] = expand_str(v, match_dict, cfg)
                else:
                    new_match_dict[k] = match_dict.get(k)
            match_dict = new_match_dict

        name = unescape(match_dict.pop('NAME', '')).decode(encoding, 'ignore')
        thumbnail = match_dict.pop('THUMBNAIL', '')
        video_found = False
        for k in ['BTIH', 'ED2K', 'VIDEO']:
            if k in match_dict:
                key = {
                    'BTIH': 'btih',
                    'ED2K': 'ed2k_url',
                    'VIDEO': 'video_url',
                }[k]
                value = match_dict[k]

                if key == 'btih' and len(value) == 32:
                    value = decode_btih(value)

                entries.append({
                    'label': 'R:' + name,
                    'thumbnail': thumbnail,
                    key: value,
                })

                video_found = True
                break

        if video_found:
            continue

        if 'PLAYHTML' in match_dict:
            entry = {'name': 'R:' + name, 'thumbnail': thumbnail, 'handler':
                     'playhtml', 'fetch_handler': handler['fetch_handler']}
        else:
            entry = {'name': 'R:' + name, 'thumbnail':
                     thumbnail, 'handler': handler['redirect']}

        entry.update(match_dict)
        inhert = handler.get('inhert', False)
        if isinstance(inhert, list):
            for key in inhert:
                if key in env:
                    entry.setdefault(key, env[key])
        elif inhert:
            for key, value in env.iteritems():
                entry.setdefault(key, value)

        entries.append(entry)

    env['items_count'] = len(entries)

    if len(entries) == 0:
        has_next = False
    else:
        if 'has_next' in handler:
            has_next = expand_str(handler['has_next'], env, cfg)
        elif 'has_next' in constants:
            has_next = expand_str(constants['has_next'], env, cfg)
        else:
            has_next = constants.get('next_regex', True)

        if isinstance(has_next, basestring):
            has_next = get_regex(has_next, encoding).search(html)

    env['has_next'] = bool(has_next)
    if has_next:
        entry = entry_base.copy()
        entry['page'] = env['page'] + 1
        next_label = handler.get('next_label')
        entry['label'] = expand_str(next_label, entry, cfg) if next_label \
            else NEXT_PAGE_NAME

        if 'next_handler' in handler:
            entry['handler'] = handler['next_handler']

        entries.append(entry)
        if handler.get('top_next', False):
            entries.insert(0, entry)

    more_entries = expand_str(handler.get('more_entries'), env, cfg)
    if more_entries:
        if not isinstance(more_entries, list):
            more_entries = [more_entries]

        for entry in more_entries:
            visible = expand_str(entry.pop('visible', True), env, cfg)
            if not visible:
                continue

            entry = dict((k, expand_str(v, env, cfg))
                         for k, v in entry.iteritems())

            inhert = entry.pop('inhert', False)
            if isinstance(inhert, list):
                for key in inhert:
                    if key in env:
                        entry.setdefault(key, env[key])
            elif inhert:
                for key, value in env.iteritems():
                    entry.setdefault(key, value)

            insert_pos = entry.pop('insert_pos', None)
            if not isinstance(insert_pos, list):
                insert_pos = [insert_pos]
            for pos in insert_pos:
                if pos is None:
                    entries.append(entry)
                else:
                    entries.insert(pos, entry)

    return entries


def handle_search(ID):
    cfg = cfgs[ID]
    params = dict((k, v[0]) for k, v in plugin.request.args.items())
    heading = params.pop('heading', u'请输入搜索关键词')
    query = (keyboard(heading=heading) or '').strip()
    if query:
        params['k'] = query
        handler_name = params.pop('redirect', None)
        handler_name = expand_str(handler_name, params, cfg) if handler_name \
            else 'search'
        handler = cfg['HANDLERS'][handler_name]
        params['handler'] = handler_name
        entries = get_entries_by_handler(ID, handler, params, cfg)
        return get_items_from_entries(ID, entries)

    return []


def handle_choice(ID):
    cfg = cfgs[ID]
    params = dict((k, v[0]) for k, v in plugin.request.args.items())
    heading = params.pop('heading', u'请在下面列表中选择')
    redirect = params.pop('redirect')
    params['handler'] = redirect
    mapping = expand_str(params.pop('mapping', 'choice'), params, cfg)
    choices = expand_str(params.pop('choices'), params, cfg)

    index = xbmcgui.Dialog().select(heading, choices)
    if index > 0:
        choice = choices[index]
        handler = cfg['HANDLERS'][redirect]

        if isinstance(mapping, dict):
            for key, value in mapping.iteritems():
                params[key] = index if value == 'index' else choice
        else:
            params[mapping] = choice

        entries = get_entries_by_handler(ID, handler, params, cfg)
        return get_items_from_entries(ID, entries)

    return []


def handle_play_html(ID):
    cfg = cfgs[ID]
    params = dict((k, v[0]) for k, v in plugin.request.args.items())
    name = params['name']

    fetch_handler = params['fetch_handler']
    urls = get_playable_urls_by_handler(ID, fetch_handler, params, cfg)
    if not urls:
        return

    first_url = urls[0]
    if first_url[0] == 'btih':
        url = get_btih_playurl(first_url[1], name)
        run_plugin(url)
    elif first_url[0] == 'ed2k_url':
        url = get_ed2k_playurl(first_url[1], name)
        run_plugin(url)
    else:
        if len(urls) == 1:
            url = first_url[1]
        else:
            url = 'stack://' + ' , '.join(u[1].strip() for u in urls)

        player = xbmc.Player()
        listitem = xbmcgui.ListItem(name)
        listitem.setInfo(type="Video", infoLabels={'Title': name})
        player.play(url)


def get_playable_urls_by_handler(ID, handler, env, cfg=None):
    cfg = cfg or cfgs[ID]

    if isinstance(handler, basestring):
        handler = cfg['HANDLERS'][handler]

    if isinstance(handler, list):
        urls = []
        for h in handler:
            urls.extend(get_playable_urls_by_handler(ID, h, env, cfg))

        return urls

    default_args = handler.get('default_args')
    if default_args:
        env = dict(((k, expand_str(v, env, cfg))
                    for k, v in default_args.iteritems()), **env)
    else:
        env = env.copy()

    url = handler['url']
    if isinstance(url, dict):
        cond = url['key']
        choices = url['map']
        url = choices[expand_str(cond, env, cfg)]
    url = expand_str(url, env, cfg)

    http_headers = expand_str(handler.get('http_headers', {}), env, cfg)

    html = fetch_url(url, headers=http_headers)
    encoding = handler.get('encoding') or chardet.detect(html)['encoding']

    constants = cfg.get('CONSTANTS', {})
    urls = []
    regex = handler.get('regex') or constants['default_regex']

    if regex == 'ignore':
        return []

    if regex.startswith('C:'):
        regex = constants[regex[2:]]
    if isinstance(regex, dict):
        transform = regex.get('transform')
        regex = regex['regex']
        if regex[:2] in ('C:', 'E:'):
            regex = expand_str(regex, env, cfg)
    else:
        transform = None
    regex = get_regex(regex, encoding)

    for m in regex.finditer(html):
        match_dict = m.groupdict()
        if transform:
            new_match_dict = {}
            for k, v in transform.iteritems():
                if isinstance(v, basestring):
                    new_match_dict[k] = expand_str(v, match_dict, cfg)
                else:
                    new_match_dict[k] = match_dict.get(k)
            match_dict = new_match_dict

        video_found = False
        for k in ['BTIH', 'ED2K', 'VIDEO']:
            if k in match_dict:
                key = {
                    'BTIH': 'btih',
                    'ED2K': 'ed2k_url',
                    'VIDEO': 'video_url',
                }[k]
                value = match_dict[k]

                if key == 'btih' and len(value) == 32:
                    value = decode_btih(value)

                urls.append((key, value))

                video_found = True
                break

        if video_found:
            continue

    return urls


class MyFormatter(string.Formatter):

    def convert_field(self, value, conversion):
        if 'q' == conversion:
            if isinstance(value, unicode):
                value = value.encode('utf-8', 'ignore')
            return quote_plus(value, '')
        else:
            return super(MyFormatter, self).convert_field(value, conversion)

formatter = MyFormatter()


class DictCombiner():

    def __init__(self, *args):
        self._dicts = args

    def __contains__(self, key):
        return any(key in d for d in self._dicts)

    def __getitem__(self, key):
        for d in self._dicts:
            if key in d:
                return d.__getitem__(key)
        else:
            raise KeyError
