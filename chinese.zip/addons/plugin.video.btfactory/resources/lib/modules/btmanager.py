#! /usr/bin/env python
# coding=utf-8
import os
import re
import json
import urllib2
import chardet
from BeautifulSoup import BeautifulSoup
from urllib import quote_plus, unquote_plus, urlencode
from urlparse import parse_qs
from xbmcswift2 import Module, Plugin, xbmcgui, actions, xbmc
import xbmcvfs
from ..bt import TorrentFile, decode_thunder_url, decode_btih
from ..utils import get_btih_playurl, refresh, get_ed2k_playurl, fetch_url


m = Module(__name__)
m.storage_path = Plugin().storage_path  # a bug from xbmcswift2

colors = {
    'bth': '7FFF00',
    'torrent': 'DA70D6',
    'dir': '8B4513',
    'bt': 'FF0066',
    'ed2k': '66FFFF',
    'thunder': 'CCFFCC',
    'stream': 'FFFF00',
    'baidu': 'CCCCFF',
    'video': 'FF0000',
}


@m.route('/add_dir/')
def add_dir():
    dialog = xbmcgui.Dialog()
    dirpath = dialog.browse(0, u'请选择需要增加的种子目录', 'files')
    if not dirpath:
        return

    media_dirs = m.plugin.get_storage(
        'user_media_dirs')  # bug from xbmcswift2. _unsynced_storages of Module
                    # cannot be reflected back to plugin. You have to use
                    # sync()
    name = os.path.basename(dirpath.rstrip(os.sep)) or dirpath
    media_dirs[dirpath] = name.decode('utf-8')

    refresh()


@m.route('/remove_dir/<dir>/')
def remove_dir(dir):
    media_dirs = m.plugin.get_storage(
        'user_media_dirs')  # bug from xbmcswift2. _unsynced_storages of Module
                # cannot be reflected back to plugin. You have to use sync()
    media_dirs.pop(dir, None)

    refresh()


@m.route('/bthfile/<path>/')
def show_bth_file(path):
    path = unquote_plus(path)
    items = parse_btih_file(path)

    menu_items = map(lambda x: generate_menu_items(*x), items)

    return menu_items


@m.route('/play_baidupan/<uk>/<shareid>/<fid>/noresolved/',
         name='play_baidupan_noresolved', options={'noresolved': True})
@m.route('/play_baidupan/<uk>/<shareid>/<fid>/')
def play_baidupan(uk, shareid, fid, noresolved=False):
    if fid == 'null':
        fid = ''

    if fid.isdigit():
        share_files, _ = parse_baidupan_url(uk, shareid, fid)
    else:
        share_files, _ = parse_baidupan_url(uk, shareid, remote_dir=fid)

    url, name = share_files[0][:2]
    url += '|User-Agent=Mozilla/5.0%20%28Windows%20NT%206.1%3B%20rv%3A25.0%29%20Gecko/20100101%20Firefox/25.0&Referer=http%3A//pan.baidu.com/share/' + 'shareid=%s&uk=%s' % (shareid, uk)
    if fid.isdigit():
        url += '&fid=%s' % fid
    if is_torrent(name):
        m.plugin.redirect(m.url_for('play_torrent', torrent=url))
    elif noresolved:
        listitem = xbmcgui.ListItem(name)
        xbmc.Player().play(url, listitem)
    else:
        m.plugin.set_resolved_url(url)


def update_plugin_url(plugin_url):
    xbmc.executebuiltin('Container.Update(%s)' % plugin_url)


def get_bdclnd(uk, shareid, passwd):
    url = 'http://pan.baidu.com/share/verify?shareid=%s&uk=%s' % (shareid, uk)
    data = 'pwd=%s&vcode=' % passwd
    r = urllib2.urlopen(url, data)
    cookies = r.headers.get('set-cookie')
    bdclnd = re.search(r'BDCLND=(.+?);', cookies).group(1)

    return bdclnd


@m.route('/baidupan/<uk>/<shareid>/<fid>/')
def show_baidupan(uk, shareid, fid):
    if shareid == 'null':
        shareid = ''
    if fid == 'null':
        fid = ''

    if shareid:
        try:
            params = dict((k, v[0]) for k, v in m.plugin.request.args.items())
            bdclnd = params.get('bdclnd')
            if bdclnd == 'null':
                bdclnd = None

            if not bdclnd:
                passwd = params.get('passwd')
                if passwd and passwd != 'null':
                    try:
                        bdclnd = get_bdclnd(uk, shareid, passwd)
                    except:
                        xbmcgui.Dialog().ok('警告', '提取密码校验失败')
                        return

            if fid.isdigit():
                share_files, folders = parse_baidupan_url(
                    uk, shareid, fid, bdclnd=bdclnd)
            else:
                share_files, folders = parse_baidupan_url(
                    uk, shareid, remote_dir=fid, bdclnd=bdclnd)
        except:
            xbmcgui.Dialog().ok('警告', '分享链接不存在或者存在错误')

            return

        compressed_files = []
        normal_files = []
        for sharefile in share_files:
            if is_compressed(sharefile[1]):
                compressed_files.append(sharefile)
            else:
                normal_files.append(sharefile)

        if len(normal_files) == 1 and not folders and not compressed_files:
            dlink, name, thumbnail = normal_files[0]
            dlink += '|User-Agent=Mozilla/5.0%20%28Windows%20NT%206.1%3B%20rv%3A25.0%29%20Gecko/20100101%20Firefox/25.0&Referer=http%3A//pan.baidu.com/share/link?' + 'shareid=%s&uk=%s' % (shareid, uk)
            if fid.isdigit():
                dlink += '&fid=%s' % fid
            update_plugin_url(
                m.url_for('playurl_with_name', url=dlink,
                          name=name.encode('utf-8')))

            return

        return [{
            'label': (colorize_label(name, 'torrent') if is_torrent(name)
                      else name),
            'path': (m.url_for('play_torrent', torrent=dlink)
                if is_torrent(name) else m.url_for('play_stream', url=dlink)),
            'is_playable': True,
            'thumbnail': thumbnail or '',
            'properties': is_torrent(name) and {'isPlayable': ''} or {}
        } for dlink, name, thumbnail in normal_files] + [{
            'label': '[COLOR FFFFFF00][ %s ][/COLOR]' % name,
            'path': m.url_for('show_baidupan', uk=uk, shareid=shareid,
                              fid=path.encode('utf-8'),
                              bdclnd=bdclnd or 'null')
        } for path, name, _ in folders] + [{
            'label': '[COLOR FFFFFF00][ %s ][/COLOR]' % name,
            'path': m.url_for('show_user_dir', dir=quote_url(
                '%s://%s/' % (name[-3:].lower(), quote_url(path))))
        } for path, name, _ in compressed_files]

    items = []
    share_files = parse_baidupan_url(uk)
    for share_id, name, fsIds, typicalCategory in share_files:
        one_file = len(fsIds) == 1 and typicalCategory != -1 \
            and not is_compressed(name)
        items.append({
            'label': (
                (colorize_label(name, 'torrent') if is_torrent(name) else name)
                if one_file
                else '[COLOR FFFFFF00]%s 等[/COLOR]' % name),
            'path': m.url_for('play_baidupan' if one_file else 'show_baidupan',
                              uk=uk, shareid=share_id, fid='null'),
            'is_playable': one_file,
            'properties': is_torrent(name) and {'isPlayable': ''} or {}
        })

    return items


@m.route('/asxfile/<path>/')
def show_asx_file(path):
    path = unquote_plus(path)
    soup = BeautifulSoup(xbmcvfs.File(path).read())

    entries = []
    for entry in soup.findAll(['entry', 'Entry']):
        url = entry.find(['Ref', 'ref']).get('href')
        title = entry.find(['Title', 'title'])
        if title is not None:
            title = title.text
        entries.append((url, title))

    return [{
        'label': colorize_label(title or url, 'stream'),
        'path': m.url_for('play_stream', url=url),
        'is_playable': True,
    } for url, title in entries]


@m.route('/playurl/<url>/<name>/', 'playurl_with_name')
@m.route('/playurl/<url>/')
def playurl(url, name=''):
    if name and is_torrent(name):
        play_torrent(url)
        return

    if not name:
        try:
            from urlresolvercn import resolve
            stream_url = resolve(url)
            if stream_url:
                url = stream_url
            else:
                from urlresolver import resolve
                stream_url = resolve(url)
                if stream_url:
                    url = stream_url
        except ImportError:
            pass

    listitem = xbmcgui.ListItem(name)
    xbmc.Player().play(url, listitem)


@m.route('/stream/<url>/')
def play_stream(url):
    m.plugin.set_resolved_url(url)


def join_path(path1, path2):
    if '://' in path1:
        if path1[-1] == '/':
            return path1 + path2

        return path1 + '/' + path2

    return os.path.join(path1, path2)


@m.route('/play_torrent/<torrent>/')
def play_torrent(torrent):
    if torrent.startswith('http://'):
        m.plugin.notify('正在加载torrent种子文件，请稍候...', delay=2000)
        try:
            fobj = fetch_url(torrent, timeout=10)
        except urllib2.URLError:
            xbmcgui.Dialog().ok('警告', '从网络获取torrent文件失败！')
            return
    else:
        fobj = xbmcvfs.File(torrent)

    try:
        tor = TorrentFile(fobj)
    except:
        xbmcgui.Dialog().ok('警告', '读取torrent文件失败！')
        return

    xbmc.executebuiltin('Container.Update(%s)' %
                        get_btih_playurl(tor.btih, tor.name))


@m.route('/listdir/<dir>/')
def show_user_dir(dir):
    dir = unquote_plus(dir)
    items = []
    subdirs = []
    torrent_files = []
    bth_files = []
    asx_files = []
    zip_files = []
    rar_files = []
    video_files = []

    subdirs, files = xbmcvfs.listdir(dir)
    for subdir in sorted(subdirs):
        items.append({
            'label': colorize_label(subdir, 'dir'),
            'path': m.url_for('show_user_dir',
                              dir=quote_url(join_path(dir, subdir)))
        })

    for name in files:
        fullpath = join_path(dir, name)

        if name.endswith('.torrent'):
            torrent_files.append((fullpath, name))
        elif name.endswith('.bth') or name.endswith('.strm'):
            bth_files.append((fullpath, name))
        elif name.endswith('.asx'):
            asx_files.append((fullpath, name))
        elif name.endswith('.zip'):
            zip_files.append((fullpath, name))
        elif name.endswith('.rar'):
            rar_files.append((fullpath, name))
        elif is_video(name):
            video_files.append((fullpath, name))

    for zip_file, name in sorted(zip_files):
        items.append({
            'label': colorize_label(name, 'dir'),
            'path': m.url_for('show_user_dir', dir=quote_url(
                'zip://%s/' % quote_url(zip_file)))
        })

    for rar_file, name in sorted(rar_files):
        items.append({
            'label': colorize_label(name, 'dir'),
            'path': m.url_for('show_user_dir', dir=quote_url(
                'rar://%s/' % quote_url(rar_file)))
        })

    for video_file, name in sorted(video_files):
        items.append({
            'label': colorize_label(name, 'video'),
            'path': video_file,
            'is_playable': True
        })

    for torrent_file, name in torrent_files:
        if is_compressed_http_url(torrent_file):
            items.append({
                'label': colorize_label(name, 'torrent'),
                'path': m.url_for('play_torrent', torrent=torrent_file),
                'is_playable': True,
                'properties': {'isPlayable': ''}
            })
        else:
            try:
                tor = TorrentFile(xbmcvfs.File(torrent_file))
            except:
                continue
            items.append({
                'label': colorize_label(tor.name, 'torrent'),
                'path': get_btih_playurl(tor.btih, tor.name),
                'is_playable': True,
                'properties': {'isPlayable': ''}
            })

    for bth_file, name in sorted(bth_files):
        items.append({
            'label': colorize_label(name, 'bth'),
            'path': m.url_for('show_bth_file', path=quote_url(bth_file))
        })

    _RE_ENTRY = re.compile(r'<\s*[Ee]ntry[\s>]')
    _RE_REF = re.compile(r'<\s*[Rr]ef\s+href\s*=\s*"(.+?)"')
    for asx_file, name in sorted(asx_files):
        try:
            content = xbmcvfs.File(asx_file).read()
            count = 0
            for match in _RE_ENTRY.finditer(content):
                count += 1
                if count >= 2:
                    break

            if count == 0:
                continue

            if count == 1:
                url = _RE_REF.search(content).group(1)
                items.append({
                    'label': colorize_label(name, 'stream'),
                    'path': m.url_for('play_stream', url=url),
                    'is_playable': True,
                })
                continue

            items.append({
                'label': colorize_label(name, 'stream'),
                'path': m.url_for('show_asx_file', path=quote_url(
                    asx_file.encode('utf-8')))
            })
        except:
            pass

    return items


def colorize_label(label, _class=None, color=None):
    color = color or colors.get(_class)

    if not color:
        return label

    if len(color) == 6:
        color = 'FF' + color

    return '[COLOR %s]%s[/COLOR]' % (color, label)


def transform_to_utf8(s):
    encoding = chardet.detect(s)['encoding']
    u = s.decode(encoding)
    ur = u.encode('raw_unicode_escape')
    encoding2 = chardet.detect(ur)['encoding']
    if encoding2 == 'ascii':
        return s if encoding == 'utf-8' else u.encode('utf-8')

    return transform_to_utf8(ur)


def generate_menu_items(protocol, url, name):
    if 'baidu' == protocol:
        uk, shareid, fid, path, passwd = url

        return {
            'label': colorize_label(name, protocol),
            'path': m.url_for('show_baidupan', uk=uk,
                              shareid=shareid or 'null',
                              fid=fid or path or 'null',
                              passwd=passwd or 'null')
        }

    return {
        'label': colorize_label(name, protocol),
        'path': {
            'bt': get_btih_playurl,
            'ed2k': get_ed2k_playurl,
            'thunder': get_ed2k_playurl,
            'bth': lambda url, name: m.url_for('show_bth_file', path=url),
            'stream': lambda url, name: m.url_for('playurl', url=url),
            'dir': lambda url, name: m.url_for('show_user_dir',
                                               dir=quote_url(name)),
            'plugin': lambda url, name: url
        }[protocol](url, name),
        'is_playable': protocol not in ('bth', 'dir', 'plugin'),
        'properties': {'isPlayable': ''}
    }


def is_video(filename):
    _video_file_exts = [
        '.mkv', '.rmvb', '.rm', '.avi', '.mpg', '.mpeg', '.mp4',
        '.mov', '.3gp', '.asf', '.wmv', '.flv', '.ts']
    filename = filename.lower()
    return any(filename.endswith(ext) for ext in _video_file_exts)


def is_torrent(filename):
    return filename.lower().endswith('.torrent')


def is_zip(filename):
    return filename.lower().endswith('.zip')


def is_rar(filename):
    return filename.lower().endswith('.rar')


def is_compressed(filename):
    return is_zip(filename) or is_rar(filename)


def is_useful_file(filename):
    return is_video(filename) or is_torrent(filename) \
        or is_compressed(filename)


def is_compressed_http_url(url):
    url = url.lower()
    return url.startswith('zip://http%3a%2f%2f') \
        or url.startswith('rar://http%3a%2f%2f')


def is_compressed_url(url):
    url = url.lower()
    return url.startswith('zip://') \
        or url.startswith('rar://')


@m.cached(TTL=60)
def parse_baidupan_url(uk, shareid=None, fid=None, remote_dir=None,
                       bdclnd=None):
    if shareid:
        items = []
        folders = []
        n_shareitems = 0
        for page in xrange(1, 21):
            shareitems = list_baidu_share(shareid, uk, fid, remote_dir,
                                          page=page, bdclnd=bdclnd)

            for share_item in shareitems:
                if str(share_item['isdir']) == '1':
                    folders.append((share_item['path'],
                                    share_item['server_filename'],
                                    share_item['fs_id']))
                else:
                    add_share_item(share_item, items)

            n_shareitems += len(shareitems)
            if len(shareitems) < 100:
                break

        assert n_shareitems

        if n_shareitems == 1 and not folders and not items:
            add_share_item(share_item, items, video_only=False)

        return items, folders

        # url = 'http://pan.baidu.com/share/link?shareid=%s&uk=%s' % (
        #     shareid, uk)
        # if fid:
        #     url += '&fid=' + fid
        # res = fetch_url(url)
        # _RE_SINGLE = re.compile(
        #     r'disk\.util\.ViewShareUtils\.viewShareData="(.+?[^\\])"')
        # match = _RE_SINGLE.search(res)
        # if match:
        #     json_obj = json.loads(match.group(1).decode('string_escape'))
        #     add_share_item(json_obj, items)

        #     return items

        # _RE_MULTI = re.compile(
        #     r'"(\[\{\\"fs_id\\":\\".+?\}\])"\]\);</script>')
        # captured_text = _RE_MULTI.search(res).group(1)
        # json_obj = json.loads(captured_text.decode('string_escape'))
        # top_folders = []
        # for share_item in json_obj:
        #     if str(share_item['isdir']) == '1':
        #         top_folders.append(share_item['path'])
        #     else:
        #         add_share_item(share_item, items)

        # for subdir in top_folders:
        #     sub_items = parse_baidupan_folder(uk, shareid, subdir)
        #     items.extend(sub_items)

        # return items

    items = [(share_item['shareId'],
              share_item['typicalPath'].rpartition('/')[2],
              share_item['fsIds'],
              share_item['typicalCategory'])
             for share_item in list_baidu_share_home_all(uk)
             if len(share_item['fsIds']) > 1
             or share_item['typicalCategory'] == -1
             or is_useful_file(share_item['typicalPath'])]

    return items


def list_baidu_share_home_all(uk):
    items = []
    for page in xrange(1, 21):
        shareitems = list_baidu_share_home(uk, page=page)
        items.extend(shareitems)

        if len(shareitems) < 100:
            break

    return items


def list_baidu_share_home(uk, remote_dir='/',
                          page=1, num=100, order='time', desc=1):
    params = {'uk': uk, 'dir': remote_dir, 'page': page}
    if 1 < num < 100:
        params['num'] = num
    if order != 'time':
        params['order'] = order
    if desc != 1:
        params['desc'] = desc

    url = 'http://pan.baidu.com/share/homerecord?' + urlencode(params)
    shareitems = json.loads(fetch_url(url))['list']

    return shareitems


def list_baidu_share(shareid, uk, fid=None, remote_dir=None,
                     page=1, num=100, order='time', desc=1,
                     bdclnd=None):
    params = {'shareid': shareid, 'uk': uk}
    if fid:
        params['fid'] = fid
    elif remote_dir:
        params['dir'] = remote_dir
    else:
        params['root'] = 1
    if page > 1:
        params['page'] = page
    if 1 < num < 100:
        params['num'] = num
    if order != 'time':
        params['order'] = order
    if desc != 1:
        params['desc'] = desc

    url = 'http://pan.baidu.com/share/list?' + urlencode(params)
    headers = {}
    if bdclnd:
        headers['Cookie'] = 'BDCLND=' + bdclnd
    shareitems = json.loads(fetch_url(url, headers=headers))['list']

    return shareitems


# def parse_baidupan_folder(uk, shareid, path, bdclnd=None):
#     items = []
#     folders = []

#     for page in xrange(1, 20):
#         shareitems = list_baidu_share(
#             shareid, uk, page=page, remote_dir=path, bdclnd=bdclnd)

#         if not shareitems:
#             break

#         for share_item in shareitems:
#             if str(share_item['isdir']) == '1':
#                 folders.append(share_item['path'])
#             else:
#                 add_share_item(share_item, items, name_only=False)

#         if len(shareitems) < 100:
#             break

#     for subdir in folders:
# items.extend(parse_baidupan_folder(uk, shareid, subdir, bdclnd=bdclnd))

#     return items


def add_share_item(share_item, items, video_only=True, name_only=True):
    if video_only and not is_useful_file(share_item['server_filename']):
        return

    imgurl = ''
    if 'thumbs' in share_item and 'url1' in share_item['thumbs']:
        imgurl = share_item['thumbs']['url1'].replace(
            'size=c140_u90', 'size=c300_u300')

    items.append((share_item['dlink'],
                  share_item['server_filename'] if name_only else
                  share_item['path'].rstrip('/'), imgurl))


def parse_btih_file(bthfile):
    items = []
    protocol, _, url_path = bthfile.partition('://')
    if url_path and protocol not in ('smb', 'nfs', 'special'):
        content = urllib2.urlopen(bthfile).read()
    else:
        content = xbmcvfs.File(bthfile).read()

    encoding = chardet.detect(content)['encoding']
    if encoding in ('GB2312', 'BIG5'):
        content = content.decode(encoding)

    fileobj = content.splitlines()
    for line in fileobj:
        line = line.strip()
        if not line or line.startswith('#'):
            continue

        item = parse_url(line)
        if not item:
            continue

        items.append(item)

    return items


def parse_url(url):
    _RE_ED2K = re.compile(r'ed2k://\|file\|(.+?)\|(?:.*\|/\s*\|(.+))?')
    _RE_THUNDER = re.compile(r'(thunder://[A-Za-z0-9\+/]+=*)(?:\s*\|(.+))?')
    _RE_MAGNET_URL = re.compile(
        r'magnet:\?xt=urn:btih:([0-9a-fA-F]{40}|[2-7A-Z]{32})(?:.*?\|(.+))?')
    _RE_BTIH = re.compile(r'([0-9a-fA-F]{40}|[2-7A-Z]{32})(?:\s*\|(.+))?')

    match = _RE_MAGNET_URL.match(url)
    if match:
        btih, name = match.groups()
        if len(btih) == 32:
            btih = decode_btih(btih)
        return ('bt', btih, name and name.strip() or btih)

    match = _RE_BTIH.match(url)
    if match:
        btih, name = match.groups()
        if len(btih) == 32:
            btih = decode_btih(btih)
        return ('bt', btih, name and name.strip() or btih)

    match = _RE_ED2K.match(url)
    if match:
        name_ed2k, name_user = match.groups()
        if name_user:
            name = name_user and name_user.strip() or unquote_plus(name_ed2k)
            url = url.rpartition('|/')[0] + '|/'
        else:
            name = unquote_plus(name_ed2k)
        return ('ed2k', url, name)

    match = _RE_THUNDER.match(url)
    if match:
        thunder_url, name = match.groups()
        return ('thunder', thunder_url, name and name.strip() or
                transform_to_utf8(decode_thunder_url(thunder_url)))

    _RE_BAIDUPAN = re.compile(
        r'http://(pan|yun)\.baidu\.com/share/(link|home)\?')
    if _RE_BAIDUPAN.match(url):
        param_str, _, name = url[url.index('?') + 1:].partition('|')

        path = ''
        path_idx = param_str.find('#dir/path=')
        if path_idx >= 0:
            path = unquote_plus(param_str[path_idx + 10:]).strip()
            param_str = param_str[:path_idx]

        params = parse_qs(param_str)
        if 'uk' not in params:
            return

        uk = params['uk'][0].strip()

        shareid = ''
        if 'shareid' in params:
            shareid = params['shareid'][0].strip()

        fid = ''
        if 'fid' in params:
            fid = params['fid'][0].strip()

        passwd = ''
        if 'passwd' in params:
            passwd = params['passwd'][0].strip()

        name = name.strip() or \
            '百度盘 (uk=%s%s%s)' % (
            uk, ', shareid=' + shareid if shareid else '',
            ',fid=' + fid if fid else '')

        return ('baidu', (uk, shareid, fid, path, passwd), name)

    if url.startswith('bth:'):
        newurl, _, name = url[4:].rpartition('|')
        return ('bth', newurl or name, name or newurl)

    if (url.startswith('zip://') or url.startswith('rar://')
            or url.startswith('/')
            or (url[1:3] == ':\\' and url[0].isalpha())):
        url = url.partition('|')[0].rstrip()
        return ('dir', None, url)

    if url.startswith('plugin://'):
        newurl, _, name = url.rpartition('|')
        return ('plugin', newurl or name, name or newurl)

    pos = url.find('://')
    if url[:pos] in ('http', 'ftp', 'rstp', 'rtmp', 'mms', 'plugin'):
        newurl, _, name = url.rpartition('|')
        return ('stream', newurl or name, name or newurl)


def log(*args):
    m.plugin.log.info(args[0] if len(args) == 1 else args)


def quote_url(url):
    return quote_plus(url, '')


def get_main_menu_items():
    media_dirs = m.get_storage('user_media_dirs')
    items = [{
        'label': '[目录] [COLOR FFFFFF00]%s[/COLOR]' % name,
        'path': m.url_for('show_user_dir', dir=quote_url(path)),
        'context_menu': [('移除目录',
                          actions.background(m.url_for(
                                             'remove_dir', dir=path)))]
    } for path, name in media_dirs.items()]

    items.append({
        'label': '添加[COLOR FFFFFF00]本地视频[/COLOR]目录',
        'path': m.url_for('add_dir'),
        'is_playable': True,
        'properties': {'isPlayable': ''}
    })

    return items
