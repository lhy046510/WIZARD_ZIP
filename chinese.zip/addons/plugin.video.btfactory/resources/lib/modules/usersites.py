#! /usr/bin/env python
#coding=utf-8
from xbmcswift2 import Module, Plugin, xbmcgui, xbmc, CLI_MODE
if not CLI_MODE:
    import xbmcvfs
import os
from resources.lib import yaml
from ..utils import refresh


m = Module(__name__)
m.storage_path = Plugin().storage_path #a bug from xbmcswift2

@m.route('/')
def index():
    items = [{
        'label': name,
        'path': m.url_for('del_site', filename=name),
        'is_playable': True,
        'properties': {'isPlayable': ''}
    } for name in get_user_sites()]

    items += [{
        'label': u'添加自定义站点',
        'path': m.url_for('add_sites'),
        'is_playable': True,
        'properties': {'isPlayable': ''}
    }]

    return items


@m.route('/add_sites/')
def add_sites():

    dialog = xbmcgui.Dialog()
    yamlfile = dialog.browse(1, u'请选择自定义站点配置文件', 'files', '.yaml')
    if not yamlfile:
        return

    basename = os.path.basename(yamlfile)
    try:
        cfg = yaml.load(xbmcvfs.File(yamlfile))
        cfg['TOP_ENTRIES']
        cfg['HANDLERS']
        'LABEL' in cfg or cfg['NAME']
    except:
        m.notify(u'您选择的配置文件不符合规范，请重新选择！')
    else:
        xbmcvfs.copy(yamlfile,
            os.path.join(get_user_sites_path(), basename))
        refresh()

@m.route('/del_site/<filename>/')
def del_site(filename):
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(u'提示', u'您是否真的需要删除该站点？'):
        return

    fullpath = os.path.join(get_user_sites_path(), filename)
    xbmcvfs.delete(fullpath)
    refresh()


def get_user_sites():
    return [f for f in xbmcvfs.listdir(get_user_sites_path())[1]
                if f.endswith('.yaml')]

def get_user_sites_path():
    path = xbmc.translatePath(
        'special://profile/addon_data/%s/sites/' % m.plugin.id)
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdir(path)

    return path

def get_main_menu_items():
    if not CLI_MODE and not m.get_setting('user_sites', bool):
        return []

    return [{
        'label': u'管理[COLOR FFFFCC00]用户自定义[/COLOR]站点',
        'path': m.url_for('index'),
    }]
