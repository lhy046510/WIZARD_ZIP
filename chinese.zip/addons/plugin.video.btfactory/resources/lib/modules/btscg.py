#!/usr/bin/python
# -*- coding: utf-8 -*-
from xbmcswift2 import Module, Plugin
import re, urllib, urlparse
from xml.sax.saxutils import unescape
from BeautifulSoup import BeautifulSoup
from ..bt import check_btih
from ..utils import fetch_url, get_btih_playurl, NEXT_PAGE_NAME, keyboard, run_plugin


m = Module(__name__)
m.storage_path = Plugin().storage_path #a bug from xbmcswift2


@m.route('/')
def index():
    return [ {'label': u'电影', 'path': m.url_for('show_contents_firstpage', genre='default', tag='movie')},
             {'label': u'电视剧', 'path': m.url_for('show_contents_firstpage', genre='default', tag='tv')},
             {'label': u'*搜索*', 'path': m.url_for('search')}]

@m.route('/search/')
def search():
    query = (keyboard(heading=u'请输入搜索内容') or '').strip()
    if query:
        m.plugin.redirect(m.url_for('search_result_firstpage', keyword=query)) #bug from xbmcswift2, cannot use Module.redirect


@m.route('/search/<keyword>/', 'search_result_firstpage')
@m.route('/search/<keyword>/<page>/')
def search_result(keyword, page='1'):
    page = int(page)
    url = get_search_url(keyword) if page == 1 else m.request.args['url'][0]
    return get_search_items(url, keyword, page)


@m.route('/playtv/<url>/')
def play_tv(url):
    name = m.request.args['name'][0]
    btih = ''
    html = fetch_url(url)

    match = re.search(r'href="magnet:\?xt=urn:btih:([0-9a-fA-F]{40})', html)
    if match:
        btih = match.group(1)
    else:
        match = re.search(r'href="[^"]*([0-9a-fA-F]{40})\.torrent', html)
        if match:
            btih = match.group(1)

    if btih:
        #m.plugin.set_resolved_url(get_btih_playurl(btih, name)) #bug from xbmcswift2, cannot use Module.set_resolved_url
        run_plugin(get_btih_playurl(btih, name))


@m.route('/<tag>/genres/')
def show_genres(tag):
    return [{
        'label': name,
        'path': m.url_for('show_contents_firstpage', tag=tag,
            genre=name.encode('utf-8'), url=url)
    } for name, url in get_genres(tag)]


@m.route('/<tag>/<genre>/', 'show_contents_firstpage')
@m.route('/<tag>/<genre>/<page>/')
def show_contents(tag, genre, page='0'):
    page_index = int(page) or 1
    items = []

    url = ''
    if genre == 'default':
        if page_index == 1: #第一页下方显示分类
            items.append({
                'label': u'[COLOR FFFFFF00]【分类索引】[/COLOR]',
                'path': m.url_for('show_genres', tag=tag)
            })
            url = DEFAULT_URLS[tag]

    if not url:
        url = m.request.args['url'][0]
    
    if tag == 'movie':
        m.set_content('movies')

    items.extend(get_playable_items(url, tag, page_index, genre))
    return m.plugin.finish(items, update_listing=page != '0',
        view_mode='thumbnail' if tag == 'movie' else '') #bug from xbmcswift2, cannot use Module.finish


DEFAULT_URLS = {
    'movie': 'http://www.btscg.com/forum-2-1.html',
    'tv': 'http://www.btscg.com/forum-36-1.html'
}


@m.cached(TTL=60)
def get_genres(tag):
    '''获取分类索引'''
    _RE_GENRE_LINK = re.compile(r'class="xw1"\s*?><a\s+?href="(.+?)">(.+?)<')
    genres = []

    html = fetch_url(DEFAULT_URLS[tag])
    for m in _RE_GENRE_LINK.finditer(html):
        linkurl, linkname = m.groups()
        genres.append((linkname.decode('gbk'), unescape(linkurl)))

    return genres


#TODO: 需要有个机制清理过期数据
#bug from xbmcswift2, TTL无效，被前面的TTL覆盖
@m.cached(TTL=10)
def get_playable_items(url, tag, page, genre):
    html = fetch_url(url).decode('gbk', 'ignore')
    items = {
        'movie': get_movie_links,
        'tv': get_tv_links
    }[tag](html, genre)

    for f_get_link in (get_next_link, get_prev_link):
        link = f_get_link(html, tag, genre, page)
        if link:
            items.insert(0, link)
            items.append(link)

    return items


def get_next_link(html, tag, genre, page):
    match = re.search(ur'<a[^>]+href="([^>]+?)"\s+class="nxt"\s*>\s*下一页', html)
    if not match:
        return

    next_page = str(page+1)
    return {
        'label': u'[COLOR FFFF0000]第%s页 >[/COLOR]' % next_page,
        'path': m.url_for('show_contents', tag=tag, genre=genre,
                page=next_page, url=unescape(match.group(1)))
    }


def get_prev_link(html, tag, genre, page):
    if page < 2:
        return

    match = re.search(r'<div\s*class="pg">.*?<a[^>]+?href="([^>]+?)">\s*\d+\s*<\/a>\s*<strong>', html)
    if not match:
        return

    prev_page = str(page-1)
    return {
        'label': u'[COLOR FFFF0000]< 第%s页[/COLOR]' % prev_page,
        'path': m.url_for('show_contents', tag=tag, genre=genre,
                page=prev_page, url=unescape(match.group(1)))
    }


def get_movie_links(html, genre):
    _RE_MOVIE_LINK = re.compile(ur'class="listtopimg"[^>]*>\s*<[^>]+>\s*<img[^>]+src="(.+?)"[^>]*>\s*<\/a>\s*<\/div>\s*<div\s+class="listboxbottxt">[^>]+>\s*(.+?)\s*<\/a>\s*<\/div>\s*<div\s+class="operbox">(?:\s*<a[^>]+href="(.+?)"[^>]*>\s*种子\s*<\/a>)?(?:\s*<a[^>]+href="magnet:\?xt=urn:btih:([0-9a-fA-F]{40})[^>]+>\s*磁力链)?')
    items = []

    for match in _RE_MOVIE_LINK.finditer(html):
        imgurl, name, torrent_url, btih = match.groups()
        if not btih:
            btih = torrent_url[-48: -8]
        btih = str(btih)

        if check_btih(btih):
            items.append({
                'label': name,
                'path': get_btih_playurl(btih, name),
                'thumbnail': imgurl,
                'info': {
                    'title': name,
                    'genre': genre
                },
                'is_playable': True,
                'properties': {'isPlayable': ''}
            })

    return items


def get_tv_links(html, genre):
    _RE_TV_LINK = re.compile(r'<a[^>]+href="([^"]+)"[^>]+class="xst"[^>]*>\s*(\S+)\s*<\/a>')
    items = []

    for match in _RE_TV_LINK.finditer(html):
        link, name = match.groups()

        items.append({
            'label': name,
            'path': m.url_for('play_tv', url=unescape(link), name=name.encode('utf-8')),
            'info': {
                'title': name,
                'genre': genre
            },
            'is_playable': True,
            'properties': {'isPlayable': ''}
        })

    return items


def get_search_url(keyword):
    params = {
        'myfIds[]': ['2', '36'],
        'orderField': 'default',
        'orderType': 'desc',
        'searchLevel': '4',
        'q': keyword,
        'qs': 'txt.adv.a',
        'threadScope': 'all',
        'timeLength': '0',
    }
    html = fetch_url('http://www.btscg.com/search.php')
    match = re.compile(r"var\s+myParams\s*=\s*\'(.+)\'").search(html)
    params.update(dict(urlparse.parse_qsl(match.group(1))))

    return 'http://search.btscg.com/f/search?' + urllib.urlencode(params, 1)


def get_search_items(url, keyword, page):
    html = fetch_url(url)
    soup = BeautifulSoup(html)
    items = []

    result_items = soup.find(id='result-items')
    if not result_items:
        return []

    for li in result_items('li'):
        link = li.h3.a
        items.append({
            'label': link.text,
            'path': m.url_for('play_tv', url=link['href'], name=link.text.encode('utf-8')),
            'is_playable': True,
            'properties': {'isPlayable': ''}
        })

    next_page = soup.find(lambda t:t.name=='a' and t.text.startswith(u'下一页'))
    if next_page:
        next_url = urlparse.urljoin('http://search.btscg.com/f/search', next_page['href'])
        items.append({
            'label': NEXT_PAGE_NAME,
            'path': m.url_for('search_result', url=next_url,
                        keyword=keyword, page=str(page+1))
        })

    return items


def get_main_menu_items():
    return [{
        'label': u'从[COLOR FF00CC00]圣城家园[/COLOR]获取种子',
        'path': m.url_for('index'),
        'thumbnail': 'http://www.btscg.com/static/image/common/logo.gif'
    }]
