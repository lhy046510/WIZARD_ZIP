# -*- coding: utf-8 -*-
# hdplib.py

import urllib,urllib2,re,xbmcplugin,xbmcgui,subprocess,sys,os,os.path,xbmcaddon,md5,hashlib,xbmc
HOST='http://tv1.hdpfans.com'
src = 'andriod'   
m1 = md5.new()   
m1.update(src)   
dest1 = m1.hexdigest()   
KEY = 'key/'+ dest1
TYPE_LIST = [HOST+'/~rss.get.category/site/youku/channel/movie/rss/1/xml/1/ajax/1/'+KEY, HOST+'/~rss.get.category/site/youku/channel/tv/rss/1/xml/1/ajax/1/'+KEY,HOST+'/~rss.get.category/site/youku/channel/comic/rss/1/xml/1/ajax/1/'+KEY]

def GetHttpData(url):
	#UserAgent = ''
	req = urllib2.Request(url)
	#req.add_header('User-Agent', UserAgent)
	response = urllib2.urlopen(req)
	httpdata = response.read()
	if response.headers.get('content-encoding', None) == 'gzip':
		httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
	response.close()
	match = re.compile('encodingt=(.+?)"').findall(httpdata)
	if len(match)<=0:
		match = re.compile('meta charset="(.+?)"').findall(httpdata)
	if len(match)>0:
		charset = match[0].lower()
		if (charset != 'utf-8') and (charset != 'utf8'):
			httpdata = unicode(httpdata, charset).encode('utf8')
	return httpdata

def buildRoot():
	listitem=xbmcgui.ListItem('热门电影')
	url=sys.argv[0]+'?mode=1&type=0&page=1&url='+urllib.quote_plus(HOST+'/~rss.get.film_xml/site/youku/channel/movie/category/%25E6%259C%2580%25E7%2583%25AD/rss/1/xml/1/ajax/1/'+KEY)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	listitem=xbmcgui.ListItem('热门电视剧')
	url=sys.argv[0]+'?mode=1&type=1&page=1&url='+urllib.quote_plus(HOST+'/~rss.get.film_xml/site/youku/channel/tv/category/%25E7%2583%25AD%25E9%2597%25A8/rss/1/xml/1/ajax/1/'+KEY)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	listitem=xbmcgui.ListItem('最新美剧')
	url=sys.argv[0]+'?mode=1&type=1&page=1&url='+urllib.quote_plus(HOST+'/~rss.get.film_xml/site/youku/channel/tv/category/%25E7%25BE%258E%25E5%2589%25A7/rss/1/xml/1/ajax/1/'+KEY)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	listitem=xbmcgui.ListItem('少儿节目')
	url=sys.argv[0]+'?mode=1&type=2&page=1&url='+urllib.quote_plus(HOST+'/~rss.get.film_xml/site/youku/channel/comic/category/%25E5%2585%25A8%25E9%2583%25A8/rss/1/xml/1/ajax/1/'+KEY)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def buildLists(url,page,type):
	mylist = GetHttpData(url+'/page/'+str(page))
	maxpage = re.compile('<PAGECOUNT>(.*?)</PAGECOUNT>', re.DOTALL).findall(mylist)
	listitem=xbmcgui.ListItem('[COLOR FF00FF00]第'+str(page)+ '/' + str(maxpage[0])+'页 【[COLOR FFFF0000]点击切换分类[/COLOR]】[/COLOR]')
	u=sys.argv[0] + '?mode=5&type=' + str(type)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, listitem, True)
	if page > 1:
		listitem=xbmcgui.ListItem('[COLOR FF00FF00]上一页  ' + str(page)+ '/' + str(maxpage[0])+'[/COLOR]')
		u=sys.argv[0] + '?mode=1&page='+str(page-1) + '&type=' + str(type) + '&url=' + urllib.quote_plus(url)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, listitem, True)
	names = re.compile('<name>(.*?)</name>', re.DOTALL).findall(mylist)
	links = re.compile('<link>(.*?)</link>', re.DOTALL).findall(mylist)
	thumbnails = re.compile('<img>(.*?)</img>', re.DOTALL).findall(mylist)
	for i in range(0,len(names)):
		name = names[i]
		link = links[i]
		thumbnail = thumbnails[i] 
		listitem=xbmcgui.ListItem(name,thumbnailImage = thumbnail)
		u=sys.argv[0]+'?mode=2&url='+urllib.quote_plus(link)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, listitem, True, len(names))
	listitem=xbmcgui.ListItem('[COLOR FF00FF00]下一页  ' + str(page)+ '/' + str(maxpage[0])+'[/COLOR]')
	u=sys.argv[0] + '?mode=1&page='+str(page+1) + '&type=' + str(type) +'&url=' + urllib.quote_plus(url)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, listitem, True)
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
	xbmc.executebuiltin('Container.SetViewMode(500)')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def buildSeries(url):
	mylist = GetHttpData(url)
	foobars = re.compile('<foobar>(.+?)</foobar>', re.DOTALL).findall(mylist)
	for foobar in foobars:
		names = re.compile('<name>(.+?)</name>', re.DOTALL).findall(foobar)
		links = re.compile('<url>(.+?)</url>', re.DOTALL).findall(foobar)
		listitem=xbmcgui.ListItem(names[0])
		url=sys.argv[0] + '?mode=3&url=' + urllib.quote_plus(links[0])
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, False)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
		
def playVideo(url):
	mylist = GetHttpData(url)
	foobars = re.compile('<m3u8>(.*?)</m3u8>', re.DOTALL).findall(mylist)
	playlist = xbmc.PlayList(1)
	playlist.clear()
	for i in range(0,len(foobars)):
		title =" 第"+str(i+1)+"/"+str(len(foobars))+"节"
		listitem=xbmcgui.ListItem(title)
		listitem.setInfo(type="Video",infoLabels={"Title":title})
		playlist.add(foobars[i], listitem)
	xbmc.Player().play(playlist)

def performChange(type):
	mylist = GetHttpData(TYPE_LIST[type])
	names = re.compile('<name>(.*?)</name>', re.DOTALL).findall(mylist)
	links = re.compile('<url>(.*?)</url>', re.DOTALL).findall(mylist)
	dialog = xbmcgui.Dialog()
	sel = dialog.select('选择分类', names)
	url=links[sel]
	buildLists(url,page=1,type=type)

		
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param	

