# -*- coding: utf-8 -*- 

import os
import sys,traceback, threading
import xbmc,xbmcgui,json,urllib2,re,base64,cookielib,urllib
import xbmcaddon
from BeautifulSoup import BeautifulSoup,Comment,BeautifulStoneSoup
import chardet
reload(sys)
sys.setdefaultencoding('utf-8')
__author__     = "yxblog"
__scriptid__   = "plugin.video.yyets"
__scriptname__ = "人人影视(YYETS)"

__addon__      = xbmcaddon.Addon()

__cwd__        = __addon__.getAddonInfo('path')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString

__profile__    = xbmc.translatePath( __addon__.getAddonInfo('profile') )
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )
THEME = 'Default'
cookie = cookielib.LWPCookieJar()
cook = urllib2.HTTPCookieProcessor(cookie)
try:
    from ChineseKeyboard import Keyboard
except:
    from xbmc import Keyboard  
    pass
ACTION_MOVE_LEFT      = 1
ACTION_MOVE_RIGHT     = 2
ACTION_MOVE_UP        = 3
ACTION_MOVE_DOWN      = 4
ACTION_PAGE_UP        = 5
ACTION_PAGE_DOWN      = 6
ACTION_SELECT_ITEM    = 7
ACTION_HIGHLIGHT_ITEM = 8
ACTION_PARENT_DIR_OLD = 9
ACTION_PARENT_DIR     = 92
ACTION_PREVIOUS_MENU  = 10
ACTION_SHOW_INFO      = 11
ACTION_PAUSE          = 12
ACTION_STOP           = 13
ACTION_NEXT_ITEM      = 14
ACTION_PREV_ITEM      = 15
ACTION_SHOW_GUI       = 18
ACTION_PLAYER_PLAY    = 79
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_CONTEXT_MENU   = 117
main_type_list=['电影','电视剧','纪录片','公开课','专题','我的收藏']
area = ['全部','美国','大陆','日本','韩国','英国','香港','台湾','印度','法国','加拿大','西班牙','新加坡','泰国','意大利','德国','俄罗斯','越南','澳大利亚','其他']
category = [ '全部','动作','战争','剧情','喜剧','生活','偶像','青春','魔幻','科幻','历史','纪录','暴力','血腥','歌舞','恐怖','惊悚','悬疑','古装','史诗','丧尸','爱情','医务','律政','真人秀','励志','体育','谍战','罪案','冒险','动画','科教','西部','枪战','灾难','传记','幽默','讽刺','童话','幻想','综艺']
year= ['全部','2013','2012','2011','2010','2009','2008','2007','2006','2005','2004','2003','2002','2001','2000','1999','1998','1997','1996','1995','1994','1993','1992','1991','1990']
sort=[['update','按更新'],['pubdate','按发布'],['premiere','按上映'],['name','按名称'],['rank','按排名'],['score','按评分'],['views','按点击']]
sys.path.append (__resource__)


class WindowState:
	def __init__(self):
		self.items = None
		self.listIndex = 0
		self.settings = {}

class BaseWindow(xbmcgui.WindowXML):
	def __init__( self, *args, **kwargs):
		self.oldWindow = None
		xbmcgui.WindowXML.__init__( self )
		
	def doClose(self):
		self.session.window = self.oldWindow
		self.close()
		
	def onInit(self):
		self.setSessionWindow()
		
	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def setSessionWindow(self):
		try:
			self.oldWindow = self.session.window
		except:
			self.oldWindow=self
		self.session.window = self
		
	def onAction(self,action):
		if action.getId() == ACTION_PARENT_DIR or action.getId() == ACTION_PREVIOUS_MENU:
			if xbmc.Player().isPlaying():
				xbmc.Player().stop()
			self.doClose()
			return True
		else:
			return False

class MainWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = None
		self.main_type_list_select=0
		self.category_select=0
		self.area_select=0
		self.sort_select=0
		self.year_select=0
		self.page=1
		self.updates=True
		self.search_select=False
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		if self.session:
			self.session.window = self
		else:
			try:
				self.session = yyetsSession(self)
			except:
				ERROR('Unhandled Error')
				self.close()
		
		if self.getControl(10).size()==0:
			for item in main_type_list:
				listitem = xbmcgui.ListItem( label=item)
				self.getControl(10).addItem( listitem )
			self.getControl(10).getSelectedItem().select(True)	
			for item in category:
				listitem = xbmcgui.ListItem( label=item)
				self.getControl(5).addItem( listitem )
			self.getControl(5).getSelectedItem().select(True)	
			for item in area:
				listitem = xbmcgui.ListItem( label=item)
				self.getControl(6).addItem( listitem )
			self.getControl(6).getSelectedItem().select(True)	
			for item in year:
				listitem = xbmcgui.ListItem( label=item)
				self.getControl(7).addItem( listitem )
			self.getControl(7).getSelectedItem().select(True)	
			for item in sort:
				listitem = xbmcgui.ListItem( label=item[1])
				self.getControl(8).addItem( listitem )
			self.getControl(8).getSelectedItem().select(True)	
			self.update_list()
		if self.main_type_list_select==5:
			self.update_fav()

	def onClick( self, controlId ):
		if controlId ==10:
			position = self.getControl( 10 ).getSelectedPosition()
			if position == 5:
				self.getControl( 10 ).getListItem(self.main_type_list_select).select(False)
				self.getControl( 10 ).getSelectedItem().select(True)
				self.main_type_list_select=position
				self.update_fav()
			else:
				self.getControl( 10 ).getListItem(self.main_type_list_select).select(False)
				self.getControl( 10 ).getSelectedItem().select(True)
				self.main_type_list_select=position
				self.updates=True
				self.search_select=False
				self.update_list()
		elif controlId ==5:
			position = self.getControl( 5 ).getSelectedPosition()
			self.getControl( 5 ).getListItem(self.category_select).select(False)
			self.getControl( 5 ).getSelectedItem().select(True)
			self.category_select=position
			self.updates=True
			self.search_select=False
			self.update_list()
		elif controlId ==6:
			position = self.getControl( 6 ).getSelectedPosition()
			self.getControl( 6 ).getListItem(self.area_select).select(False)
			self.getControl( 6 ).getSelectedItem().select(True)
			self.area_select=position
			self.updates=True
			self.search_select=False
			self.update_list()
		elif controlId ==7:
			position = self.getControl(7 ).getSelectedPosition()
			self.getControl(7 ).getListItem(self.year_select).select(False)
			self.getControl( 7 ).getSelectedItem().select(True)
			self.year_select=position
			self.updates=True
			self.search_select=False
			self.update_list()
		elif controlId ==8:
			position = self.getControl( 8).getSelectedPosition()
			self.getControl( 8 ).getListItem(self.sort_select).select(False)
			self.getControl( 8 ).getSelectedItem().select(True)
			self.sort_select=position
			self.updates=True
			self.search_select=False
			self.update_list()
		elif controlId ==9:
			position = self.getControl( 9).getSelectedPosition()
			#openWindow("info",session=self,url=self.getControl( 9 ).getListItem(position).getLabel2())
			tid=self.getControl( 9 ).getListItem(position).getLabel2()[self.getControl( 9 ).getListItem(position).getLabel2().rfind('/')+1:len(self.getControl( 9 ).getListItem(position).getLabel2())]
			self.seriesList(name=self.getControl( 9 ).getListItem(position).getLabel(),id=tid)
		elif controlId==51:
			self.searchKey()
		else:
			pass

	def onAction(self,action):
		BaseWindow.onAction(self, action)
		if action.getId()==4 and self.getFocusId()== 9 and self.search_select==False and self.main_type_list_select < 5:
			if self.getControl( 9 ).size() - self.getControl( 9 ).getSelectedPosition() <=6:
				self.page+=1
				self.updates=False
				self.update_list()
	def onFocus( self, controlId ):
		self.controlId = controlId
		if controlId==9 and self.search_select==False and self.main_type_list_select < 5:
			if self.getControl( 9 ).size() - self.getControl( 9 ).getSelectedPosition() <=6:
				self.page+=1
				self.updates=False
				self.update_list()

	def update_list(self):
		if 	self.updates:
			self.getControl( 9 ).reset()
			self.page=1
		else:
			sum = self.getControl( 9 ).getSelectedPosition() 
		post_data=[]
		if self.main_type_list_select==0:
			post_data.append('channel=movie')
		elif self.main_type_list_select==1:
			post_data.append('channel=tv')
		elif self.main_type_list_select==2:
			post_data.append('channel=documentary')
		elif self.main_type_list_select==3:
			post_data.append('channel=openclass')
		elif self.main_type_list_select==4:
			post_data.append('channel=topic')
		else:
			pass
		if self.area_select>0:
			post_data.append('area='+area[self.area_select])
		if self.category_select>0:
			post_data.append('category='+category[self.category_select])
		if self.year_select>0:
			post_data.append('year='+year[self.year_select])
		if self.sort_select>0:
			post_data.append('sort='+sort[self.sort_select][0])
		if self.page>1:
			post_data.append('page='+str(self.page))
		url = 'http://www.yyets.com/resourcelist?' + '&'.join(post_data)
		link = GetHttpData(url).replace('\r','').replace('\n','')
		soup = BeautifulSoup(link)
		data = soup.find('div',attrs={'class':'box_4 res_listview'})
		data = data.findAll('li',attrs={'class':'clearfix'})
		for item in data:
			title=item.find('strong').text.encode('UTF-8')
			img=item.find('img')['src']
			top=item.find('font',attrs={'class':'f101'}).text
			ids=item.find('a')['href']
			listitem = xbmcgui.ListItem( label=title,label2=ids,thumbnailImage=img)
			listitem.setInfo('video', { 'originaltitle':top,'tagline':ids})
			self.getControl(9).addItem( listitem )			
		if 	self.updates==False:
			self.getControl(9).selectItem(sum)
	def seriesList(self,name,id):
		if id == __addon__.getSetting('id_str'):
			vod_data = json.loads(base64.b64decode(__addon__.getSetting('data_str')))
		else:
			url = 'http://www.yyets.com/resource/' + id
			link = GetHttpData(url).replace('\r','').replace('\n','')
			pDialog = xbmcgui.DialogProgress()
			pDialog.create('人人影视-yyets', '处理数据中、请稍后...')
			soup = BeautifulSoup(link)
			pDialog.update(25, '请稍后...') 
			vod_data=[]
			vod_data.append({"title":name})
			vod_data[0]["image"]=soup.find("div",attrs={'class':'f_l_img'}).find('img')['src']
			desc=soup.find('ul',attrs={'class':'r_d_info'}).findAll('li')
			vod_data[0]["description"]=desc[len(desc)-1].div.text
			vod_data[0]["id"]=id
			tabs = soup.findAll('div',attrs={'class':'resod_tit'})
			temp=tabs[0].find('ul',attrs={'format':'all'})
			season_list=[]
			pDialog.update(50, '请稍后...') 
			for i in range(0,len(temp.contents)):
				temp2=tabs[0].find('ul',attrs={'format':'all'})
				vod_temp=soup.find('ul',attrs={'class':"resod_list",'season':temp.contents[i]['season']}).contents
				list={}
				for ccc in vod_temp:
					if list.has_key(ccc['format']) <> True:
					   list[ccc['format']]=[]
					title=ccc.find('span',attrs={'class':'a'}).contents[0]
					ed2k=ccc.find('a',attrs={'type':'ed2k'})
					if ed2k <> None:
					   list[ccc['format']].append({'title':title,'link':ed2k['href']})
				if temp.contents[i].contents[0].contents[0].encode('utf-8') == '前传':
				   title='全部'
				else:
					title=temp.contents[i].contents[0].contents[0]
				season_list.append({'id':temp.contents[i]['season'],'title':title,'link':list})
			pDialog.update(75, '请稍后...') 
			vod_data[0]["vod_link"]=[]
			vod_data[0]["vod_link"]=season_list
			__addon__.setSetting('data_str', base64.b64encode(json.dumps(vod_data)))
			__addon__.setSetting('id_str', id)
			pDialog.update(100, '请稍后...') 
			pDialog.close ()

		openWindow("info",session=self,data=vod_data)

	def update_fav(self):
		fav=json.loads(base64.b64decode(__addon__.getSetting('fav')))
		list = fav.items()
		self.getControl(9).reset()
		for item in list:
			listitem = xbmcgui.ListItem( label=item[1]['title'],label2=item[1]['id'],thumbnailImage=item[1]['img'])
			self.getControl(9).addItem( listitem )			
	
	def searchKey(self):
		kb = Keyboard('','请输入搜索内容')
		kb.doModal()
		if (kb.isConfirmed()):
			keyword = kb.getText()
			if keyword !='':
				self.search_select=True
				self.search_list(keyword)
		else: return

	def search_list(self,key):
		link = GetHttpData("http://www.yyets.com/search/index?keyword="+key+"&type=resource&order=uptime").replace('\r','').replace('\n','')
		soup = BeautifulSoup(link)
		list = soup.findAll('div',attrs={'class':'all_search_li2'})
		self.getControl( 9 ).reset()
		for item in list:
			title=item.find('strong').text.encode('UTF-8')
			img='Personal_Last-played_focus.png'
			ids=item.find('a')['href']
			listitem = xbmcgui.ListItem( label=title,label2=ids,thumbnailImage=img)
			self.getControl(9).addItem( listitem )	


class InfoWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.pageData = kwargs.get('data')
		self.resod = 0
		self.format = ''
		self.format_id = 0
		self.initialized = False
		try:
			self.fav=json.loads(base64.b64decode(__addon__.getSetting('fav')))
		except:
			self.fav={}
			__addon__.setSetting('fav', base64.b64encode(json.dumps(self.fav)))
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		self.getControl( 2 ).setLabel(self.pageData[0]['title'])
		self.getControl( 9 ).setLabel(self.pageData[0]['description'])
		self.getControl( 1 ).setImage(self.pageData[0]['image'])
		if self.fav.has_key(self.pageData[0]['id']):
			self.getControl( 120 ).setLabel("取消")
		else:
			self.getControl( 120 ).setLabel("收藏")
		self.update_resod_tit()

	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def onClick( self, controlId ):
		if controlId == 12:
			position = self.getControl( 12 ).getSelectedPosition()
			self.getControl( 12 ).getListItem(self.resod).select(False)
			self.getControl( 12 ).getSelectedItem().select(True)
			self.resod = position
			self.format_id=0
			self.update_itemTit()
		if controlId == 11:
			position = self.getControl( 11 ).getSelectedPosition()
			self.run_plugin(self.get_ed2k_playurl(self.pageData[0]['vod_link'][self.resod]['link'][self.format][position]['link'],self.pageData[0]['vod_link'][self.resod]['link'][self.format][position]['title']))
		if controlId == 10:
			position = self.getControl( 10 ).getSelectedPosition()
			self.format = self.getControl( 10 ).getListItem(position).getLabel().encode('utf-8')
			self.getControl( 10 ).getListItem(self.format_id).select(False)
			self.getControl( 10 ).getSelectedItem().select(True)
			self.format_id=position
			self.update_resod_list()
		if controlId == 120:
			if self.getControl( 120 ).getLabel()=="收藏":
				self.fav[self.pageData[0]["id"]]={'title':self.pageData[0]["title"],'id':self.pageData[0]["id"],'img':self.pageData[0]["image"]}
				__addon__.setSetting('fav', base64.b64encode(json.dumps(self.fav)))
				self.getControl( 120 ).setLabel("取消")
			else:
				del	self.fav[self.pageData[0]["id"]]
				__addon__.setSetting('fav', base64.b64encode(json.dumps(self.fav)))
				self.getControl( 120 ).setLabel("收藏")

		
	def onAction(self,action):
		BaseWindow.onAction(self, action)

	def update_itemTit( self ):
		self.getControl( 10 ).reset()
		temp =self.pageData[0]['vod_link'][self.resod]['link']
		for x in temp.keys():
			listitem = xbmcgui.ListItem( label=x) 
			self.getControl( 10 ).addItem( listitem )
		self.format = self.getControl( 10 ).getListItem(0).getLabel().encode('utf-8')
		self.getControl( 10 ).getListItem(self.format_id).select(False)
		self.getControl( 10 ).getListItem(0).select(True)
		self.update_resod_list()
	
	def update_resod_list(self):
		self.getControl( 11 ).reset()
		for i in xrange(len(self.pageData[0]['vod_link'][self.resod]['link'][self.format])):
			listitem = xbmcgui.ListItem( label=self.pageData[0]['vod_link'][self.resod]['link'][self.format][i]['title']) 
			self.getControl( 11 ).addItem( listitem )


	def update_resod_tit(self):
		self.getControl( 12 ).reset()
		for i in xrange(len(self.pageData[0]['vod_link'])):
			listitem = xbmcgui.ListItem( label=' ' + self.pageData[0]['vod_link'][i]['title']) 
			self.getControl( 12 ).addItem( listitem )
		self.setFocus( self.getControl( 12 ) )
		self.getControl( 12 ).selectItem( 0 )
		self.getControl( 12 ).getListItem(self.resod).select(False)
		self.getControl( 12 ).getSelectedItem().select(True)
		self.update_itemTit()
	
	def onFocus( self, controlId ):
		pass


	def run_plugin(self,plugin_url):
		xbmc.executebuiltin('RunPlugin(%s)' % plugin_url)                

	def create_playurl(self,pattern, **kwargs):
		name = kwargs.setdefault('name', '')
		if name:
			if isinstance(name, unicode):
				name = name.encode('utf-8')
			kwargs['name'] = urllib.quote_plus(name, '')
		return pattern.format(**kwargs)

	def get_ed2k_playurl(self,ed2k_url, name=''):  # noqa
		if ed2k_url:
			if isinstance(ed2k_url, unicode):
				ed2k_url = ed2k_url.encode('utf-8')

		return self.create_playurl(
			'plugin://script.thunder.player/ed2k/{ed2k_url}/?name={name}',
			ed2k_url=urllib.quote_plus(ed2k_url), name=name)

def openWindow(window_name,session=None,**kwargs):
		windowFile = 'yyets-media-%s.xml' % window_name
		if window_name == 'main':
			windowFile = 'yyets-media-main.xml'
			windowFilePath = os.path.join(xbmc.translatePath(__addon__.getAddonInfo('path')),'resources','skins',THEME,'720p',windowFile)
			w = MainWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME)
		elif window_name == 'info':
			w = InfoWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		else:
			return #Won't happen :)
		w.doModal()			
		del w


def GetHttpData(url):
	print "getHttpData: " + url
	pDialog = xbmcgui.DialogProgress()
	ret = pDialog.create('人人影视-yyets', '正在加载数据，请稍后······')
	opener = urllib2.build_opener(cook)
	POST = urllib2.Request('http://www.yyets.com/user/login/getCurUserTopInfo')
	Cookie_str = __addon__.getSetting('cookie_str')
	POST.add_header('Cookie', Cookie_str)
	login=json.loads(opener.open(POST).read())
	if login['status'] == 4001:
		opener = urllib2.build_opener(cook)
		POST = urllib2.Request('http://www.yyets.com/user/login/ajaxLogin',data='type=nickname&account=psptest&password=psptest&remember=1')
		login=json.loads(opener.open(POST).read())
		cookie_str=''
		for index,ccc in enumerate(cookie):
			aaa= str(ccc).split(' ')
			cookie_str=cookie_str+aaa[1]+'; '
		__addon__.setSetting('cookie_str', cookie_str)
	req = urllib2.Request(url)
	req.add_header('Cookie', __addon__.getSetting('cookie_str'))
	try:
		response = urllib2.urlopen(req)
		httpdata = response.read()
		if response.headers.get('content-encoding', None) == 'gzip':
			httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
		charset = response.headers.getparam('charset')
		response.close()
	except:
		print 'GetHttpData Error: %s' % url
		return ''
	match = re.compile('<meta http-equiv=["]?[Cc]ontent-[Tt]ype["]? content="text/html;[\s]?charset=(.+?)"').findall(httpdata)
	if len(match)>0:
		charset = match[0]
	if charset:
		charset = charset.lower()
		if (charset != 'utf-8') and (charset != 'utf8'):
			httpdata = httpdata.decode(charset, 'ignore').encode('utf8', 'ignore')
	pDialog.close()
	return httpdata

class RedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        pass
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib2.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        infourl.headers = headers
        return infourl

def GetHttpData2(url):
    opener = urllib2.build_opener(RedirectHandler)
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = opener.open(req)
        httpdata = response.headers.get('Location', None)
        response.close()
    except:
        xbmc.log( "%s: %s (%d) [%s]" % (
            "vst",
            sys.exc_info()[ 2 ].tb_frame,
            sys.exc_info()[ 2 ].tb_lineno,
            sys.exc_info()[ 1 ]
            ), level=xbmc.LOGERROR)
        return ''
    return httpdata

def get_params2(url):
    param = []
    paramstring = url[url.index('?'):len(url)]
    print paramstring
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

def playVideo(url,site,title,title2):
	data=GetHttpData("http://so.52itv.cn/v_xmlnew/"+url+".xml")
	soup = BeautifulStoneSoup(data)
	print soup
	if soup.findAll('play',attrs={'q':'3'}):
		vod_link=soup.findAll('play',attrs={'q':'3'})[0].url.text
	elif soup.findAll('play',attrs={'q':'2'}):
		vod_link=soup.findAll('play',attrs={'q':'2'})[0].url.text	
	elif soup.findAll('play',attrs={'q':'1'}):
		vod_link=soup.findAll('play',attrs={'q':'1'})[0].url.text
	else:
		vod_link=soup.findAll('play',attrs={'q':'0'})[0].url.text
	if site == 'pptv':
		temp = BeautifulStoneSoup(GetHttpData(vod_link.replace('__','%')))
		vod_link = "http://"+temp.root.server_host.text+"/"+vod_link[vod_link.rfind('/')+1:vod_link.rfind('.m')]+".m3u8?type=m3u8.web.pad&k="+temp.root.key.text
		vod_link=vod_link.replace('__','%')
	elif site == 'qiyi':
		temp = GetHttpData(vod_link)
		vod_sp = temp.split('\n')
		urls=''
		for item in vod_sp:
			if item[0:4]=='http':
				urls = GetHttpData2(item)
				break
		pargm=urls.split('/')
		pargm1=get_params2(urls)
		ukey=pargm1['key']
		uuid=pargm1['uuid']
		ip=pargm[2]
		temp=temp.replace("data.video.iqiyi.com",ip).replace("data.video.qiyi.com",ip).replace("?",'?key='+ukey+'&uuid='+uuid+"&")
		wfile = open(__cwd__+"/b.m3u8", 'w') 
		wfile.write(temp)
		wfile.close() 
		vod_link= __cwd__+"/b.m3u8"
	elif site == 'qqlive':
		temp = BeautifulStoneSoup(GetHttpData(vod_link))
		vod_link = temp.root.vd.vi.url.text
	elif site == 'weiyun':
		vod_link = vod_link.replace('&amp;','&')
	elif site == 'letv':
		vod_link = GetHttpData2(vod_link)
	else:
		pass
	listitem = xbmcgui.ListItem(title+"_"+title2)
	listitem.setInfo(type="Video", infoLabels={'Title': title+"_"+title2})
	xbmc.Player().play(vod_link, listitem, 0)


class yyetsSession:
	def __init__(self,window=None):
		self.window = window
		
	def removeCRLF(self,text):
		return " ".join(text.split())
		
	def makeAscii(self,name):
		return name.encode('ascii','replace')
	
	
		
	def closeWindow(self):
		self.window.doClose()
			
	def clearSetting(self,key):
		__addon__.setSetting(key,'')
		
	def setSetting(self,key,value):
		__addon__.setSetting(key,value and ENCODE(value) or '')
		
	def getSetting(self,key,default=None):
		setting = __addon__.getSetting(key)
		if not setting: return default
		if type(default) == type(0):
			return int(float(setting))
		elif isinstance(default,bool):
			return setting == 'true'
		return setting
	

if __name__ == '__main__':
	openWindow('main')