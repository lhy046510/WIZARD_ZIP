#! /usr/bin/env python
#coding=utf-8
import xbmc
try:
    from ChineseKeyboard import Keyboard
except ImportError:
    Keyboard = xbmc.Keyboard

def keyboard(default='', heading='', hidden=False):
    kb = Keyboard(default, heading)
    xbmc.sleep(1000)
    kb.doModal()
    if (kb.isConfirmed()):
        return kb.getText()

def refresh():
    xbmc.executebuiltin('Container.Refresh')
