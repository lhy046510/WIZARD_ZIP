#! /usr/bin/env python
# coding=utf-8
import urllib2
import json
import hashlib
from elementtree import ElementTree as etree


def get_api_data(userid=None):
    return parse_xml('http://www.hdpfans.com/live/unamenew/' + userid) if userid \
        else parse_xml('http://itv.hdpfans.com/hdpzb/hdpfans.xml')


def parse_xml(url):
    try:
        root = etree.parse(urllib2.urlopen(url))
    except:
        return

    return filter(lambda x: x['channels'], [{
        'id': class_node.get('id'),
        'name': class_node.get('classname'),
        'channels': filter(lambda x: x['tvlinks'], [{
            'id': channel_node.get('id'),
            'name': channel_node.get('name'),
            'tvlinks': [{
                'name': tv.get('source'),
                'link': transform_url(tv.get('link')),
            } for tv in channel_node.findall('tvlink')],
        } for channel_node in class_node.findall('channel')]),
    } for class_node in root.findall('class')])


def get_live_data(user_ids=[]):
    users = {}
    data = {
        'users': users,
        'class': get_api_data()
    }
    data['class_index'] = dict((c['id'], c) for c in data['class'])
    channel_index = dict((ch['id'], ch)
                         for c in data['class'] for ch in c['channels'])

    for userid in user_ids:
        user_data = get_api_data(userid)
        if user_data:
            users[userid] = user_data
            for tv_class in user_data:
                for ch in tv_class['channels']:
                    ch_id = 'u' + ch['id']
                    ch['id'] = ch_id
                    ch['diy'] = True
                    channel_index[ch_id] = ch

    data['channel_index'] = channel_index

    return data


def check_user(userid):
    return bool(get_api_data(userid))


def transform_url(url):
    if not url.startswith('http://live.hdpfans.com/'):
        return url

    return url + '/' + get_verify_code()

_verify_code = None


def get_verify_code():
    global _verify_code

    if _verify_code is None:
        tag = json.load(urllib2.urlopen('http://api.hdpfans.com/apk_api/itv_update.php'))['tag']  # noqa
        m = hashlib.md5(tag + 'mylive123')
        _verify_code = m.hexdigest()

    return _verify_code

_classid_table = {
    '10': '8',
    '11': '12',
    '12': '13',
    '13': '10',
    '14': '11',
    '15': '24',
    '16': '21',
    '17': '19',
    '18': '17',
    '19': '18',
    '20': '20',
    '21': '22',
    '22': '25',
    '23': '15',
    '24': '26',
    '25': '14',
    '26': '28',
    '27': '7',
    '28': '27',
    '29': '29',
    '3': '1',
    '30': '31',
    '31': '30',
    '32': '32',
    '37': '64',
    '39': '65',
    '4': '2',
    '41': '16',
    '42': '5',
    '43': '23',
    '6': '3',
    '7': '4',
    '8': '6',
    '9': '9'}


def transform_classid(id):
    return _classid_table.get(id, '65')
