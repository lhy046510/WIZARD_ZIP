# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import xbmc
import xbmcgui
import xbmcvfs

from util import fetch_url
import xbmcutils


CTRL_ID_BACKSPACE = 8
CTRL_ID_OK = 10
CTRL_ID_TEXT = 1
CTRL_ID_IMG = 2
CTRL_ID_REFRESH = 300

ACTION_PREVIOUS_MENU = (10, 92)


def get_captcha(url):
    win = CaptchaDialog('bdyun_captcha.xml', xbmcutils.plugin_path, imgurl=url)

    try:
        win.doModal()

        input_text = win.get_text()
        if input_text:
            return input_text

        return 'CANCEL'

    finally:
        del win


class CaptchaDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, strXMLname, strFallbackPath, defaultSkin='Default',
                 forceFallback=False, imgurl=''):
        self._imgurl = imgurl
        self.input_text = ''
        self._ok = False
        self._tmp_imgfile = 'special://temp/baidu_captcha.jpg'

    def __del__(self):
        tmp_imgfile = self._tmp_imgfile
        if xbmcvfs.exists(self._tmp_imgfile):
            try:
                xbmcvfs.delete(tmp_imgfile)
            except:
                pass

    def _download_img(self):
        imgdata = fetch_url(self._imgurl, timeout=10)
        xbmcvfs.File(self._tmp_imgfile, 'w').write(imgdata)

    def onInit(self):
        self._download_img()
        self.getControl(CTRL_ID_IMG).setImage(self._tmp_imgfile)

    def get_text(self):
        if self._ok:
            return self.input_text

    def onAction(self, action):
        if action in ACTION_PREVIOUS_MENU:
            self.close()

    def onClick(self, controlID):
        input_text = self.input_text
        xbmc.log(str(controlID))

        if CTRL_ID_OK == controlID:
            if len(self.input_text) < 4:
                xbmcgui.Dialog().ok(u'提示', '验证码必须是4位！')
                return

            self._ok = True
            self.close()

        elif input_text and CTRL_ID_BACKSPACE == controlID:
            input_text = input_text[:-1]
            self.input_text = input_text
            self.getControl(CTRL_ID_TEXT).setLabel(input_text)

        elif CTRL_ID_REFRESH == controlID:
            self._download_img()
            img_control = self.getControl(CTRL_ID_IMG)
            img_control.setImage('')
            img_control.setImage(self._tmp_imgfile)
            # self.getControl(CTRL_ID_IMG).setImage(
            #     self._imgurl + '&t=%s' % time.time())

        elif len(input_text) < 4 and (
            ord('0') <= controlID <= ord('9') or
            ord('A') <= controlID <= ord('Z')
        ):
                char = chr(controlID)
                xbmc.log(char)
                input_text += char
                self.input_text = input_text
                self.getControl(CTRL_ID_TEXT).setLabel(input_text)

    def onFocus(self, controlID):
        pass
