# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
from collections import defaultdict


def _split_uri(uri):
    protocol, _, rest = uri.partition(':')
    # 默认http协议
    if not rest:
        protocol, rest = 'http', protocol

    if not(2 <= len(protocol) <= 10):
        return None, None

    if protocol not in ('http', 'https'):
        return (protocol, None)

    domain = rest.lstrip('/').partition('/')[0]

    return protocol, domain


class ParserManager:
    _group_keys = ('domains', 'protocols')

    def __init__(self):
        self._parsers_dict = {}
        self._parsers_to_check = []
        for k in self._group_keys:
            setattr(self, '_' + k, defaultdict(list))

    def parse(self, uri, parser=None, params=None):
        if parser:
            parser = self.get_parser(parser)

        if not parser:
            parser = self.find_match_parser(uri)
            if not parser:
                return

        return parser.parse(uri, params)

    def register_parser(self, parser):
        self._parsers_dict[str(parser)] = parser

        for k in self._group_keys:
            v = getattr(parser, k, None)
            if v:
                self._register_group(parser, k, v)

                break

        if parser.check_match:
            self._register_parsers_to_check(parser)

    def find_parser(self, uri):
        protocol, domain = _split_uri(uri)

        return (self._find_parser_by_domain(domain) or
                self._find_parser_by_protocol(protocol) or
                self._find_parser_match(uri))

    def find_match_parser(self, uri):
        protocol, domain = _split_uri(uri)
        for func_data in (
            (self._find_parser_by_domain, domain),
            (self._find_parser_by_protocol, protocol)
        ):
            parsers = func_data[0](*func_data[1:])
            if parsers:
                if len(parsers) == 1:
                    return parsers[0]

                for parser in parsers:
                    if parser.match(uri):
                        return parser

                return parser

        parsers = self._find_parser_match(uri)
        return parsers and parsers[0]

    def has_parser(self, parser_name):
        return parser_name in self._parsers_dict

    def get_parser(self, parser_name):
        return self._parsers_dict.get(parser_name)

    def _find_parser_by_domain(self, domain):
        if not domain:
            return

        domains = self._domains

        while '.' in domain:
            if domain in domains:
                return domains[domain]

            domain = domain.partition('.')[-1]

    def _find_parser_by_protocol(self, protocol):
        if not protocol:
            return

        return self._protocols.get(protocol)

    def _find_parser_match(self, uri):
        if not uri:
            return

        for parser in self._parsers_to_check:
            if parser.match(uri):
                return [parser]

    def _register_group(self, parser, group_key, group_values):
        if not isinstance(group_values, (tuple, list)):
            group_values = [group_values]

        d = getattr(self, '_' + group_key)
        for v in group_values:
            d[v].append(parser)

    def _register_parsers_to_check(self, parser):
        self._parsers_to_check.append(parser)
