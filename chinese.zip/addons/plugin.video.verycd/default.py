# -*- coding: utf-8 -*-
# default.py
from __future__ import division
import urllib,urllib2,re,xbmcplugin,xbmcgui,subprocess,sys,os,os.path,xbmcaddon
import json,math
from xbmcswift2 import Plugin, CLI_MODE, xbmcaddon,ListItem
from BeautifulSoup import BeautifulSoup,Comment,BeautifulStoneSoup
try:
    from ChineseKeyboard import Keyboard
except:
    from xbmc import Keyboard  
    pass
# Plugin constants 
__addonid__ = "plugin.video.verycd"
__addon__ = xbmcaddon.Addon(id=__addonid__)
__cwd__ = __addon__.getAddonInfo('path')
plugin = Plugin()
type_list=[['update','一周新增'],['tv','电视剧'],['movie','电影'],['zongyi','综艺'],['dongman','动漫'],['edu','公开课'],['s','自定义搜索']]
options_update={"sort":{"cname":"排序","results":[{"name":"default","cname":"热门"},{"name":"update_time","cname":"最新"},{"name":"release_date","cname":"发行"},{"name":"rating","cname":"评分"},{"name":"create_time","cname":"创建"}]}}
options_tv={"kind":{"cname":"类型","results":[{"name":"","cname":"全部"},{"name":"teleplay.mainland","cname":"国产"},{"name":"teleplay.american","cname":"美剧"},{"name":"teleplay.korean","cname":"韩剧"},{"name":"teleplay.japanese","cname":"日剧"},{"name":"teleplay.hk","cname":"港剧"},{"name":"teleplay.tw","cname":"台剧"},{"name":"teleplay.others","cname":"其它"}]},"year":{"cname":"年代","results":[{"name":"","cname":"全部"},{"name":"2014","cname":"2014"},{"name":"2013","cname":"2013"},{"name":"2012","cname":"2012"},{"name":"2011","cname":"2011"},{"name":"2010","cname":"2010"},{"name":"2009","cname":"2009"},{"name":"2008","cname":"2008"},{"name":"2007","cname":"2007"},{"name":"2006","cname":"2006"},{"name":"2005","cname":"以前"}]},"update_status":{"cname":"更新","results":[{"name":"","cname":"全部"},{"name":"serialized","cname":"连载"},{"name":"end","cname":"完结"}]},"sort":{"cname":"排序","results":[{"name":"default","cname":"热门"},{"name":"update_time","cname":"最新"},{"name":"release_date","cname":"发行"},{"name":"rating","cname":"评分"},{"name":"create_time","cname":"创建"}]}}
options_movie={"country":{"cname":"地区","results":[{"name":"","cname":"全部"},{"name":"china","cname":"国产"},{"name":"hongkong","cname":"香港"},{"name":"taiwan","cname":"台湾"},{"name":"usa","cname":"美国"},{"name":"japan","cname":"日本"},{"name":"southkorea","cname":"韩国"},{"name":"others","cname":"其它"}]},"kind":{"cname":"类型","results":[{"name":"","cname":"全部"},{"name":"movie.Action","cname":"动作"},{"name":"movie.Comedy","cname":"喜剧"},{"name":"movie.Romance","cname":"爱情"},{"name":"movie.Horror","cname":"恐怖"},{"name":"movie.Drama","cname":"剧情"},{"name":"movie.War","cname":"战争"},{"name":"movie.Thriller","cname":"惊悚"},{"name":"movie.Short","cname":"短片"},{"name":"movie.Documentary","cname":"纪录"},{"name":"movie.Crime","cname":"犯罪"},{"name":"movie.Adventure","cname":"冒险"},{"name":"movie.Mystery","cname":"悬疑"},{"name":"movie.Animation","cname":"动画"},{"name":"movie.Family","cname":"家庭"},{"name":"movie.Fantasy","cname":"奇幻"},{"name":"movie.Sci-Fi","cname":"科幻"},{"name":"movie.Musical","cname":"歌舞"},{"name":"movie.Western","cname":"西部"},{"name":"movie.Music","cname":"音乐"},{"name":"movie.Biography","cname":"传记"},{"name":"movie.History","cname":"历史"},{"name":"movie.Sport","cname":"运动"},{"name":"movie.Ancient-Costume","cname":"古装"},{"name":"movie.Martial-Arts","cname":"武侠"},{"name":"movie.Opera","cname":"戏曲"},{"name":"movie.Kids","cname":"儿童"},{"name":"movie.others","cname":"其它"}]},"year":{"cname":"年代","results":[{"name":"","cname":"全部"},{"name":"2014","cname":"2014"},{"name":"2013","cname":"2013"},{"name":"2012","cname":"2012"},{"name":"2011","cname":"2011"},{"name":"2010","cname":"2010"},{"name":"2009","cname":"2009"},{"name":"2008","cname":"2008"},{"name":"2007","cname":"2007"},{"name":"2006","cname":"2006"},{"name":"2005","cname":"以前"}]},"sort":{"cname":"排序","results":[{"name":"default","cname":"热门"},{"name":"update_time","cname":"最新"},{"name":"release_date","cname":"发行"},{"name":"rating","cname":"评分"},{"name":"create_time","cname":"创建"}]}}
options_dongman={"country":{"cname":"地区","results":[{"name":"","cname":"全部"},{"name":"china","cname":"大陆"},{"name":"japan","cname":"日本"},{"name":"hongkong","cname":"香港"},{"name":"taiwan","cname":"台湾"},{"name":"usa","cname":"美国"},{"name":"others","cname":"其它"}]},"kind":{"cname":"类型","results":[{"name":"","cname":"全部"},{"name":"cartoon.Young","cname":"热血"},{"name":"cartoon.Sci-Fi","cname":"科幻"},{"name":"cartoon.Fantasy","cname":"奇幻"},{"name":"cartoon.Adventure","cname":"冒险"},{"name":"cartoon.Fight","cname":"格斗"},{"name":"cartoon.Sports","cname":"体育"},{"name":"cartoon.Campus","cname":"校园"},{"name":"cartoon.Romance","cname":"爱情"},{"name":"cartoon.BL","cname":"耽美"},{"name":"cartoon.Comedy","cname":"爆笑"},{"name":"cartoon.Detective","cname":"推理"},{"name":"cartoon.Cure","cname":"治愈"},{"name":"cartoon.Horror","cname":"恐怖"},{"name":"cartoon.Kids","cname":"儿童"}]},"year":{"cname":"年代","results":[{"name":"","cname":"全部"},{"name":"2014","cname":"2014"},{"name":"2013","cname":"2013"},{"name":"2012","cname":"2012"},{"name":"2011","cname":"2011"},{"name":"2010","cname":"2010"},{"name":"2009","cname":"2009"},{"name":"2008","cname":"2008"},{"name":"2007","cname":"2007"},{"name":"2006","cname":"2006"},{"name":"2005","cname":"以前"}]},"update_status":{"cname":"更新","results":[{"name":"","cname":"全部"},{"name":"serialized","cname":"连载"},{"name":"end","cname":"完结"}]},"sort":{"cname":"排序","results":[{"name":"default","cname":"热门"},{"name":"update_time","cname":"最新"},{"name":"release_date","cname":"发行"},{"name":"rating","cname":"评分"},{"name":"create_time","cname":"创建"}]}}
options_zhongyi={"country":{"cname":"地区","results":[{"name":"","cname":"全部"},{"name":"china","cname":"大陆"},{"name":"hongkong","cname":"香港"},{"name":"taiwan","cname":"台湾"},{"name":"usa","cname":"美国"},{"name":"japan","cname":"日本"},{"name":"southkorea","cname":"韩国"},{"name":"uk","cname":"英国"},{"name":"others","cname":"其它"}]},"kind":{"cname":"类型","results":[{"name":"","cname":"全部"},{"name":"zongyi.show","cname":"娱乐"},{"name":"zongyi.news","cname":"新闻"},{"name":"zongyi.ceremony","cname":"晚会"},{"name":"zongyi.concert","cname":"音乐"},{"name":"zongyi.newsreel","cname":"纪录"},{"name":"zongyi.sports","cname":"体育"},{"name":"zongyi.sci_edu","cname":"科教"},{"name":"zongyi.tvshow","cname":"选秀"},{"name":"zongyi.others","cname":"其它"}]},"year":{"cname":"年代","results":[{"name":"","cname":"全部"},{"name":"2014","cname":"2014"},{"name":"2013","cname":"2013"},{"name":"2012","cname":"2012"},{"name":"2011","cname":"2011"},{"name":"2010","cname":"2010"},{"name":"2009","cname":"2009"},{"name":"2008","cname":"2008"},{"name":"2007","cname":"2007"},{"name":"2006","cname":"2006"},{"name":"2005","cname":"以前"}]},"sort":{"cname":"排序","results":[{"name":"default","cname":"热门"},{"name":"update_time","cname":"最新"},{"name":"release_date","cname":"发行"},{"name":"rating","cname":"评分"},{"name":"create_time","cname":"创建"}]}}
options_edu={"country":{"cname":"地区","results":[{"name":"","cname":"全部"},{"name":"china","cname":"大陆"},{"name":"hongkong","cname":"香港"},{"name":"taiwan","cname":"台湾"},{"name":"usa","cname":"美国"},{"name":"japan","cname":"日本"},{"name":"southkorea","cname":"韩国"},{"name":"uk","cname":"英国"},{"name":"france","cname":"法国"},{"name":"thailand","cname":"泰国"},{"name":"germany","cname":"德国"},{"name":"italy","cname":"意大利"},{"name":"russia","cname":"俄罗斯"},{"name":"australia","cname":"澳大利亚"},{"name":"canada","cname":"加拿大"},{"name":"spain","cname":"西班牙"},{"name":"newzealand","cname":"新西兰"},{"name":"poland","cname":"波兰"},{"name":"denmark","cname":"丹麦"},{"name":"greece","cname":"希腊"},{"name":"ireland","cname":"爱尔兰"},{"name":"finland","cname":"芬兰"},{"name":"norway","cname":"挪威"},{"name":"iceland","cname":"冰岛"},{"name":"netherlands","cname":"荷兰"},{"name":"sweden","cname":"瑞典"},{"name":"switzerland","cname":"瑞士"},{"name":"austria","cname":"奥地利"},{"name":"hungary","cname":"匈牙利"},{"name":"portugal","cname":"葡萄牙"},{"name":"belgium","cname":"比利时"},{"name":"bulgaria","cname":"保加利亚"},{"name":"romania","cname":"罗马尼亚"},{"name":"croatia","cname":"克罗地亚"},{"name":"estonia","cname":"爱沙尼亚"},{"name":"latvia","cname":"拉脱维亚"},{"name":"czechrepublic","cname":"捷克"},{"name":"slovak","cname":"斯洛伐克"},{"name":"slovenia","cname":"斯洛文尼亚"},{"name":"lithuania","cname":"立陶宛"},{"name":"turkey","cname":"土耳其"},{"name":"yugoslavia","cname":"南斯拉夫"},{"name":"iran","cname":"伊朗"},{"name":"israel","cname":"以色列"},{"name":"palestine","cname":"巴勒斯坦"},{"name":"mongolia","cname":"蒙古"},{"name":"korea","cname":"朝鲜"},{"name":"macau","cname":"澳门"},{"name":"singapore","cname":"新加坡"},{"name":"india","cname":"印度"},{"name":"pakistan","cname":"巴基斯坦"},{"name":"philippines","cname":"菲律宾"},{"name":"malaysia","cname":"马来西亚"},{"name":"indonesia","cname":"印度尼西亚"},{"name":"vietnam","cname":"越南"},{"name":"laos","cname":"老挝"},{"name":"cambodia","cname":"柬埔寨"},{"name":"mexico","cname":"墨西哥"},{"name":"argentina","cname":"阿根廷"},{"name":"brazil","cname":"巴西"},{"name":"colombia","cname":"哥伦比亚"},{"name":"paraguay","cname":"巴拉圭"},{"name":"chile","cname":"智利"},{"name":"cuba","cname":"古巴"},{"name":"bolivia","cname":"玻利维亚"},{"name":"egypt","cname":"埃及"},{"name":"cameroon","cname":"喀麦隆"},{"name":"southafrica","cname":"南非"},{"name":"monaco","cname":"摩纳哥"},{"name":"others","cname":"其它"}]},"kind":{"cname":"类型","results":[{"name":"","cname":"全部"},{"name":"edu.literature","cname":"文学"},{"name":"edu.art","cname":"艺术"},{"name":"edu.philosophy","cname":"哲学"},{"name":"edu.history","cname":"历史"},{"name":"edu.economics","cname":"经济"},{"name":"edu.sociology","cname":"社会"},{"name":"edu.ethics","cname":"伦理"},{"name":"edu.psychology","cname":"心理"},{"name":"edu.management","cname":"管理"},{"name":"edu.computer","cname":"编程"},{"name":"edu.mathematics","cname":"数学"},{"name":"edu.physical","cname":"物理"},{"name":"edu.chemistry","cname":"化学"},{"name":"edu.biological","cname":"生物"},{"name":"edu.medicine","cname":"医学"},{"name":"edu.environment","cname":"环境"},{"name":"edu.others","cname":"其它"}]},"year":{"cname":"年代","results":[{"name":"","cname":"全部"},{"name":"2014","cname":"2014"},{"name":"2013","cname":"2013"},{"name":"2012","cname":"2012"},{"name":"2011","cname":"2011"},{"name":"2010","cname":"2010"},{"name":"2009","cname":"2009"},{"name":"2008","cname":"2008"},{"name":"2007","cname":"2007"},{"name":"2006","cname":"2006"},{"name":"2005","cname":"以前"}]},"sort":{"cname":"排序","results":[{"name":"default","cname":"热门"},{"name":"update_time","cname":"最新"},{"name":"release_date","cname":"发行"},{"name":"rating","cname":"评分"},{"name":"create_time","cname":"创建"}]}}
def GetHttpData(url):
    #UserAgent = ''
    print url
    req = urllib2.Request(url)
    #req.add_header('User-Agent', UserAgent)
    response = urllib2.urlopen(req)
    httpdata = response.read()
    if response.headers.get('content-encoding', None) == 'gzip':
        httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
    response.close()
    match = re.compile('encodingt=(.+?)"').findall(httpdata)
    if len(match)<=0:
        match = re.compile('meta charset="(.+?)"').findall(httpdata)
    if len(match)>0:
        charset = match[0].lower()
        if (charset != 'utf-8') and (charset != 'utf8'):
            httpdata = unicode(httpdata, charset).encode('utf8')
    return httpdata
class RedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        pass
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib2.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        infourl.headers = headers
        return infourl

def GetHttpData2(url):
    print url
    opener = urllib2.build_opener(RedirectHandler)
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = opener.open(req)
        httpdata = response.headers.get('Location', None)
        response.close()
    except:
        xbmc.log( "%s: %s (%d) [%s]" % (
            "vst",
            sys.exc_info()[ 2 ].tb_frame,
            sys.exc_info()[ 2 ].tb_lineno,
            sys.exc_info()[ 1 ]
            ), level=xbmc.LOGERROR)
        return ''
    return httpdata

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param    
def get_params2(url):
    param = []
    paramstring = url[url.index('?'):len(url)]
    print paramstring
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

def rootlist():
	for item in type_list:
		listitem=xbmcgui.ListItem(item[1])
		url=sys.argv[0]+"?mode="+item[0]
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_update(page,optionss):
	if optionss==None:
		link="http://www.verycd.com/api/v2/search/entries?can_play=1&catalog_range=12%2C14%2C22%2C15%2C20&count=80&is_charge=0&page="+str(page)+"&platform=android&show_options=1&sort=online_release_time"
	else:
		link="http://www.verycd.com/api/v2/search/entries?can_play=1&catalog_range=12%2C14%2C22%2C15%2C20&count=80&is_charge=0&page="+str(page)+"&platform=android&show_options=1&sort=online_release_time&"+optionss
	link=GetHttpData(link)
	rs=json.loads(link)
	maxpage="%.0f" % math.ceil(rs['total']/80)
	listitem=xbmcgui.ListItem('[COLOR FF00FF00]第'+str(page)+ '/' + str(maxpage)+'页 【[COLOR FFFF0000]点击这里筛选[/COLOR]】[/COLOR]')
	url=sys.argv[0]+"?mode=options&url=update"
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if page>1:
		listitem=xbmcgui.ListItem('上一页')
		url=sys.argv[0]+"?mode=update&page="+str(page-1)
		if optionss!=None:
			url=url+"&optionss="+urllib.quote_plus(optionss)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	for item in rs['results']:
		listitem=xbmcgui.ListItem(item['cname'],thumbnailImage="http://i-"+item['thumbnail'][0:1]+".vcimg.com/crop/"+item['thumbnail'][2:40]+"%28200x276%29/thumb.jpg")
		url=sys.argv[0]+"?mode=getplaylink&url="+str(item['id'])
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if len(rs['results'])==80:
		listitem=xbmcgui.ListItem('下一页')
		url=sys.argv[0]+"?mode=update&page="+str(page+1)
		if optionss!=None:
			url=url+"&optionss="+urllib.quote_plus(optionss)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_list(page,optionss,cat_id,mode):
	if optionss==None:
		optionss=''
	link=GetHttpData("http://www.verycd.com/api/v2/search/entries?can_play=1&catalog_id="+str(cat_id)+"&count=80&is_charge=0&page="+str(page)+"&platform=android&show_options=1&"+optionss)
	rs=json.loads(link)
	maxpage="%.0f" % math.ceil(rs['total']/80)
	listitem=xbmcgui.ListItem('[COLOR FF00FF00]第'+str(page)+ '/' + str(maxpage)+'页 【[COLOR FFFF0000]点击这里筛选[/COLOR]】[/COLOR]')
	url=sys.argv[0]+"?mode=options&url="+str(cat_id)
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if page>1:
		listitem=xbmcgui.ListItem('上一页')
		url=sys.argv[0]+"?mode="+mode+"&page="+str(page-1)
		if optionss!=None:
			url=url+"&optionss="+urllib.quote_plus(optionss)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)

	for item in rs['results']:
		listitem=xbmcgui.ListItem(item['cname'],thumbnailImage="http://i-"+item['thumbnail'][0:1]+".vcimg.com/crop/"+item['thumbnail'][2:40]+"%28200x276%29/thumb.jpg")
		url=sys.argv[0]+"?mode=getplaylink&url="+str(item['id'])
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if len(rs['results'])==80:
		listitem=xbmcgui.ListItem('下一页')
		url=sys.argv[0]+"?mode="+mode+"&page="+str(page+1)
		if optionss!=None:
			url=url+"&optionss="+urllib.quote_plus(optionss)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def s_options(url):
	op=[]
	dialog = xbmcgui.Dialog()
	if url=='update':
		options_list=options_update.items()
		for item in options_list:
			type_name=item[0]
			sel = dialog.select(item[1]['cname'], [i['cname'] for i in item[1]['results']])
			if sel >-1:
				if item[1]['results'][sel]['name']!='':
					op.append(type_name+"="+item[1]['results'][sel]['name'])
		
		u = sys.argv[0] + '?mode=update&optionss=' + urllib.quote_plus('&'.join(op))
		xbmc.executebuiltin('Container.Update(%s)' % u)
	elif url=='15':
		options_list=options_tv.items()
		for item in options_list:
			type_name=item[0]
			sel = dialog.select(item[1]['cname'], [i['cname'] for i in item[1]['results']])
			if sel >-1:
				if item[1]['results'][sel]['name']!='':
					op.append(type_name+"="+item[1]['results'][sel]['name'])
		
		u = sys.argv[0] + '?mode=tv&optionss=' + urllib.quote_plus('&'.join(op))
		xbmc.executebuiltin('Container.Update(%s)' % u)
	elif url=='14':
		options_list=options_movie.items()
		for item in options_list:
			type_name=item[0]
			sel = dialog.select(item[1]['cname'], [i['cname'] for i in item[1]['results']])
			if sel >-1:
				if item[1]['results'][sel]['name']!='':
					op.append(type_name+"="+item[1]['results'][sel]['name'])
		
		u = sys.argv[0] + '?mode=movie&optionss=' + urllib.quote_plus('&'.join(op))
		xbmc.executebuiltin('Container.Update(%s)' % u)
	elif url=='12':
		options_list=options_dongman.items()
		for item in options_list:
			type_name=item[0]
			sel = dialog.select(item[1]['cname'], [i['cname'] for i in item[1]['results']])
			if sel >-1:
				if item[1]['results'][sel]['name']!='':
					op.append(type_name+"="+item[1]['results'][sel]['name'])
		
		u = sys.argv[0] + '?mode=dongman&optionss=' + urllib.quote_plus('&'.join(op))
		xbmc.executebuiltin('Container.Update(%s)' % u)
	elif url=='20':
		options_list=options_zhongyi.items()
		for item in options_list:
			type_name=item[0]
			sel = dialog.select(item[1]['cname'], [i['cname'] for i in item[1]['results']])
			if sel >-1:
				if item[1]['results'][sel]['name']!='':
					op.append(type_name+"="+item[1]['results'][sel]['name'])
		
		u = sys.argv[0] + '?mode=zhongyi&optionss=' + urllib.quote_plus('&'.join(op))
		xbmc.executebuiltin('Container.Update(%s)' % u)
	elif url=='22':
		options_list=options_edu.items()
		for item in options_list:
			type_name=item[0]
			sel = dialog.select(item[1]['cname'], [i['cname'] for i in item[1]['results']])
			if sel >-1:
				if item[1]['results'][sel]['name']!='':
					op.append(type_name+"="+item[1]['results'][sel]['name'])
		
		u = sys.argv[0] + '?mode=edu&optionss=' + urllib.quote_plus('&'.join(op))
		xbmc.executebuiltin('Container.Update(%s)' % u)

def get_play_link(url):
	link=GetHttpData("http://www.verycd.com/api/v2/base/entry?entry_id="+url)
	rs=json.loads(link)
	for item in rs['basic']['platform']:
		listitem=xbmcgui.ListItem(item['title'].encode('UTF-8')+"[共"+str(item['count'])+"集]")
		url=sys.argv[0]+"?mode=getplaydata&url="+url+"&platforms="+item['name']+"&name="+urllib.quote_plus(rs['basic']['cname'].encode('UTF-8'))+"&counts="+str(item['count'])
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_play_data(url,platforms,name,counts):
	link=GetHttpData("http://www.verycd.com/api/v1/base/entry/playlinks?entry_id="+url+"&platform="+platforms+"&count="+counts)
	rs=json.loads(link)
	for item in rs['playlinks']['results']:
		listitem=xbmcgui.ListItem(item['title'],thumbnailImage="http://i-"+item['thumbnail'][0:1]+".vcimg.com/crop/"+item['thumbnail'][2:40]+"%28200x276%29/thumb.jpg")
		url=sys.argv[0]+"?mode=playvod&url="+urllib.quote_plus(item['uri'])+"&name="+name+"-"+item['title'].encode('UTF-8')
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_video(url,name):
	link=GetHttpData("http://www.verycd.com/api/v2/base/playlink/get_playinfo?platform=android&url="+url+"&version=2")
	rs=json.loads(link)
	vod_link=rs['video_url']
	if rs['platform']=='qiyi':
		temp = GetHttpData(vod_link)
		vod_sp = temp.split('\n')
		urls=''
		for item in vod_sp:
			if item[0:4]=='http':
				urls = GetHttpData2(item)
				break
		pargm=urls.split('/')
		pargm1=get_params2(urls)
		ukey=pargm1['key']
		uuid=pargm1['uuid']
		ip=pargm[2]
		temp=temp.replace("data.video.iqiyi.com",ip).replace("data.video.qiyi.com",ip).replace("?",'?key='+ukey+'&uuid='+uuid+"&")
		wfile = open(__cwd__+"/b.m3u8", 'w') 
		wfile.write(temp)
		wfile.close() 
		vod_link= __cwd__+"/b.m3u8"
	else:
		pass
	listitem = xbmcgui.ListItem(name)
	listitem.setInfo(type="Video", infoLabels={'Title': name})
	xbmc.Player().play(vod_link.replace('&amp;','&'), listitem, 0)
	
def searchKey():
    kb = Keyboard('','请输入搜索内容,可用首拼字母搜索')
    kb.doModal()
    if (kb.isConfirmed()):
        keyword = kb.getText()
        if keyword !='':
			u=sys.argv[0]+"?mode=search&url="+urllib.quote_plus(keyword)
			xbmc.executebuiltin('Container.Update(%s)' % u)
    else: return

def searchs(url,page):
	key=url
	link=GetHttpData("http://www.verycd.com/api/v2/search/entries?can_play=1&count=80&is_charge=1&kw="+str(key)+"&page="+str(page)+"&platform=android")
	rs=json.loads(link)
	maxpage="%.0f" % math.ceil(rs['total']/80)
	listitem=xbmcgui.ListItem('[COLOR FF00FF00]第'+str(page)+ '/' + str(maxpage)+'页 [/COLOR]')
	url=''
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, False)
	if page>1:
		listitem=xbmcgui.ListItem('上一页')
		url=sys.argv[0]+"?mode=search&page="+str(page-1)+"&url="+str(key)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)

	for item in rs['results']:
		listitem=xbmcgui.ListItem(item['cname'],thumbnailImage="http://i-"+item['thumbnail'][0:1]+".vcimg.com/crop/"+item['thumbnail'][2:40]+"%28200x276%29/thumb.jpg")
		url=sys.argv[0]+"?mode=getplaylink&url="+str(item['id'])
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if len(rs['results'])==80:
		listitem=xbmcgui.ListItem('下一页')
		url=sys.argv[0]+"?mode=search&page="+str(page+1)+"&url="+str(key)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

params = get_params()
mode = None
url = None
name=None
page = 1
platforms=None
optionss=None
counts=None
try:
    mode = params["mode"]
except:
    pass
try:
    page = int(params["page"])
except:
    pass
try:
    url =urllib.unquote_plus( params["url"])
except:
    pass
try:
    name =urllib.unquote_plus( params["name"])
except:
    pass
try:
    platforms =urllib.unquote_plus( params["platforms"])
except:
    pass
try:
    optionss =urllib.unquote_plus( params["optionss"])
except:
    pass
try:
    counts =urllib.unquote_plus( params["counts"])
except:
    pass
if mode == None:
	rootlist()
elif mode=='update':
	get_update(page,optionss)
elif mode=='getplaylink':
	get_play_link(url)
elif mode=='getplaydata':
	get_play_data(url,platforms,name,counts)
elif mode=='playvod':
	play_video(url,name)
elif mode=='options':
	s_options(url)
elif mode=='tv':
	get_list(page,optionss,15,mode)
elif mode=='movie':
	get_list(page,optionss,14,mode)
elif mode=='dongman':
	get_list(page,optionss,12,mode)
elif mode=='zongyi':
	get_list(page,optionss,20,mode)
elif mode=='edu':
	get_list(page,optionss,22,mode)
elif mode=='s':
	searchKey()
elif mode=='search':
	searchs(url,page)