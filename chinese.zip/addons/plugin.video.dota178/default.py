﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, urllib2, urllib, re, string, sys, os, gzip, StringIO, simplejson

########################################################################
# 优酷视频(YouKu) by taxigps, 2011
# Version 2.1.2 2012-08-20 (cmeng)
# - add multi-pages selection for easy access
# - add segment numbering in playlist for reference

# See changelog.txt for previous history
########################################################################
# Plugin constants 
__addonname__ = "Dota视频站(178)"
__addonid__ = "plugin.video.dota178"
__addon__ = xbmcaddon.Addon(id=__addonid__)
__addonicon__ = os.path.join( __addon__.getAddonInfo('path'), 'icon.png' )

UserAgent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
MENU_LIST = [['Dota集锦视频',[['video/highlights','全部'], ['video/wodota','WODOTA'], ['video/douma','Douma'], ['video/iyoupai','爱游派'], ['video/gzonetv','GzoneTV'], ['video/tuntun','吞吞映像']]],
['Dota解说视频', [['video/jieshuo','全部'], ['pis/','PIS'], ['sjq/','鼠大王'], ['820/','820'], ['2009/','2009伍声'], ['haitao/','海涛'], ['jingling/','精灵'], ['video/jieshuo/aotuman','凹凸曼'], ['video/jieshuo/shiyi','西十一'], 
['zsmj/','ZSMJ'], ['video/jieshuo/danche','单车'], ['video/jieshuo/xiaoman','小满'], ['video/jieshuo/sashen','满楼水平'], ['video/jieshuo/ksssssss','Ksssssss'], ['video/jieshuo/laodang','老党'],
['kevin/','凯文'], ['video/jieshuo/qingshu','情书'], ['niuwa/','牛蛙'], ['video/jieshuo/sky','SKY'], ['video/jieshuo/kuangshi','小爷不狂'], ['video/jieshuo/achuan','屠夫阿川'],
['video/jieshuo/shahei','傻黑'], ['wuer/','舞儿'], ['video/jieshuo/qiqi','七七'], ['video/jieshuo/yoyo','莜莜'], ['lengleng/','冷冷'], ['video/jieshuo/momo','沫沫'],
['video/jieshuo/yuki','Yuki'], ['video/jieshuo/mirana','Mirana'], ['video/jieshuo/miss','Miss']]],
['DotA战队视频', [['video/DK','DK战队'], ['video/LGD','LGD战队'], ['video/ig','iG战队'], ['video/tongfu','TongFu战队'], ['video/WE','WE战队'], ['video/tyloo','Tyloo战队'], ['video/EHOME','EHOME战队']]],
['Dota比赛视频', [['video/bisai','全部'], ['video/WCG','WCG视频'], ['video/ace','ACE视频'], ['video/hfgl','HFGL视频'], ['video/Gleague','G联赛视频'], ['video/G-1','G-1视频'], ['video/SW','StarsWar']]],
['Dota教学视频', [['video/Education','全部'], ['116744687890','Pis第一视角'], ['video/jieshuo/sjq','鼠大王第一视角'], ['72056649073','海涛教你打DOTA'], ['97698470323','09dota提高班'], ['123143726351','流言终结者'], ['116744710002','DotA回忆录'], ['72053342855','第一视角教学']]],
['DotA搞笑视频', [['video/guai','全部'], ['95555290371','蛋疼集锦'], ['video/wodota/funny10','funny10'], ['95559590176','女友联盟'], ['75938472686','D.7.DOTA']]],
['DotA影音视频', [['video/yingyin','全部'], ['video/music','音乐'], ['video/movie','电影']]],
['DotA最新视频', [['65233028369','全部']]]]
RES_LIST = ['normal', 'high', 'super']

def GetHttpData(url):
    print "getHttpData: " + url
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = urllib2.urlopen(req)
        httpdata = response.read()
        if response.headers.get('content-encoding', None) == 'gzip':
            httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
        charset = response.headers.getparam('charset')
        response.close()
    except:
        print 'GetHttpData Error: %s' % url
        return ''
    match = re.compile('<meta http-equiv=["]?[Cc]ontent-[Tt]ype["]? content="text/html;[\s]?charset=(.+?)"').findall(httpdata)
    if len(match)>0:
        charset = match[0]
    if charset:
        charset = charset.lower()
        if (charset != 'utf-8') and (charset != 'utf8'):
            httpdata = httpdata.decode(charset, 'ignore').encode('utf8', 'ignore')
    return httpdata

def searchDict(dlist,idx):
    for i in range(0,len(dlist)):
        if dlist[i][0] == idx:
            return dlist[i][1]
    return ''


def rootList1():
    list = [x[0] for x in MENU_LIST]
    totalItems = len(list)
    for name in list:
        u = sys.argv[0]+"?mode=1&name="+urllib.quote_plus(name)
        li = xbmcgui.ListItem(name)
        xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)
    u = sys.argv[0]+"?mode=5"
    li = xbmcgui.ListItem('最热视频排行')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
def rootList():
    link = GetHttpData('http://dota.178.com/video/')
    match0 = re.compile('<div class="nav">(.+?)<!--nav-->', re.DOTALL).search(link)
    match = re.compile('<li><a href="http://dota.178.com/list/video/([^\.]+)\.html"[^>]+>(.+?)</a></li>').findall(match0.group(1))
    totalItems = len(match)
    for path, name in match:
        u = sys.argv[0]+"?mode=1&name="+urllib.quote_plus(name)+"&id="+urllib.quote_plus(path)+"&cat="+urllib.quote_plus('不限')+"&area="+urllib.quote_plus('不限')+"&year="+urllib.quote_plus('不限')+"&order="+urllib.quote_plus('7')
        li = xbmcgui.ListItem(name)
        xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def departList(id):
	url = 'http://dota.178.com/video/'+id
	link = GetHttpData(url)
	match = re.compile('<h2><span class="sign-1"></span><a class="more" title="(.+?)" href="http://dota\.178\.com/list/(.+?)\.html">更多作品&gt;&gt;</a>(.+?)</h2>', re.DOTALL).findall(link)
	totalItems =len(match)
	for title,uid,hh in match:
		li = xbmcgui.ListItem( title, iconImage = '', thumbnailImage = '')
		u = sys.argv[0]+"?mode=4&id="+urllib.quote_plus(uid)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, True, totalItems)      
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def getRank():
    url = 'http://dota.178.com/public/atcount/dota_v.js'
    link = GetHttpData(url)
    link = link.replace('f_dota_v(','')
    link = link.replace(');','')
    objectRank = simplejson.loads(link)
    dialog = xbmcgui.Dialog()
    sel = dialog.select('选择分类', ['每月排行','每周排行','每日排行'])
    if sel == 0:
        id ='month'
    elif sel == 1:
        id ='week'
    elif sel == 2:
        id ='day'
    else:
        return
    print objectRank[id]
    for i in range(len(objectRank[id])):
        li = xbmcgui.ListItem( objectRank[id][i]['title'], iconImage = '', thumbnailImage = '')
        u = sys.argv[0] +"?mode=2&name="+objectRank[id][i]['title']+"&thumb=&id="+objectRank[id][i]['url']+"&res="+str(2)
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False, len(objectRank[id]))
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
def progList(id,page):
    url = 'http://dota.178.com/list/' + id

    if page and page != '1':
        url = url + '_' + page
        currpage = int(page)
    else:
        currpage = 1
    url += '.html'
    link = GetHttpData(url).replace('\n','').replace('\r','')
    
    matchp = re.compile('<div class="page">(.+?)</div>', re.DOTALL).findall(link)
    if len(matchp):
        match1 = re.compile('<a.+?>([0-9]+)</a>', re.DOTALL).findall(matchp[0])
        totalpages = int(match1[len(match1)-1][0])
    else:
        totalpages = 1   
    #for http://dota.178.com/list/video/highlights.html
    match = re.compile('<dt><a class="imgs" href="(.+?)" title="(.+?)"><span></span>  <p  style="background-image: url\(\'(.*?)\'\);"><strong>(.+?)</strong></p><em>.+?</em></a></dt>', re.DOTALL).findall(link)
    print len(match)
    if len(match) == 0:
        match = re.compile('<dt><a class="imgs" href="(.+?)" title="(.+?)"><span></span>  <p  style="background-image: url\(\'(.*?)\'\);">(.*?)</p><em>.+?</em></a></dt>', re.DOTALL).findall(link)
    totalItems = len(match) + 1
    if currpage > 1: totalItems = totalItems + 1
    if currpage < totalpages: totalItems = totalItems + 1
    
    for url,title,picurl,duration in match:
        li = xbmcgui.ListItem( title + "  " + duration, iconImage = '', thumbnailImage = picurl)
        u = sys.argv[0] +"?mode=2&name="+urllib.quote_plus(title)+"&id="+urllib.quote_plus(url)+"&thumb="+urllib.quote_plus(picurl)+"&res="+str(2)
        #li.setInfo(type = "Video", infoLabels = {"Title":p_name, "Director":p_director, "Genre":p_genre, "Plot":p_plot, "Year":p_year, "Cast":p_cast, "Tagline":p_tagline})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False, totalItems)
        
    # Fetch and build user selectable page number 
    if len(matchp): matchp1 = re.compile('<a.+?>([0-9]+)</a>', re.DOTALL).findall(matchp[0])
    if len(matchp1):
        plist=[]
        for num in matchp1:
            if num not in plist and int(num) != currpage:
                plist.append(num)
                li = xbmcgui.ListItem("... 第" + num + "页")
                u = sys.argv[0]+"?mode=4&id="+urllib.quote_plus(id)+"&page="+str(num)
                xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, True, totalItems)          
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def getMovie(name,id,thumb,res):
    id = id.replace("dota.178.com","178.v.playradio.cn")
    link = GetHttpData(id)
    match = re.compile('src="http://player.youku.com/player.php/sid/(.+?)/', re.DOTALL).search(link)
    if match:
        url = 'http://v.youku.com/v_show/id_' + match.group(1)
        #sel = dialog.select('选择分类', ['FLV','M3U8'])
        #if sel == 0:
        PlayVideo(name, url, thumb, res)
        #elif sel == 1:
            #PlayVideoM3U8(name, match.group(1), thumb, res)
        

def PlayVideoM3U8(name,vid,thumb,res):
    res_limit = int(__addon__.getSetting('movie_res'))
    if res > res_limit:
        res = res_limit
		
    m3uList = 'http://v.youku.com/player/getRealM3U8/vid/' + vid + '/type/hd2/v.m3u8'
    playlist=xbmc.PlayList(1)
    playlist.clear()
    listitem=xbmcgui.ListItem(name,thumbnailImage=thumb)
    playlist.add(m3uList, listitem)
    xbmc.Player().play(playlist)

def PlayVideo(name,url,thumb,res):
    res_limit = int(__addon__.getSetting('movie_res'))
    if res > res_limit:
        res = res_limit
    link = GetHttpData("http://www.flvcd.com/parse.php?kw="+url+"&format="+RES_LIST[res])
    match = re.compile('"(http://f.youku.com/player/getFlvPath/.+?)" target="_blank"').findall(link)
    if len(match)>0:
        playlist=xbmc.PlayList(1)
        playlist.clear()
        # for i in range(0,len(match)):
            # title = name+" 第"+str(i+1)+"/"+str(len(match))+"节"
            # listitem=xbmcgui.ListItem(title,thumbnailImage=thumb)
            # listitem.setInfo(type="Video",infoLabels={"Title":title})
            # playlist.add(match[i], listitem)
        # xbmc.Player().play(playlist)
        stackurl = 'stack://' 
        # for i in range(0,len(match)):
        stackurl += ' , '.join(match)
        print len(match)
        # stackurl = stackurl[0:len(stackurl) -3]
        print stackurl
        xbmc.Player().play(stackurl)
    else:
        if link.find('该视频为加密视频')>0:
            dialog = xbmcgui.Dialog()
            ok = dialog.ok(__addonname__, '无法播放：该视频为加密视频')
        elif link.find('解析失败，请确认视频是否被删除')>0:
            dialog = xbmcgui.Dialog()
            ok = dialog.ok(__addonname__, '无法播放：该视频或为收费节目')


def selectChildType(name):
    typeMenu = searchDict(MENU_LIST,name)
    typeList = [x[1] for x in typeMenu]
    dialog = xbmcgui.Dialog()
    sel = dialog.select('选择分类', typeList)
    if sel != -1:
        id = typeMenu[sel][0]
        if id.endswith('/'):
	        departList(id)
        else:
            progList(id,None)
    
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

params = get_params()
mode = None
name = None
id = None
page = None
url = None
thumb = None
res = 0

try:
    res = int(params["res"])
except:
    pass
try:
    thumb = urllib.unquote_plus(params["thumb"])
except:
    pass
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    page = urllib.unquote_plus(params["page"])
except:
    pass
try:
    id = urllib.unquote_plus(params["id"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

if mode == None:
    rootList1()
elif mode == 1:
    selectChildType(name)
elif mode == 2:
    getMovie(name,id,thumb,res)
elif mode == 4:
    progList(id,page)
elif mode == 5:
    getRank()
elif mode == 10:
    PlayVideo(name,url,thumb,res)

