# -*- coding: utf-8 -*-
# default.py
# HDPfans Live TV

import urllib,urllib2,re,xbmcplugin,xbmcgui,subprocess,sys,os,os.path,xbmcaddon
import xml.dom.minidom

# Plugin constants 
__addonid__ = "plugin.video.hdpmytv"
__addon__ = xbmcaddon.Addon(id=__addonid__)
__addonpath__ = xbmc.translatePath(__addon__.getAddonInfo('path'))
ACCOUNT_PATH = xbmc.translatePath(os.path.join(__addonpath__,'account.dat'))
API='http://www.hdpfans.com/live/unamenew/'

def GetHttpData(url):
	req = urllib2.Request(url)
	response = urllib2.urlopen(req)
	httpdata = response.read()
	if response.headers.get('content-encoding', None) == 'gzip':
		httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
	response.close()
	return httpdata

def buildRoot():
	account = None
	if os.path.isfile(ACCOUNT_PATH) == True:
		f = open(ACCOUNT_PATH, 'r')
		for line in f:
			account = line
		f.close()
	if account != None:
		url = API + urllib.quote_plus(account.encode('utf-8'))
		mylist = GetHttpData(url)
		match = re.compile('xml version').findall(mylist)
		if len(match) > 0:
			doc = xml.dom.minidom.parseString(mylist)  
			root = doc.documentElement  
			nodes= root.getElementsByTagName('class')  
			link=sys.argv[0]+'?mode=3'
			listitem=xbmcgui.ListItem('当前帐号:[COLOR FF00FF00]' + account + '[/COLOR] 点击[COLOR FFFF0000]这里[/COLOR]修改用户名或者UID')		
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), link, listitem, True)
			for node in nodes:
				name=node.getAttribute('classname')
				link=sys.argv[0]+'?id='+node.getAttribute('id') + '&mode=1'
				listitem=xbmcgui.ListItem(name)
				xbmcplugin.addDirectoryItem(int(sys.argv[1]), link, listitem, True)
			xbmcplugin.endOfDirectory(int(sys.argv[1]))
		else:
			listitem=xbmcgui.ListItem('帐号:[COLOR FF00FF00]'+ account + '[/COLOR] 没有收藏任何直播数据，点击[COLOR FFFF0000]这里[/COLOR]更换帐号')		
			link=sys.argv[0]+'?mode=3'
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), link, listitem, True)
			xbmcplugin.endOfDirectory(int(sys.argv[1]))		
	else:
		listitem=xbmcgui.ListItem('点击[COLOR FFFF0000]这里[/COLOR]输入您在HDPfans.com的用户名或者UID来绑定您的私有直播数据')		
		link=sys.argv[0]+'?mode=3'
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), link, listitem, True)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		
def inputAccount():
	keyboard = xbmc.Keyboard('','请输入您在hdpfans.com的用户名或者UID')
	xbmc.sleep(1000)
	keyboard.doModal()
	if (keyboard.isConfirmed()):
		keyword = keyboard.getText()
		f = open(ACCOUNT_PATH, 'w')
		f.write(keyword)
		f.close()
	buildRoot()

def buildChannel(id):
	f = open(ACCOUNT_PATH, 'r')
	for line in f:
		account = line
	f.close()
	url = API + urllib.quote_plus(account.encode('utf-8'))
	mylist = GetHttpData(url)
	doc = xml.dom.minidom.parseString(mylist)  
	root = doc.documentElement  
	nodes= root.getElementsByTagName('class')  
	for node in nodes:
		if node.getAttribute('id') == id:
			channels=node.getElementsByTagName('channel') 
			for channel in channels:			
				name=channel.getAttribute('name')
				link=sys.argv[0]+'?id='+channel.getAttribute('id') + '&mode=2'
				listitem=xbmcgui.ListItem(name)
				xbmcplugin.addDirectoryItem(int(sys.argv[1]), link, listitem, False)
			break
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def performChange(id):
	f = open(ACCOUNT_PATH, 'r')
	for line in f:
		account = line
	f.close()
	url = API + urllib.quote_plus(account.encode('utf-8'))
	mylist = GetHttpData(url)
	doc = xml.dom.minidom.parseString(mylist)  
	root = doc.documentElement  
	nodes= root.getElementsByTagName('channel')
	for node in nodes:
		if node.getAttribute('id') == id:
			tvlinks =node.getElementsByTagName('tvlink') 
			names=[]
			links=[]
			for tvlink in tvlinks:
				names.append(tvlink.getAttribute('source'))
				links.append(tvlink.getAttribute('link'))
			break;			
	dialog = xbmcgui.Dialog()
	sel = dialog.select('选择信号源', names)
	url=links[sel]
	xbmc.Player().play(url)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param	

	
params = get_params()
mode = None
id = None

try:
	id = params["id"]
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass


if mode == None:
	buildRoot()
elif mode == 1:
	buildChannel(id)
elif mode == 2:
	performChange(id)
elif mode == 3:
	inputAccount()
	
