﻿# -*- coding: utf-8 -*-
from xbmcswift2 import Plugin, CLI_MODE, xbmcaddon,ListItem
import xbmcgui
import urllib2, urllib, re, string, sys, os, gzip, StringIO, json
#import urlresolvercn
from urlparse import parse_qsl
from resources.lib.iqiyitv import IqiyiItv
try:
    from ChineseKeyboard import Keyboard
except:
    from xbmc import Keyboard
    pass

#VIEWTYPE ID 
#陈列     501
#上档     57
#海报     510
#横向     503
#封面墙   500
    
plugin = Plugin()

PAGE_SIZE = 200

iqiyiAPI = IqiyiItv()

@plugin.route('/')
def index():

    return [{
        'label': u'最新更新','path': plugin.url_for('getList',typeId=10001,tagid=0)
    },{
        'label': u'最新电影','path': plugin.url_for('getList',typeId=1,tagid=103)
    },{
        'label': u'最新电视剧','path': plugin.url_for('getList',typeId=1,tagid=105)
    },{
        'label': u'最新综艺','path': plugin.url_for('getList',typeId=61,tagid=20696)
    },{
        'label': u'最新娱乐','path': plugin.url_for('getList',typeId=7,tagid=118)
    },{
        'label': u'最新动漫','path': plugin.url_for('getList',typeId=4,tagid=450)
    },{
        'label': u'最新搞笑','path': plugin.url_for('getList',typeId=18,tagid=4053)
    },{
        'label': u'日本电影','path': plugin.url_for('getList',typeId=1,tagid=450)
    }]


@plugin.route('/getList/<typeId>/<tagid>/')
def getList(typeId,tagid):
    data = iqiyiAPI.getAlbumList(typeId,1,PAGE_SIZE,tagid)
    items = build_items(data)
    return plugin.finish(items,view_mode=55)
 
@plugin.route('/playvideo/<tvId>/<albumId>/<res>/')
def play_video(tvId,albumId,res):
    m3u8 = iqiyiAPI.mplay(tvId,albumId,res)
    plugin.set_resolved_url(m3u8)
 
def build_items(data):
    items =[]
    for video in data.get('data'):
        tvId = video.get('tvId')
        albumId = video.get('albumId')
        name = video.get('albumName')
        cover = video.get('albumTvPic')
        fanart = video.get('albumPic')
        plot = video.get('albumDesc') #简介
        score = video.get('albumName') #评分
        issuetime = video.get('issueTime') #发行时间
        length = video.get('playLength') #时长
        
        genre = video.get('tag') #类型、流派
        
        director = video.get('directors') #导演
        
        actors = video.get('actors',"") #演员
        
        resStr = video.get('streamVer') #分辨率
        
        if '4' in resStr:
            res = 4
        elif '2' in resStr:
            res = 2
        else:
            res = 1
        
        showLabel = name 
        print issuetime
        plugin.set_content('movies')
        item = ListItem(showLabel, "", "", fanart, plugin.url_for('play_video',tvId=tvId,albumId=albumId,res =res))
        item.set_is_playable( True);
        item.set_info('video', {
            'title':name,
            'tvshowtitle':name,
            'rating':score,
            'year':issuetime[0:4],
            'director':director,
            'plot':plot,
            'genre':genre,
            'cast':actors.split(','),
            'episode':"0",
            'duration':length/60.0
        })
        items.append(item)
    return items
    

    
    
@plugin.route('/recommand/<typeid>/<viewtype>',options={'viewtype':'510'})
def recommand(typeid,viewtype):
    #http://www.go3c.tv:8062/go3cci/recommvideo.api?termid=1

    url = API_BASE + "/recommvideo.api?termid="+ str(TERMID)  
    items =[]
    httpdata =GetHttpData(url)
    data = json.loads(httpdata)
    if not data:
        plugin.notify("获取数据出错")
        return
    typedata = None
    for type in data:   
        if str(type.get("typeID")) == str(typeid):
            typedata = type

    for video in typedata.get('recommendedVideos'):
        colid = video.get("columnID")
        plugin.set_content('movies')
        images =  video.get('images')
        icon =''
        fanart =''
        for image in images:
            if image.get('imageID') == 102: #图标
                icon = image.get('imageURL')
            elif image.get('imageID') == 111: #海报
                fanart = image.get('imageURL')
        if colid == 5: #movie 
            item = ListItem(video.get('title'), video.get('subtitle'), "", icon, plugin.url_for('play_video',id=video.get('videoID')))
            item.set_is_playable(True)
            plugin.set_content('movies')
        elif colid == 4 or colid == 3: #tvshowes
            tvtitle = video.get('title') + u"  更新到{0}集".format(video.get('latestEpisodeNum'))
            item = ListItem(tvtitle, video.get('subtitle'), "", icon, plugin.url_for('getepisodes',id=video.get('videoID')))
            plugin.set_content('movies')
        elif colid == 9:  #music
            plugin.set_content('albums')
            item = ListItem(video.get('title'), video.get('subtitle'), "", icon, plugin.url_for('getepisodes',id=video.get('videoID')))
        imageURL = ""
        if video.get('imageURL'):
            imageURL = video.get('imageURL')
        item.set_property("Fanart_Image", fanart)
        
        items.append(item)
        
        #xbmcgui.Window(10000).setProperty('LiveTV_BACKGROUND', imageURL)
    print "ITEM count::" + str(len(items))
    return plugin.finish(items,view_mode=int(viewtype))


    
@plugin.route('/videodetails/<id>')
def videodetails(id):
    url = API_BASE + "/video.api?m=videodetails&vid="+str(id)+"&termid=" + str(TERMID)
    items =[]
    httpdata =GetHttpData(url)
    coldata = json.loads(httpdata)

    for source in coldata.get('episodeInfo'):
        name = source.get('name') + u"更新到{0}集，共有{1}集".format(source.get('total') ,source.get('max'))
        item = ListItem(name, name, "", source.get('iconUrl'), plugin.url_for('getepisodes',id=id,sourceid=source.get('sourceID')))
        items.append(item)

    return items

@plugin.route('/getepisodes/<id>')
def getepisodes(id):
    url = API_BASE + "/video.api?m=videodetails&vid="+str(id)+"&termid=" + str(TERMID)  #http://www.go3c.org:8062/go3cci/video.api?m=getepisodes&vid=355977&sourceid=14&c=200&termid=4
    items =[]
    httpdata =GetHttpData(url)
    episodeDetail = json.loads(httpdata)
    lastestEp = 0
    chooseSourceID = 0
    start = None
    end =None
    colid =episodeDetail.get("columnID")
    for source in episodeDetail.get('episodeInfo'):
        if lastestEp < source.get('total'):
            #if colid ==3 and source.get('sourceID') == 13:
                #continue
            lastestEp = source.get('total')
            chooseSourceID = source.get('sourceID')
            start = source.get('min')
            end = source.get('max')
    if chooseSourceID ==0:
        return
    sort = 0
    if colid ==3:
        sort = 1
    url = API_BASE + "/video.api?m=getepisodes&vid="+str(id)+"&sourceid=" + str(chooseSourceID) + "&start=" + str(start)+ "&end=" + str(end)+ "&c=200&desc=" + str(sort) + "&termid=" + str(TERMID)
    items =[]
    httpdata =GetHttpData(url)
    coldata = json.loads(httpdata)

    for episode in coldata:
        item = ListItem(episode.get('name'), episode.get('name'), "", episode.get('imageURL'), plugin.url_for('play_video',id=episode.get('ID')))
        actors = []
        for actor in episodeDetail.get("actors"):
            actors.append(actor.get("actorName"))
        item.set_is_playable( True);
        item.set_info('video', {
            'title':episode.get('name'),
            'tvshowtitle':episode.get('name'),
            'rating':episodeDetail.get('avgRating'),
            'year':episodeDetail.get('yearReleased'),
            'director':episodeDetail.get("director"),
            'plot':episodeDetail.get("longDescription"),
            'genre':episodeDetail.get("director"),
            'cast':actors,
            'episode':episode.get("episodeNumber"),
        })
        item.set_property('actor1', 'name of first actor')
        items.append(item)
    return plugin.finish(items, view_mode=519)

@plugin.route('/search1/')
def search():
    kb = Keyboard('','请输入搜索内容')
    xbmc.sleep( 1500 )
    kb.doModal()
    keyword = kb.getText()
    if keyword !='':
        return search_video2(keyword)
    print keyword

@plugin.route('/search/<keyword>')
def search_video2(keyword):
    url = API_BASE + "/search.api?m=search&keyword=" +keyword+ "&termid=" + str(TERMID) #http://www.go3c.org:8062/go3cci/system.api?m=getkey
    httpdata = GetHttpData(url)
    data = json.loads(httpdata)
    items = []
    item = ListItem('搜索:'+ keyword + '【[COLOR FFFF0000]点此输入关键字搜索[/COLOR]】', '', "", '', plugin.url_for('search'))
    items.append(item)

    for entity in data:
        item = ListItem(entity['name'], entity['description'], "", entity.get("imageURL"), plugin.url_for('play_video',id=entity.get('ID')))
        item.set_is_playable(True);
        items.append(item)
    return items
if __name__ == '__main__':
    plugin.run()