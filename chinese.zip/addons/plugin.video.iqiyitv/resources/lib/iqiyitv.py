# -*- coding: utf-8 -*-

import urllib2, urllib, re, gzip, StringIO, json,base64
from urlparse import parse_qsl
  

def GetHttpData(url,head=None):
    print "getHttpData: " + url
    req = urllib2.Request(url)
    if head:
        for key in head:
            req.add_header(key,head[key])
    try:
        response = urllib2.urlopen(req)
        httpdata = response.read()
        if response.headers.get('content-encoding', None) == 'gzip':
            httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
        charset = response.headers.getparam('charset')
        response.close()
    except:
        print 'GetHttpData Error: %s' % url
        return ''
    match = re.compile('<meta http-equiv=["]?[Cc]ontent-[Tt]ype["]? content="text/html;[\s]?charset=(.+?)"').findall(httpdata)
    if len(match)>0:
        charset = match[0]
    if charset:
        charset = charset.lower()
        if (charset != 'utf-8') and (charset != 'utf8'):
            httpdata = httpdata.decode(charset, 'ignore').encode('utf8', 'ignore')
    return httpdata


class IqiyiItv():
    apikey = 'ba8603be0d7563afcfaa8c345fbf5535'
    token = 'QDEwMTc3NDQ5NGZjNTgxMTY0OjE6MTM5OTQ1NTMxMDo5NmJiOTUxMmMwYTZhZTlhMzIzYjI1NDkwZjhkNjM0Ng=='
    
    head = {'User-Agent':'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)',
            'Itv-userToken':token}

    def __init__(self):
        pass
        
    '''
    login function  NOT work
    '''
    def login(self):
        url ='http://data.itv.iqiyi.com/itv/userLogin/{apiKey}/0'.format(apiKey = self.apikey)
        data = GetHttpData(url,self.head)
        print data
        
    def getAlbumVideo(self,albumId):
        url = 'http://data.itv.iqiyi.com/itv/albumVideo/{albumId}/{apiKey}/0'.format(albumId=albumId,apiKey = self.apikey) #http://data.itv.iqiyi.com/itv/albumVideo/2087132/ba8603be0d7563afcfaa8c345fbf5535/0
        data = GetHttpData(url)
        print data
        
    def getChnList(self):
        url = 'http://data.itv.iqiyi.com/itv/chnList/{apiKey}/0/0'.format(apiKey = self.apikey)
        data = json.loads(GetHttpData(url))
        return data
        
    
    def getAlbumList(self,typeId,page,pageSize,tagid):
        url = 'http://data.itv.iqiyi.com/itv/albumList/{apiKey}/2/{typeId}/{pageNo}/{pageSize}/{tagId}'.format(
            apiKey = self.apikey,typeId=typeId,pageNo =1,pageSize=60,tagId=tagid)
        data =  json.loads(GetHttpData(url))
        return data
        
    def mplay(self,tvId,albumId,res = 4):
        param = '{apiKey}/0/{res}/{tvId}/{albumId}'.format(apiKey=self.apikey,res=res,tvId=tvId,albumId=albumId)
        url = 'http://data.itv.iqiyi.com/itv/mplay/' + base64.b64encode(param)
        data =  json.loads(GetHttpData(url,self.head))
        return data['data'].get('m3u8',"")
    

#cc = IqiyiItv(1)
#cc.login()
#cc.getAlbumVideo(2084935)
#print cc.mplay(936882,2084935)
#print cc.getAlbumList(1,1,60,450)
#cc.getChnList()







