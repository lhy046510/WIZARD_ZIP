plugin.video.mediacorp
================

v0.1.0
XBMC Addon for Mediacorp TV Singapore

Plays Tv catch-up for channels 5,8,Channel U, Suria, Okto and Vasantham. To display chinese titles correctly, choose Arial Font under Settings/Appearance/Skin/Font

v0.1.1

Removed UNSORTED View to allow other sorts to be viewed
Set mimetype in addurl - supposed to speed things up

v0.2.0
version 0.2.0 added required fields in addon.xml, translatable strings separated

v0.2.2
minor change to addon.xml

Version 1.0.2 rewrite for web site changes

Version 1.0.3 cleanup of folder name and settings xml

Version 1.1.4 significant website change

Version 1.1.5 Added Brightcove support