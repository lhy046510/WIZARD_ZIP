plugin.video.viewster================


XBMC Addon for viewster website

version 1.0.1 initial release

