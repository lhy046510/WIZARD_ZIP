import urlparse

import mediaitem
import chn_class
from helpers import datehelper
from logger import Logger


class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "lamasimage.png"

        # setup the urls
        self.mainListUri = "http://sites.bnn.nl/page/lamazien/zoek/doemaarwat"
        self.baseUrl = "http://sites.bnn.nl"

        # setup the main parsing data
        self.episodeItemRegex = "(?:<div class=\"button\"[^>]+href='(/page/lamazien/[^']+)';\">([^<]+)</div>|<a href=\"(/page/lamazien/zoek/[^\"]+)\">([^<]+)</a>)"  # used for the ParseMainList
        self.videoItemRegex = """<li>\W+<strong>([^<]+)</strong>+[\w\W]+?onclick="location.href='([^']+)';[\W\w]+?<img src="([^"]+)"[\W\w]+?</div>\W+</div>\W+(?:<br /> )*([^<>]+)<br />(?:\W+<small>[^,]+, (\d+) (\w+) (\d+)</small>){0,1}"""   # used for the CreateVideoItem
        self.folderItemRegex = ''  # used for the CreateFolderItem
        self.mediaUrlRegex = "'file', '([^']+\.flv)'"    # used for the UpdateVideoItem

        #===============================================================================================================
        # non standard items
        self.topDescription = ""

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CtMnDownloadItem(self, item):
        item = self.DownloadVideoItem(item)
        return item

    def CreateEpisodeItem(self, resultSet):
        """Creates a new MediaItem for an episode
        
        Arguments:
        resultSet : list[string] - the resultSet of the self.episodeItemRegex
        
        Returns:
        A new MediaItem of type 'folder'
        
        This method creates a new MediaItem from the Regular Expression 
        results <resultSet>. The method should be implemented by derived classes 
        and are specific to the channel.
         
        """

        name = resultSet[3]
        url = resultSet[2]
        if name == '':
            name = "-= %s =-" % (resultSet[1], )
            url = resultSet[0]
        
        # dummy class
        item = mediaitem.MediaItem(name, urlparse.urljoin(self.baseUrl, url))
        item.complete = True
        return item
    
    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.
        
        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex
        
        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)
        
        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes 
        and are specific to the channel.
        
        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.
         
        """

        Logger.Trace(resultSet)
        
        item = mediaitem.MediaItem(resultSet[0], urlparse.urljoin(self.baseUrl, resultSet[1].replace(" ", "%20")))
        item.type = 'video'
        item.icon = self.icon
        
        # temp store the thumb for use in UpdateVideoItem
        item.thumb = resultSet[2]
        item.description = resultSet[3]
                
        if not resultSet[4] == "":
            day = resultSet[4]
            month = resultSet[5]
            month = datehelper.DateHelper.GetMonthFromName(month, "nl", short=False)
            year = resultSet[6]
            item.SetDate(year, month, day)
        
        # getting the URL is part of the PlayVideo
        item.downloadable = True
        item.complete = True
        return item