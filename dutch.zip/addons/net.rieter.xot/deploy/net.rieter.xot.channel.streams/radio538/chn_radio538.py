import mediaitem
import chn_class

from regexer import Regexer
from logger import Logger
from urihandler import UriHandler
from helpers.datehelper import DateHelper

class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = ""

        # setup the urls
        if self.channelCode == '538':
            self.noImage = "radio538image.png"
            self.mainListUri = "http://www.538gemist.nl/"
            self.baseUrl = "http://www.538.nl"
            self.swfUrl = "http://www.538.nl/jwplayer/player.swf"

        # setup the main parsing data
        self.episodeItemRegex = '<option value="(\d+)">([^<]+)</option>'
        self.videoItemRegex = '<figure style="background-image:url\(([^"]+)\);">[\w\W]{0,200}?<h1>' \
                              '<a[^>]+href="(/gemist/(\d+)/[^"]+)"[^>]*title="([^"]+)"[^>]*>[^>]*></h1>' \
                              '<p>([^<]+)</p><time datetime="(\d+) (\w+) (\d+), (\d+):(\d+) uur">'

        self.mediaUrlRegex = '<media:content url="([^"]+)"'
        self.pageNavigationRegex = '<a href="(/gemist/filter/pagina/)(\d+)[\w\W]{0,200}?<span>Volgende</span></a>'
        self.pageNavigationRegexIndex = 1

        #===============================================================================================================
        # non standard items
        self.EndOfProgramsFound = True  # should be done in the pre-processor

        #===============================================================================================================
        # Test cases:

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CreateEpisodeItem(self, resultSet):
        """Creates a new MediaItem for an episode

        Arguments:
        resultSet : list[string] - the resultSet of the self.episodeItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        Logger.Trace(resultSet)

        # the URL
        programId = resultSet[0]
        url = "http://www.538.nl/gemist/filter/pagina/1/type/video,audiofragmenten,uitzending-gemist" \
              "/programma/%s/sortering/date" % (programId, )

        if programId == "0":
            # first set of <option> elements, we should use them
            self.EndOfProgramsFound = False
            return None

        if self.EndOfProgramsFound:
            return None

        # the title
        title = resultSet[1]

        item = mediaitem.MediaItem(title, url)
        # item.thumb = resultSet.get("thumburl", None)
        # item.description = resultSet.get("description", "")
        item.icon = self.icon
        item.complete = True
        item.fanart = self.fanart
        return item

    def ParseMainList(self, returnData=False):
        """Parses the mainlist of the channel and returns a list of MediaItems

        This method creates a list of MediaItems that represent all the different
        programs that are available in the online source. The list is used to fill
        the ProgWindow.

        Keyword parameters:
        returnData : [opt] boolean - If set to true, it will return the retrieved
                                     data as well

        Returns a list of MediaItems that were retrieved.

        """

        if returnData:
            items, data = chn_class.Channel.ParseMainList(self, returnData=returnData)
        else:
            items = chn_class.Channel.ParseMainList(self, returnData=returnData)

        # add live stuff
        live = mediaitem.MediaItem("Live streams", "")
        live.icon = self.icon
        live.thumb = self.noImage
        live.complete = True
        #live.SetDate(2050, 1, 1)

        tv538 = mediaitem.MediaItem("TV 538", "")
        tv538.icon = self.icon
        tv538.thumb = self.noImage
        tv538.AppendSingleStream("rtmp://82.201.53.52:80/livestream/tv538 live=1", 800)
        tv538.type = "video"
        tv538.complete = True
        live.items.append(tv538)

        cam538 = mediaitem.MediaItem("538 Webcam", "")
        cam538.icon = self.icon
        cam538.thumb = self.noImage
        cam538.AppendSingleStream("rtmp://82.201.53.52:80/livestream/live live=1", 800)
        cam538.type = "video"
        cam538.complete = True
        live.items.append(cam538)

        slam = mediaitem.MediaItem("Slam TV", "")
        slam.icon = self.icon
        slam.thumb = self.noImage
        slam.AppendSingleStream("rtmp://82.201.53.52:80/livestream/slamtv live=1", 800)
        slam.type = "video"
        slam.complete = True
        live.items.append(slam)

        data = ""
        items.append(live)

        # now = datetime.datetime.now()
        # fromDate = now - datetime.timedelta(365)
        # Logger.Debug("Showing dates starting from %02d%02d%02d to %02d%02d%02d", fromDate.year, fromDate.month, fromDate.day, now.year, now.month, now.day)
        # current = fromDate
        # while current <= now:
        #     url = "http://www.538.nl/ajax/VdaGemistBundle/Gemist/ajaxGemistFilter/date/%02d%02d%02d" % (current.year, current.month, current.day)
        #     title = "Afleveringen van %02d-%02d-%02d" % (current.year, current.month, current.day)
        #     dateItem = mediaitem.MediaItem(title, url)
        #     dateItem.icon = self.icon
        #     dateItem.thumb = self.noImage
        #     dateItem.complete = True
        #     dateItem.httpHeaders = {"X-Requested-With": "XMLHttpRequest"}
        #     items.append(dateItem)
        #     current = current + datetime.timedelta(1)

        if returnData:
            # (items, data) = chn_class.Channel.ParseMainList(self, returnData=returnData)
            # items.append(live)
            return items, data
        else:
            return items

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        Logger.Trace(resultSet)

        thumbUrl = resultSet[0]
        # episodeUrl = resultSet[1]
        episodeId = resultSet[2]
        programTitle = resultSet[3]
        episodeTitle = resultSet[4]
        day = resultSet[5]
        month = resultSet[6]
        month = DateHelper.GetMonthFromName(month, language="nl")
        year = resultSet[7]
        hour = resultSet[8]
        minute = resultSet[9]

        title = episodeTitle
        if programTitle:
            title = "%s - %s" % (programTitle, episodeTitle)

        url = "http://www.538.nl/static/VdaGemistBundle/Feed/xml/idGemist/%s" % (episodeId,)

        item = mediaitem.MediaItem(title, url)
        item.type = 'video'

        item.SetDate(year, month, day, hour, minute, 0)
        item.description = episodeTitle
        item.thumb = thumbUrl
        item.icon = self.icon
        item.complete = False
        return item

    def CreatePageItem(self, resultSet):
        page = chn_class.Channel.CreatePageItem(self, resultSet)
        Logger.Trace(page.url)
        filterValue = self.parentItem.url.replace("http://www.538.nl/gemist/filter/pagina/", "")
        filterValue = filterValue[filterValue.index("/"):]
        page.url = "%s%s" % (page.url, filterValue)
        Logger.Trace(page.url)
        return page

    def UpdateVideoItem(self, item):
        """Updates an existing MediaItem with more data.

        Arguments:
        item : MediaItem - the MediaItem that needs to be updated

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        Logger.Debug('Starting UpdateVideoItem for %s (%s)', item.name, self.channelName)

        # now the mediaurl is derived. First we try WMV
        data = UriHandler.Open(item.url)
        item.MediaItemParts = []
        i = 1
        for part in Regexer.DoRegex(self.mediaUrlRegex, data):
            name = "%s - Deel %s" % (item.name, i)
            mediaPart = mediaitem.MediaItemPart(name, part, 128)
            item.MediaItemParts.append(mediaPart)
            i += 1

        item.complete = True
        return item
