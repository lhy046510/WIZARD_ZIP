from helpers.datehelper import DateHelper
import mediaitem
import chn_class
#from helpers import datehelper
from helpers import xmlhelper

from logger import Logger
from urihandler import UriHandler


class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "at5image.png"

        # setup the urls
        self.mainListUri = "http://www.at5.nl/tv/overzicht"
        self.baseUrl = "http://www.at5.nl"
        self.swfUrl = "http://www.at5.nl/embed/at5player.swf"

        # setup the main parsing data
        self.episodeItemRegex = '<li><a class="" href="(/tv/[^"]+)">([^<]+)</a></li>'
        self.videoItemRegex = """<div class="news-item-v2">\W*<a\W*href="[^"]+/(\d+)[^>]+>\W*<span[^>]+>([^<]+)</span>\W*<img[^>]+src=['"]([^'"]+)['"][^>]+>\W*<p>([^<]+)</p>"""
        self.mediaUrlRegex = '<param\W+name="URL"\W+value="([^"]+)"'
        self.pageNavigationRegex = '<a href="(/[^"]+page/)(\d+)">\d+</a>'
        self.pageNavigationRegexIndex = 1

        #===============================================================================================================
        # non standard items

        #===============================================================================================================
        # Test cases:

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CreateEpisodeItem(self, resultSet):
        """
        Accepts an arraylist of results. It returns an item.
        """

        item = mediaitem.MediaItem(resultSet[1], "%s%s" % (self.baseUrl, resultSet[0]))
        item.icon = self.icon
        item.thumb = self.noImage
        item.complete = True
        return item

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        Logger.Trace(resultSet)

        vid = resultSet[0]
        title = resultSet[1]
        thumbUrl = resultSet[2]
        if "http" not in thumbUrl:
            thumbUrl = "%s%s" % (self.baseUrl, thumbUrl)

        description = resultSet[3]

        url = "http://www.at5.nl/embedder/videodata?e=%s" % (vid,)

        item = mediaitem.MediaItem(title, url)
        item.description = description
        item.thumb = thumbUrl
        item.icon = self.icon
        #item.SetDate(year, month, day)
        item.type = 'video'
        item.complete = False

        # try to parse a date (for Journaal)
        dateParts = description.split(" ")
        Logger.Trace(dateParts)
        if len(dateParts) == 3:
            try:
                month = DateHelper.GetMonthFromName(dateParts[2], "nl")
                item.SetDate(DateHelper.ThisYear(), month, dateParts[1])
            except ValueError:
                pass
        return item

    def UpdateVideoItem(self, item):
        """
        Accepts an item. It returns an updated item. Usually retrieves the MediaURL
        and the Thumb! It should return a completed item.
        """
        Logger.Debug('Starting UpdateVideoItem for %s (%s)', item.name, self.channelName)

        data = UriHandler.Open(item.url)
        xml = xmlhelper.XmlHelper(data)

        if not item.thumb:
            # if not thumb was present use the one from the XML
            item.thumb = xml.GetSingleNodeContent("videoimage")

        server = xml.GetSingleNodeContent("server")
        fileName = xml.GetSingleNodeContent("filename")
        mediaUrl = "%s_definst_/%s" % (server, fileName)
        mediaUrl = self.GetVerifiableVideoUrl(mediaUrl)
        item.AppendSingleStream(mediaUrl, 0)

        item.complete = True
        return item
