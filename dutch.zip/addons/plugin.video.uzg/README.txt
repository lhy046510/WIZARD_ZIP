plugin.video.uzg
================

Uitzendinggemist NPO NED1, NED2, NED3

Install
-------
Download the repo as zip (or go to downloads in https://bitbucket.org/Opvolger/plugin.video.uzg/downloads)

if you download de git-repo rename de zip file to plugin.video.uzg-xxxx.zip where xxxx = versionnumber.

Install the plugin in XBMC. And ready to go!


Work in progress
----------------
I work with hg, and will push (by a new stable version) and pull (if there is a pull request that I like)

My work (unstable) https://bitbucket.org/Opvolger/plugin.video.uzg (hg repo).

My git version https://github.com/Opvolger/plugin.video.uzg (git repo)
