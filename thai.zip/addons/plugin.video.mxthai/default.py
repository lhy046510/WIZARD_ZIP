import sys
import xbmcgui
import xbmcplugin
import urllib
import urllib2
import re
import fileinput

 
addon_handle = int(sys.argv[1])
 
xbmcplugin.setContent(addon_handle, 'movies')

response = urllib2.urlopen('http://goo.gl/Hf6pZW')
for line in response:
    print line

response = urllib2.urlopen('http://goo.gl/u3Nwfx')
for lines in response:
    print lines

url = 'livem3u8.me.totiptv.com/live/8BAD9F20FF2246B894EDDCED10DCFDEB.m3u8?pt=1&code='
li = xbmcgui.ListItem('Channel 3', iconImage='http://103.7.58.100/images/logoch/freetv/3ch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)

url = 'livem3u8.me.totiptv.com/live/1D92193B11FE490B8C67D0A88BEE3FD6.m3u8?pt=1&code='
li = xbmcgui.ListItem('Channel 5', iconImage='http://103.7.58.100/images/logoch/freetv/5ch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/DDFA47E726444446864B14E0E819FDDE.m3u8?pt=1&code='
li = xbmcgui.ListItem('Channel 7', iconImage='http://103.7.58.100/images/logoch/freetv/7ch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/3AE2FD6CCAF6499E898DE377ED74EA12.m3u8?pt=1&code='
li = xbmcgui.ListItem('Channel 9', iconImage='http://103.7.58.100/images/logoch/freetv/9ch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/47105F5B5ACC488FB43354F6FA3142C1.m3u8?pt=1&code='
li = xbmcgui.ListItem('NBT', iconImage='http://103.7.58.100/images/logoch/freetv/nbt.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/D7182FAE6E9F4D929BDB5AE06059BDA8.m3u8?pt=1&code='
li = xbmcgui.ListItem('Thai PBS', iconImage='http://103.7.58.100/images/logoch/freetv/thaipbs.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/31dbe17e0c1b4c8684200f83b85b007b.m3u8?pt=1&code='
li = xbmcgui.ListItem('ASTV News 1', iconImage='http://103.7.58.100/images/logoch/news/news1.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/A5B25476119B46F5B5A34D56F7D1156C.m3u8?pt=1&code='
li = xbmcgui.ListItem('Nation Channel', iconImage='http://103.7.58.100/images/logoch/news/nation.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/26FE491F794F4497AC96BC1571A705BC.m3u8?pt=1&code='
li = xbmcgui.ListItem('Bangkok Channel', iconImage='http://103.7.58.100/images/logoch/news/bkkch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/326A1BC675A843488B0B4D69B4F75246.m3u8?pt=1&code='
li = xbmcgui.ListItem('DMC', iconImage='http://103.7.58.100/images/logoch/reli/dmc.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/f902199d513449e6a51ce477508b1246.m3u8?pt=1&code='
li = xbmcgui.ListItem('Money Channel', iconImage='http://103.7.58.100/images/logoch/news/moneych.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)



url = 'livem3u8.me.totiptv.com/live/1AE0F87662C248D693D2EED30B698760.m3u8?pt=1&code='
li = xbmcgui.ListItem('Spring News', iconImage='http://103.7.58.100/images/logoch/news/spring.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/B29F0E7ADA6348C6851BAD32728A6DDB.m3u8?pt=1&code='
li = xbmcgui.ListItem('Voice TV', iconImage='http://103.7.58.100/images/logoch/news/voicetv.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/6d5587cf7ce94cd8a7477775b7ddc253.m3u8?pt=1&code='
li = xbmcgui.ListItem('Asia Update', iconImage='http://103.7.58.100/images/logoch/news/asiaupdate.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/76221348029846b6a86cce2f76e60f82.m3u8?pt=1&code='
li = xbmcgui.ListItem('Blue Sky channel', iconImage='http://103.7.58.100/images/logoch/news/bluesky.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/bcc7d0600c9943f2a1114f5749d180e8.m3u8?pt=1&code='
li = xbmcgui.ListItem('T News', iconImage='http://103.7.58.100/images/logoch/news/tnews.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/e05107e8304b4d118c92b5dffa636715.m3u8?pt=1&code='
li = xbmcgui.ListItem('Grand Prix Channel', iconImage='http://103.7.58.100/images/logoch/variety/grandprix.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/304d812ce66a44a7a7eea2fe10dc9d1e.m3u8?pt=1&code='
li = xbmcgui.ListItem('Super Enterainment', iconImage='http://103.7.58.100/images/logoch/variety/super_ent.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/4E38ED2FA4DD43999828EAB81196DEFF.m3u8?pt=1&code='
li = xbmcgui.ListItem('Star Max Channel', iconImage='http://103.7.58.100/images/logoch/variety/starmax.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/7454994CEF7F464F9BF8E4331EE83902.m3u8?pt=1&code='
li = xbmcgui.ListItem('Green Channel', iconImage='http://103.7.58.100/images/logoch/variety/greench.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)

url = 'livem3u8.me.totiptv.com/live/45607BB280464483896716F7FA17B4D2.m3u8?pt=1&code='
li = xbmcgui.ListItem('Bang Channel', iconImage='http://103.7.58.100/images/logoch/variety/bangch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/2EE9E13BB4E442D29F7E3E858E8222E7.m3u8?pt=1&code='
li = xbmcgui.ListItem('Dude TV', iconImage='http://103.7.58.100/images/logoch/variety/dude.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/a9a68ab5471d4d39ba25695a66957067.m3u8?pt=1&code='
li = xbmcgui.ListItem('Workpoint TV', iconImage='http://103.7.58.100/images/logoch/variety/wrkpnt.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/8E959F5D739D497C95FAA31B3A810DD6.m3u8?pt=1&code='
li = xbmcgui.ListItem('You Channel', iconImage='http://103.7.58.100/images/logoch/variety/youch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/BFEE35DC7917423EB68FC3E5EDAAAE64.m3u8?pt=1&code='
li = xbmcgui.ListItem('TV Pool', iconImage='http://103.7.58.100/images/logoch/variety/tvpool.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/1E2B9312FC384567AC6A12E650D8796A.m3u8?pt=1&code='
li = xbmcgui.ListItem('Dara Daily', iconImage='http://103.7.58.100/images/logoch/variety/dara.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/BB8F0DEBA37F4F3A8D0BD0DE1656852F.m3u8?pt=1&code='
li = xbmcgui.ListItem('Saranair Channel', iconImage='http://103.7.58.100/images/logoch/variety/sara.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/9623847065ba466e90632cf686fade0b.m3u8?pt=1&code='
li = xbmcgui.ListItem('Zaa HD', iconImage='http://103.7.58.100/images/logoch/variety/zaa.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/ce4efc6a833f424f8d6cdcad5573f369.m3u8?pt=1&code='
li = xbmcgui.ListItem('Sun Channel HD', iconImage='http://103.7.58.100/images/logoch/variety/sch.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/6419c83b42934de3a333c5a32737b559.m3u8?pt=1&code='
li = xbmcgui.ListItem('GMM Music HD', iconImage='http://103.7.58.100/images/logoch/music/gmmmusic.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


url = 'livem3u8.me.totiptv.com/live/860605f7e16d4c6cacef72ef02ffa2c1.m3u8?pt=1&code='
li = xbmcgui.ListItem('Cartoon Club', iconImage='http://103.7.58.100/images/logoch/kids/toonclub.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url+line, listitem=li)


response.close()

xbmcplugin.endOfDirectory(addon_handle)
