
Extra Features
==============

Context Menu
------------
**Movie Information** : Provides information on the selected movie and also whether subtitles are available

**Clear Cache** : Clears the cache, following which all metadata is re-scraped

Addon Settings
--------------
**Cache Period** : Period of time to retain metada in the cache, following which all metadata is re-scraped