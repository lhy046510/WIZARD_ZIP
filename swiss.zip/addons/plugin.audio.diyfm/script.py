# import xbmcaddon
#
#
# __settings__ = xbmcaddon.Addon(id='plugin.audio.diyfm')
#
#
# def start_radio():
#     if __settings__.getSetting('play_news') == 'true':
#         pass