# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os, json

def stream_decoder(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3')
    req.add_header('Referer', url)
    f = urllib2.urlopen(req)
    data = json.load(f)
    return data['streaming_url']['http']
