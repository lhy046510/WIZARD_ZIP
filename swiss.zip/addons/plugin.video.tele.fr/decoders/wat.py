# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os

def stream_decoder(url):
    url2 = "http://smooth.wat.tv/DVR_ETF1/HLS/playlists/streams.js"
    user_agent = 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0'
    req = urllib2.Request(url2, headers={'X-Forwarded-For': '77.132.237.189','User-Agent': user_agent })
    try:
        f = urllib2.urlopen(req)
        url2 = f.read()
        f.close()
        m3u8 = re.findall("file:'(.*?)\?(.*?)'", url2)
        return url+"&"+m3u8[0][1]+"|X-Forwarded-For=77.132.237.189"
    except:
        return url
