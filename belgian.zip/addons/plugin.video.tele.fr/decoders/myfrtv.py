# -*- coding: UTF-8 -*-

import urllib2

def stream_decoder(url):
    try:
        req = urllib2.Request("http://www.gwenael.org/xbmc-streams/myfrtv.txt")
        f = urllib2.urlopen(req)
        html = f.read()
        return url+html.rstrip('\n')
    except:
        return url
