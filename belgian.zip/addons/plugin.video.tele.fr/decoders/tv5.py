# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os

def stream_decoder(url):
    url2 = "http://www.tv5monde.com/player/html/services/getToken.json"
    data = urllib.urlencode({"url": url,"uid":"acfc6a3aabc81a943dde4dcbace709c8","operation":"getToken"})
    req = urllib2.Request(url2, data)
    try:
        f = urllib2.urlopen(req)
        json = f.read()
        f.close()
        token = re.findall('value\":\"(.*?)\"',json)
        return token[0].replace("\\","")
    except:
        return url
