# -*- coding: UTF-8 -*-

import urllib2

def stream_decoder(url):
    user_agent = 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0'
    referer = "http://www.abweb.com/BIS-TV-Online/bistvo-tele-sur-pc.aspx"
    cookie1 = "ASP.NET_SessionId=4vb3iskwefaansu5v3rvmexu"
    cookie2 = ".abportail1=7FED0A708DF840A0486D6C2908E47C160E78B8EEF8B64039673C204B7248D071E25487EB407108D701AC3CD117BE5AE1827EB484960DE44476C536A7E8ED12316F7BC440592B0FFCAADABFDB0220DBC7C1D0762F266486E4AA5240A7A2EC95A049EB79BA365ED4360E4E7D06395CEA87E3A6EEA43E2E57E480642F89CC8ACCCD25D1D9B47E9042A62129A91115B43ED7928AB61A"
    req = urllib2.Request(url, headers={'X-Forwarded-For': '77.132.237.189','User-Agent': user_agent,'Referer': referer, 'Cookie': cookie1, 'Cookie': cookie2})
    try:
        f = urllib2.urlopen(req)
        f4m = f.read()
        f.close()
        return f4m    
    except:
        return url
