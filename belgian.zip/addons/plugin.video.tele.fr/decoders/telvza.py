# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os

def stream_decoder(url):
    page = url.split(' ')
    req = urllib2.Request(page[0], headers={'User-Agent': 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0', 'Cookie': 'SESSbae7a87956c79f1520e34d92d94d99a8=E6BA7uAIDJB_77E_rNK137I174mQWy6fVm8TdtzPEEA' })
    f = urllib2.urlopen(req)
    try:
        html = f.read()
        f.close()
        rtmp = re.findall('file: "(.*?)&e=(.*?)",',html)
        url = os.path.dirname(os.path.dirname(rtmp[0][0]))+"/"+os.path.basename(os.path.dirname(rtmp[0][0]))+"/"+os.path.basename(rtmp[0][0])+'&e='+str(rtmp[0][1])+" swfUrl=http://www.telvza-online.com/jwplayer/jwplayer.flash.swf pageUrl="+os.path.dirname(url)+" swfVfy=true live=true timeout=60"
        return url
    except:
        return url
